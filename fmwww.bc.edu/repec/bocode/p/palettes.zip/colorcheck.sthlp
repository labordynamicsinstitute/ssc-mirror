.h colorpalette
