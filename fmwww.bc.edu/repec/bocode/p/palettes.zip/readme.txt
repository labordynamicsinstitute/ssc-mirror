Recommended installation procedure:

 Type -ssc install palettes, replace- in Stata.

Alternative installation procedure (if you cannot
use -ssc- due to firewall issues, etc.):

 1. Download palettes.zip.

 2. Unzip palettes.zip into a temporary directory on
    your hard disk (e.g. c:\temp).

 3. Start Stata and type -net from c:\temp- or
    wherever you unzipped the files.

 4. Type -net install palettes, replace-.

20220403, Ben Jann
