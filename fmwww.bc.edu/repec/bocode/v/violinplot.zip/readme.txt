Recommended installation procedure:

 Type -ssc install violinplot, replace- in Stata.

Alternative installation procedure (if you cannot
use -ssc- due to firewall issues, etc.):

 1. Download violinplot.zip.

 2. Unzip violinplot.zip into a temporary directory on
    your hard disk (e.g. c:\temp).

 3. Start Stata and type -net from c:\temp- or
    wherever you unzipped the files.

 4. Type -net install violinplot, replace-.

20230322, Ben Jann
