*! Source of lgeoplot.mlib
*! {smcl}
*!     {helpb lgeoplot_source##geo_area:geo_area()}
*!     {helpb lgeoplot_source##geo_bbox:geo_bbox()}
*!     {helpb lgeoplot_source##geo_bshare:geo_bshare()}
*!     {helpb lgeoplot_source##geo_centroid:geo_centroid()}
*!     {helpb lgeoplot_source##geo_circle_tangents:geo_circle_tangents()}
*!     {helpb lgeoplot_source##geo_clip:geo_clip()}
*!     {helpb lgeoplot_source##geo_gtype:geo_gtype()}
*!     {helpb lgeoplot_source##geo_hull:geo_hull()}
*!     {helpb lgeoplot_source##geo_inpoly:geo_inpoly()}
*!     {helpb lgeoplot_source##geo_json:geo_json_import() and geo_json2xy()}
*!     {helpb lgeoplot_source##geo_ksmooth:geo_ksmooth()}
*!     {helpb lgeoplot_source##geo_orientation:geo_orientation()}
*!     {helpb lgeoplot_source##geo_pid:geo_pid()}
*!     {helpb lgeoplot_source##geo_plevel:geo_plevel()}
*!     {helpb lgeoplot_source##geo_pointinpolygon:geo_pointinpolygon()}
*!     {helpb lgeoplot_source##geo_project:geo_project()}
*!     {helpb lgeoplot_source##geo_raster:geo_raster()}
*!     {helpb lgeoplot_source##geo_refine:geo_refine()}
*!     {helpb lgeoplot_source##geo_rotate:geo_rotate()}
*!     {helpb lgeoplot_source##geo_simplify:geo_simplify()}
*!     {helpb lgeoplot_source##geo_spjoin:geo_spjoin()}
*!     {helpb lgeoplot_source##geo_symbol:geo_symbol()}
*!     {helpb lgeoplot_source##geo_tissot:geo_tissot()}
*!     {helpb lgeoplot_source##geo_welzl:geo_welzl()}
*!     {helpb lgeoplot_source##geo_wkt2xy:geo_wkt2xy()}
*!     {helpb lgeoplot_source##_geo_progress:_geo_progress()}
*!     {help  lgeoplot_source##varia:Further functions}
*! {asis}

version 16.1

*! {smcl}
*! {marker geo_area}{bf:geo_area()}{asis}
*! version 1.0.4  28aug2024  Ben Jann
*!
*! Computes area of each unit using the Shoelace formula; see
*! https://en.wikipedia.org/wiki/Shoelace_formula. Only polygons are considered.
*! Nested polygons within a unit are assumed to switch orientation (so that
*! "holes" will be deducted from the total area of the unit). Zero will be
*! returned for units that do not contain polygons.
*!
*! geo_gtype() is used to classify the geometry items within a unit; polygons
*! are assumed to start with missing.
*!
*!      result = geo_area(rtype, ID, XY)
*!
*!  rtype   results type: if rtype!=0 the result is a n x 1 vector containing
*!          repeated area values, else the result is a r x 1 matrix with ID in
*!          1st column and area in 2nd column, where r is the number of units
*!  ID      n x 1 real colvector of unit IDs (or, possibly, scalar if single
*!          unit); rows are assumed to be grouped by unit ID
*!  XY      n x 2 real matrix of (X,Y) coordinates of the geometry items
*!

mata:
mata set matastrict on

real matrix geo_area(real scalar rtype, real colvector ID, real matrix XY)
{
    real scalar    i, n, a, b
    real colvector p
    real matrix    A
    
    if (cols(XY)!=2) {
        errprintf("{it:XY} must have two columns\n")
        exit(3200)
    }
    n = rows(XY)
    i = rows(ID)
    if (i!=1) {
        if (i!=n) exit(error(3200))
    }
    if (!n) return(J(0, 1 + !rtype, .)) // no data
    if (n==1) { // single obs
        if (rtype) return(0)
        else       return(ID, 0)
    }
    if (rows(ID)==1) { // single unit
        p = 1
        A = _geo_area(XY)
    }
    else {
        p = selectindex(_mm_unique_tag(ID))
        i = rows(p)
        if (i==n) { // one obs per unit
            if (rtype) return(J(i,1,0))
            else       return(ID, J(i,1,0))
        }
        A = J(i,1,.)
        a = n + 1
        for (;i;i--) {
            b = a - 1; a = p[i]
            A[i] = _geo_area(XY[|a,1 \ b,.|])
        }
    }
    if (rtype) {
        i = rows(p)
        a = n + 1
        A = A \ J(n-i,1,.)
        for (;i;i--) {
            b = a - 1; a = p[i]
            A[|a \ b|] = J(b-a+1, 1, A[i,])
        }
        return(A)
    }
    else return(ID[p], A)
}

real rowvector _geo_area(real matrix XY)
{
    real colvector g, cnt
    
    g = geo_gtype(3, ., geo_pid(., XY), XY, cnt=.)
    if (cnt[4]) { // area of polygons
        if (sum(cnt)==cnt[4]) return(__geo_area(XY))
        return(__geo_area(select(XY, g:==3)))
    }
    return(0)
}

real rowvector __geo_area(real matrix XY)
{
    real scalar A
    
    if (rows(XY)<2) return(0)
    A = quadsum(quadrowsum((1,-1) :* XY :* (XY[|2,1\.,.|] \ (.,.))[,(2,1)]))
    return(abs(editmissing(A,0))/2)
}

end

*! {smcl}
*! {marker geo_bbox}{bf:geo_bbox()}{asis}
*! version 1.0.1  01jun2024  Ben Jann
*!
*! Determine (minimum) bounding box around cloud of points
*! minimum bounding box algorithm loosely based on
*! https://en.wikipedia.org/wiki/Minimum_bounding_box_algorithms
*!
*! Syntax:
*!
*!      result = geo_bbox(XY [, type])
*!
*!  result  real matrix containing (X,Y) of bounding box (counterclockwise)
*!  XY      n x 2 real matrix containing the points; rows containing missing
*!          will be ignored
*!  type    real scalar selecting type of box and algorithm
*!           0 = regular (unrotated) bounding box (the default)
*!           1 = minimum-area bounding box using rotating calipers algorithm
*!           2 = minimum-perimeter bounding box using rotating calipers alg.
*!          -1 = minimum-area bounding box using tilting algorithm
*!          -2 = minimum-perimeter bounding box using tilting algorithm
*!

mata
mata set matastrict on

real matrix geo_bbox(real matrix XY, | real scalar type)
{
    if (args()<2) type = 0
    if (cols(XY)!=2) {
        errprintf("{it:XY} must have two columns\n")
        exit(3200)
    }
    if (!hasmissing(XY)) return(_geo_bbox(XY, type))
    return(_geo_bbox(select(XY, !rowmissing(XY)), type))
}

real matrix _geo_bbox(real matrix XY, real scalar type)
{
    if (type==1)  return(_geo_bbox_rc(XY))
    if (type==2)  return(_geo_bbox_rc(XY, 1))
    if (type==-1) return(_geo_bbox_tilt(XY))
    if (type==-2) return(_geo_bbox_tilt(XY,1))
    return(_geo_bbox_regular(XY))
}

real matrix _geo_bbox_regular(real matrix XY)
{
    real matrix xy
    
    xy = colminmax(XY)
    return((xy[2,1],xy[1,2]) \ // xmax,ymin
           (xy[2,1],xy[2,2]) \ // xmax,ymax
           (xy[1,1],xy[2,2]) \ // xmin,ymax
           (xy[1,1],xy[1,2]) \ // xmin,ymin
           (xy[2,1],xy[1,2]))  // xmax,ymin
}

real matrix _geo_bbox_rc(real matrix XY, | real scalar perim)
{
    real scalar    b, r, t, l, a, n, xmin, xmax, ymax
    real matrix    xy, xy1
    real scalar    size, Size
    real matrix    box, Box
    
    if (args()<2) perim = 0
    // get convex hull
    xy = _geo_hull(XY)
    n = rows(xy)
    if (n==0) return(J(5,2,.))
    if (n==1) return(J(5,1,xy[1,]))
    n = n - 1 // omit last point (which is equal to first point)
    // determine minimal box using rotating calipers
    Size = .
    b = r = t = l = 1
    for (; b<=n; b++) {
        // find/update calipers, one on each side (bottom, right, top, left)
        a = _geo_bbox_rc_angle(xy,n, b)
        r = _geo_bbox_rc_update(xy,n, r, a, 1)
        t = _geo_bbox_rc_update(xy,n, t, a, 2)
        l = _geo_bbox_rc_update(xy,n, l, a, 3)
        // compute size of box
        xy1  = xy[mod(b-1,n)+1,] // reference point
        box  = _geo_bbox_rc_rotate(xy[mod((r,t,l):-1,n):+1,]:-xy1, -a)
        xmin = box[3,1]; xmax = box[1,1]; ymax = box[2,2] // ymin is 0
        if (perim) size = (xmax-xmin) + (ymax)
        else       size = (xmax-xmin) * (ymax)
        // store box if smaller than pervious smallest box
        if (size < Size) {
            Size = size
            box = (xmax,0) \ (xmax,ymax) \ (xmin,ymax) \ (xmin,0)
            Box = _geo_bbox_rc_rotate(box, a) :+ xy1
        }
    }
    // rearrange so that start is at bottom right
    _geo_bbox_rearrange(Box)
    return(Box \ Box[1,])
}

real scalar _geo_bbox_rc_angle(real matrix XY, real scalar n, real scalar i0)
{   // returns counterclockwise angle of edge
    real scalar    i, j, a
    real rowvector xy
    
    i = mod(i0-1,n) + 1
    j = mod(i0, n) + 1
    xy = XY[j,] - XY[i,]
    a = acos(xy[1] / sqrt(sum(xy:^2)))
    if (xy[2]<0) a = 2*pi() - a
    return(a + floor((i0-1)/n)*2*pi())
}

real scalar _geo_bbox_rc_update(real matrix XY, real scalar n,
    real scalar i, real scalar r, real scalar side)
{
    real scalar j
    
    j = i
    while (_geo_bbox_rc_angle(XY,n, j) < (side/2*pi() + r)) j++
    return(j)
}

real matrix _geo_bbox_rc_rotate(real matrix XY, real scalar r)
{
    real scalar s, c
    
    s = sin(r); c = cos(r)
    return((XY[,1] * c - XY[,2] * s, XY[,1] * s + XY[,2] * c))
}

real matrix _geo_bbox_tilt(real matrix XY, | real scalar perim)
{
    real scalar i, n, a, s, S
    real matrix xy, xy0, b, B
    
    if (args()<2) perim = 0
    xy = _geo_hull(XY)
    n = rows(xy)
    if (n==0) return(J(5,2,.))
    if (n==1) return(J(5,1,xy[1,]))
    S = .
    for (i=2;i<=n;i++) {
        xy0 = xy :- xy[i-1,]
        a   = _geo_bbox_tilt_angle(xy0[i,])
        b   = colminmax(geo_rotate(xy0, -a))
        if (perim) s = (b[2,1]-b[1,1]) + (b[2,2]-b[1,2])
        else       s = (b[2,1]-b[1,1]) * (b[2,2]-b[1,2])
        if (s<S) {
            S = s
            b = (b[2,1],b[1,2]) \ (b[2,1],b[2,2]) \
                (b[1,1],b[2,2]) \ (b[1,1],b[1,2])
            B = geo_rotate(b, a) :+ xy[i-1,]
        }
    }
    _geo_bbox_rearrange(B)
    return(B \ B[1,])
}

real scalar _geo_bbox_tilt_angle(real rowvector xy)
{
    real scalar r
    
    r = sqrt(sum(xy:^2))
    return(sign(xy[2]) * acos(xy[1]/r) / pi() * 180)
}

void _geo_bbox_rearrange(real matrix XY)
{
    real colvector i, j
    real matrix    w
    
    i = j = w = .
    minindex(XY[,2], 1, i, w)
    if (length(i)>1) {
        maxindex(XY[i,1], 1, j, w)
        i = i[j[1]]
    }
    if (i==1) return
    if (i==rows(XY)) XY = XY[i,] \ XY[|1,1 \ i-1,.|]
    else             XY = XY[|i,1 \ .,.|] \ XY[|1,1 \ i-1,.|]
}

end

*! {smcl}
*! {marker geo_bshare}{bf:geo_bshare()}{asis}
*! version 1.2.2  16jul2024  Ben Jann
*!
*! Algorithm to extract/identify shared borders between shape items; a shared
*! border is defined as an identical sequence of vertices (apart from
*! orientation) that exists in two shape items.
*!
*! Syntax:
*!
*!      result = geo_bshare(ID, PID, XY [, rtype, nodots ])
*!
*!  result  result depending on rtype (see below)
*!  ID      real colvector of unit IDs
*!  PID     real colvector of within-unit shape item IDs
*!  XY      n x 2 real matrix containing the (X,Y) coordinates of the shape
*!          items
*!  rtype   real scalar setting the type of output
*!          0: result will be a r x 5 matrix containing shape items representing
*!             shared borders; each shared border is only included once; columns
*!             are (id, id1, id2, x, y), where id contains a unique id for each
*!             item, id1 and id2 contain the ids of the units that share the
*!             border, x and y are the coordinates; r is the total length across
*!             all items; id1 and id2 will be the same for shared borders
*!             between items within a single item
*!          1: result will be a 2*r x 3 matrix containing shape items
*!             representing the shared borders of each unit (each shared border
*!             will be included twice); columns are (id, x, y) where id is the
*!             unit id and x and y are the coordinates
*!          2: result will be a q x 3 matrix containing for each unit a set of
*!             shape items representing the segments that are not shared
*!             borders; columns are (id, x, y) where id is the unit id and x and
*!             y are the coordinates; q is the total length across all included
*!             items
*!          3: result will be a n x 1 vector that tags all points in XY equal to
*!             the start or the end of a shared border
*!          4: result will be a n x 1 vector that tags all points in XY that are
*!             part of a shared border
*!          5: result will be a n x 1 vector that tags all points in XY equal to
*!             the start of a path with the length of the path
*!          6: result will be a q x 4 matrix containing connected non-shared
*!             borders (i.e. outlines and, possibly, enclaves); columns are
*!             (id, x, y, plevel) where id is equal to 1, x and y are the
*!             coordinates, and plevel is a plot level (enclave) indicator; q
*!             is the total length across all included outlines and enclaves
*!          default is 0; values other than the ones above are treated as 0
*!  nodots  nodots!=0 suppresses progress dots
*!
*! The algorithm assumed that the shape items have no repeated points, apart
*! from the first and last point in a polygon.
*!

local Bool    real scalar
local BoolC   real colvector
local Int     real scalar
local IntC    real colvector
local IntM    real matrix
local RS      real scalar
local RC      real colvector
local RR      real rowvector
local RM      real matrix
local ITEM    _geo_bshare_ITEM
local Item    struct `ITEM' scalar
local pItems  pointer (`Item') colvector
local BRDR    _geo_bshare_BRDR
local Brdr    struct `BRDR' scalar
local pBrdrs  pointer (`Brdr') colvector
local BRDRS   _geo_bshare_BRDRS
local Brdrs   struct `BRDRS' scalar
local NBRDRS  _geo_bshare_NBRDRS
local Nbrdrs  struct `NBRDRS' scalar
local pNbrdrs pointer (`RM') colvector

mata:

struct `ITEM' {    // shape item
    `Int'  id, pid // unit id and within-unit item id
    `Int'  a, b    // range indices of item in original data
    `Int'  gt      // 1 = point, 2 = line, 3 = polygon, 0 = empty
    `Bool' mis     // has leading row
    `RM'   XY      // coordinates of item (without leading row)
    `RS'   xmin, xmax, ymin, ymax // limits of data range 
}

struct `BRDR' {        // shared-border info
    `Int'    id1, id2  // internal ids of involved items
    `Int'    a1, a2    // within-item start indices
    `Int'    l         // length of shared border
}

struct `BRDRS' { // collection of shared border infos
    `Int'    n   // current length
    `pBrdrs' B   // stack of borders
}

struct `NBRDRS' { // collection of non-shared border infos
    `Int'     n   // current length
    `pNbrdrs' B   // stack of borders
}

`RM' geo_bshare(`RC' ID, `RC' PID, `RM' XY, | `Int' rtype, `Bool' nodots)
{
    `Int'    i, j, d0, dn, d
    `pItems' P
    `Brdrs'  B
    
    if (args()<4) rtype = 0
    if (args()<5) nodots = 0
    if (cols(XY)!=2) {
        errprintf("{it:XY} must have two columns\n")
        exit(3200)
    }
    // collect polygons
    P = _geo_bshare_items(ID, PID, XY)
    // identify common borders
    i = length(P)
    if (!nodots) {
        displayas("txt")
        printf("(search for shared borders among %g shape items)\n", i)
        d0 = _geo_progress_init("(")
        dn = comb(i, 2); d = 0
    }
    B.n = 0 // initialize stack
    for (;i;i--) {
        for (j=i-1;j;j--) {
            _geo_bshare(B, *P[i], *P[j], i, j)
            if (!nodots) _geo_progress(d0, ++d/dn)
        }
    }
    if (!nodots) _geo_progress_end(d0, ")")
    // return
    if (rtype==1) return(_geo_bshare_r1(B, P))
    if (rtype==2) return(_geo_bshare_r2(B, P, rows(XY)))
    if (rtype==3) return(_geo_bshare_tag(3, B, P, rows(XY)))
    if (rtype==4) return(_geo_bshare_tag(4, B, P, rows(XY)))
    if (rtype==5) return(_geo_bshare_tag(5, B, P, rows(XY)))
    if (rtype==6) return(_geo_bshare_r6(B, P, rows(XY), nodots))
                  return(_geo_bshare_r0(B, P))
}

`pItems' _geo_bshare_items(`RC' ID, `RC' PID, `RM' XY)
{   // return pointer vector of all shape items
    `Int'    i, a, b
    `IntC'   p
    `pItems' P
    
    p = selectindex(_mm_uniqrows_tag((ID,PID)))
    i = rows(p)
    P = J(i, 1, NULL)
    a = rows(XY) + 1
    for (;i;i--) {
        b = a - 1; a = p[i]
        P[i] = &_geo_bshare_item(ID, PID, XY, a, b)
    }
    return(P)
}

`Item' _geo_bshare_item(`RC' ID, `RC' PID, `RM' XY, `Int' a, `Int' b)
{   // collect shape item
    `RM'   minmax
    `Item' p
    
    p.id   = ID[a]
    p.pid  = PID[a]
    p.gt   = _geo_gtype(XY, a, b)
    p.a    = a
    p.b    = b
    p.mis  = b>a // ignore first row if more than one row
    if (!p.gt) return(p) // empty item
    p.XY   = XY[|a+p.mis,1 \ b,.|]
    minmax = colminmax(p.XY)
    p.xmin = minmax[1,1]
    p.xmax = minmax[2,1]
    p.ymin = minmax[1,2]
    p.ymax = minmax[2,2]
    return(p)
}

void _geo_bshare_add_brdr(`Brdrs' B, `Int' id1, `Int' id2, `Int' a1, `Int' a2,
    `Int' l)
{   // add info on shared border to collection
    `Brdr' b
    
    b.id1 = id1
    b.id2 = id2
    b.a1  = a1
    b.a2  = a2
    b.l   = l
    B.n = B.n + 1
    if (B.n>length(B.B)) B.B = B.B \ J(100,1,NULL)
    B.B[B.n] = &b
}

void _geo_bshare_add_nbrdr(`Nbrdrs' N, `RM' idxy)
{   // add data of non-shared border to collection
    N.n = N.n + 1
    if (N.n>length(N.B)) N.B = N.B \ J(100,1,NULL)
    N.B[N.n] = &idxy[.,.]
}

`RM' _geo_bshare_r0(`Brdrs' A, `pItems' P)
{   // return shared borders (unique)
    `Int'  i, id, n, a, b
    `Item' p
    `Brdr' B
    `RM'   R
    
    n = 0
    for (i=A.n;i;i--) n = n + A.B[i]->l + 1
    R = J(n,5,.) // id, id1, id2, x, y
    id = b = 0
    for (i=A.n;i;i--) {
        id++
        B = *A.B[i]
        p = *P[B.id1]
        a = b + 1; b = a + B.l
        R[|a,1 \ b,3|] = J(b-a+1, 1, (id, p.id, P[B.id2]->id))
        a++
        R[|a,4 \ b,5|] = __geo_bshare_r0(p.XY, B.a1, B.l)
    }
    return(R)
}

`RM' __geo_bshare_r0(`RM' XY, `Int' a, `Int' l)
{   // extract path from XY
    `Int' b, n
    
    n = rows(XY)
    b = a + l - 1
    if (b<=n) return(XY[|a,1 \ b,.|])
    return(XY[|a,1 \ n,.|] \ XY[|2,1 \ b-n+1,.|])
}

`RM' _geo_bshare_r1(`Brdrs' A, `pItems' P)
{   // return shared borders (with duplicates)
    `Int'   i, n, a, b
    `Item'  p
    `Brdr'  B
    `RM'    R
    
    n = 0
    for (i=A.n;i;i--) n = n + A.B[i]->l + 1
    R = J(2*n,3,.) // id, x, y
    b = 0
    for (i=A.n;i;i--) {
        B = *A.B[i]
        // Item 1
        p = *P[B.id1]
        a = b + 1; b = a + B.l
        R[|a,1 \ b,1|] = J(b-a+1, 1, p.id)
        a++
        R[|a,2 \ b,3|] = __geo_bshare_r0(p.XY, B.a1, B.l)
        // Item 2
        p = *P[B.id2]
        a = b + 1; b = a + B.l
        R[|a,1 \ b,1|] = J(b-a+1, 1, p.id)
        a++
        R[|a,2 \ b,3|] = __geo_bshare_r0(p.XY, B.a2, B.l)
    }
    return(mm_sort(R,1,1))
}

`RM' _geo_bshare_r2(`Brdrs' B, `pItems' P, `Int' n)
{   // return non-shared borders
    `Int'    r, i, a, b
    `IntC'   R, S
    `Nbrdrs' N
    `RM'     idxy
    
    // tag shared borders
    R = _geo_bshare_tag(3, B, P, n) + _geo_bshare_tag(4, B, P, n)
    S = _geo_bshare_tag(5, B, P, n)
    // extract non-shared borders
    N.n = r = 0 // initialize stack
    for (i=rows(P);i;i--) __geo_bshare_r2(N, r, R, S, *P[i])
    // collect results
    idxy = J(r, 3, .) // id, x, y
    b = 0
    for (i=N.n;i;i--) {
        a = b + 1
        b = b + rows(*N.B[i])
        idxy[|a,1 \ b,3|] = *N.B[i]
    }
    return(mm_sort(idxy,1,1))
}

void __geo_bshare_r2(`Nbrdrs' N, `Int' r, `IntC' R, `IntC' S, `Item' p)
{   // extract segments of shape item that are not shared boders
    `Int'  a, a0, b, n, l
    `IntC' T, U
    
    T = R[|p.a+p.mis \ p.b|]
    U = S[|p.a+p.mis \ p.b|]
    n = rows(T)
    if (n==1) { // point item
        if (!T) _geo_bshare_add_nbrdr(N, (J(2,1,p.id), ((.,.) \ p.XY)))
        return
    }
    b = .
    a0 = 0
    for (a=n-1; a>a0; a--) { // look for sequences of type 2[0...]2
        if (T[a]==1) continue
        if (T[a]==0) continue
        // reached only if T[a]==2
        if (U[a]>1) { // current point is start of a path of length>1
            b = a
            continue
        }
        if (b>=.) {
            if (p.gt==3) { // wrap around
                for (; a0<a;a0++) {
                    if (T[a0+1]==0) continue
                    break // reached only if T[a0+1]==2
                }
                if (a0) { // moved at least one position
                    l = 2 + n - a + a0
                    r = r + l
                    _geo_bshare_add_nbrdr(N, (J(l,1,p.id),
                        ((.,.) \ p.XY[|a,1 \ n,.|] \ p.XY[|2,1 \ a0+1,.|])))
                    continue
                }
            }
            b = n
        }
        l = b - a + 2
        r = r + l
        _geo_bshare_add_nbrdr(N, (J(l,1,p.id), ((.,.) \ p.XY[|a,1 \ b,.|])))
    }
    if (!a) { // collect first segment if T starts with 0
        if (T[1]) return
        if (b>=.) { // item has no shared borders
            r = r + n + 1
            _geo_bshare_add_nbrdr(N, (J(n+1,1,p.id), ((.,.) \ p.XY)))
            return
        }
        l = b + 1
        r = r + l
        _geo_bshare_add_nbrdr(N, (J(l,1,p.id), ((.,.) \ p.XY[|1,1 \ b,.|])))
    }
}

`BoolC' _geo_bshare_tag(`Int' rtype, `Brdrs' A, `pItems' P, `Int' n)
{   // tag points on shared border
    `Int'   i
    `Item'  p
    `Brdr'  B
    `BoolC' R
    pointer (function) scalar f
    
    if      (rtype==4) f = &_geo_bshare_r4() // tag all points on shared border
    else if (rtype==5) f = &_geo_bshare_r5() // store length in first point
    else               f = &_geo_bshare_r3() // tag start and end
    R = J(n,1,0)
    for (i=A.n;i;i--) {
        B = *A.B[i]
        // handle item 1
        p = *P[B.id1]
        (*f)(R, p.a+p.mis, p.b, B.a1, B.l, p.gt!=3)
        // handle item 2
        p = *P[B.id2]
        (*f)(R, p.a+p.mis, p.b, B.a2, B.l, p.gt!=3)
    }
    return(R)
}

void _geo_bshare_r3(`BoolC' R, `Int' a, `Int' b, `Int' i, `Int' l,
    `Bool' nowrap)
{   // tag start and end points of shared borders
    `Int' j

    R[a + i - 1] = 1
    j = a + i + l - 2
    if (nowrap)   R[j] = 1
    else if (j<b) R[j] = 1
    else if (j>b) R[a + j-b] = 1
    else          R[a] = R[b] = 1 
}

void _geo_bshare_r4(`BoolC' R, `Int' a, `Int' b, `Int' i, `Int' l,
    `Bool' nowrap)
{   // tag all points that are on a shared border
    `Int' j0, j1

    j0 =  a + i - 1
    j1 = j0 + l - 1
    if (nowrap)    R[|j0\j1|] = J(l,1,1)
    else if (j1<b) R[|j0\j1|] = J(l,1,1)
    else {
        R[|a\a+j1-b|] = J(j1-b+1,1,1)
        R[|j0\b|]     = J(b-j0+1,1,1)
    }
}

void _geo_bshare_r5(`BoolC' R, `Int' a, `Int' b, `Int' i, `Int' l,
    `Bool' nowrap)
{   // store length of shared border in first point of shared border (use
    // the length of the longest path if the point is the start of multiple
    // shared borders)
    `Int' j
    
    j = a + i - 1
    R[j] = max((l,R[j]))
    if (nowrap) return
    if      (j==a) R[b] = max((l,R[b]))
    else if (j==b) R[a] = max((l,R[a]))
}

`RM' _geo_bshare_r6(`Brdrs' B, `pItems' P, `Int' n, `Bool' nodots)
{   // overwrites P and n
    `Int'  i, j, r
    `IntC' ID
    `RR'   xy0, xy1
    `RM'   XY
    
    // obtain segments
    XY = _geo_bshare_r2(B, P, n)[,(2,3)]
    ID = J(rows(XY),1,1)
    P = _geo_bshare_items(ID, geo_pid(ID, XY), XY)
    // connect segments
    if (!nodots) printf("(connecting extracted segments ...")
    n = i = length(P)
    for (;i;i--) {
        if (P[i]==NULL)  continue
        if (P[i]->gt==3) continue // segment is a polygon
        xy0 = P[i]->XY[1,]
        xy1 = P[i]->XY[rows(P[i]->XY),]
        for (j = n; j; j--) {
            if (i==j)        continue
            if (P[j]==NULL)  continue
            if (P[i]->gt==3) continue // segment is a polygon
            r = rows(P[j]->XY)
            if (xy1==P[j]->XY[1,]) { // end of i = start of j
                xy1 = P[j]->XY[r,]
                P[i]->XY = P[i]->XY \ P[j]->XY[2::r,]
            }
            else if (xy1==P[j]->XY[r,]) { // end of i = end of j
                xy1 = P[j]->XY[1,]
                P[i]->XY = P[i]->XY \ P[j]->XY[r-1::1,]
            }
            else if (xy0==P[j]->XY[r,]) { // start of i = end of j
                xy0 = P[j]->XY[1,]
                P[i]->XY = P[j]->XY[1::r-1,] \ P[i]->XY
            }
            else if (xy0==P[j]->XY[1,]) { // start of i = start of j
                xy0 = P[j]->XY[r,]
                P[i]->XY = P[j]->XY[r::2,] \ P[i]->XY
            }
            else continue
            P[j] = NULL // remove item
            j = n + 1   // start over
        }
    }
    // obtain connected segments
    r = 0
    for (i=n;i;i--) {
        if (P[i]==NULL) continue
        r = r + rows(P[i]->XY) + 1
    }
    XY = J(r,2,.)
    for (i=n;i;i--) {
        if (P[i]==NULL) continue
        j = rows(P[i]->XY)
        XY[|r-j,1 \ r,2|] = (.,.) \ P[i]->XY
        r = r - j - 1
    }
    P = NULL // clear memory
    if (!nodots) display(" done)")
    // identify enclaves and return
    if (!nodots) display("(identifying plot levels)")
    ID = J(rows(XY),1,1)
    return((ID, XY, geo_plevel(1, ID, geo_pid(ID, XY), XY, nodots)))
}

void _geo_bshare(`Brdrs' B, `Item' pi, `Item' pj, `Int' id1, `Int' id2)
{   // find shared borders among shape items
    `Int'   i0, i, ni, j, nj, l
    `BoolC' tj
    `IntC'  J
    `RR'    xy
    `RM'    iXY, jXY
    
    if (!(pi.gt))          return // pi is empty
    if (!(pj.gt))          return // pj is empty
    if (pi.xmax < pj.xmin) return // pi left of pj
    if (pi.xmin > pj.xmax) return // pi right of pj
    if (pi.ymax < pj.ymin) return // pi below pj
    if (pi.ymin > pj.ymax) return // pi above pj
    if (pi.gt==3) iXY = pi.XY[|2,1\.,.|]
    else          iXY = pi.XY
    if (pj.gt==3) jXY = pj.XY[|2,1\.,.|]
    else          jXY = pj.XY
    ni = rows(iXY); nj = rows(jXY)
    J = 1::nj; tj = J(nj,1,1) // initialize pj search index
    i0 = 0
    for (i=ni;i>i0;i--) {
        xy = iXY[i,]
        if (xy[1] < pj.xmin) continue // xy left of pj
        if (xy[1] > pj.xmax) continue // xy right of pj
        if (xy[2] < pj.ymin) continue // xy below pj
        if (xy[2] > pj.ymax) continue // xy above pj
        j = _geo_bshare_match(xy, jXY, J) // find match in pj
        if (!j) continue // no match found in pj
        tj[j] = 0 // mark point in pj as used
        l = _geo_bshare_path(i0, i, ni, pi.gt, iXY, j, nj, pj.gt, jXY, tj)
        _geo_bshare_add_brdr(B, id1, id2, i+(pi.gt==3), j+(pj.gt==3), l)
        J = selectindex(tj) // update pj search index
    }
}

`Int' _geo_bshare_match(`RR' xy, `RM' XY, `BoolC' J)
{   // find match of point in XY; use the last match in case of ties
    `Int' j
    
    if (!anyof(XY[J,1], xy[1])) return(0) // quick check in one dimension
    for (j=rows(J);j;j--) {
        if (xy==XY[J[j],]) return(J[j])
    }
    return(0)
}

`Int' _geo_bshare_path(`Int' i00, `Int' i, `Int' ni, `Int' gti, `RM' iXY,
    `Int' j, `Int' nj, `Int' gtj, `RM' jXY, `BoolC' tj)
{   // follow common path in item pi and item pj, starting from an initial match
    `Int' l, ii, i0, jj, j0, d

    // setup
    l = 1 // length is at least 1
    d = 0 // relative direction (-1 same, 0 not yet set, 1 opposite)
    // follow path downwards in item 2
    ii = i; jj = j
    __geo_bshare_path(l, min((i-1,j-1)), 0,ii,iXY, 0,jj,jXY, tj)
    j0 = jj // save start index of path in item 2
    if (jj==1 & gtj==3) { // wrap around if item 2 is polygon
        jj = nj + 1
        __geo_bshare_path(l, min((ii-1,nj+1-j)), 0,ii,iXY, 0,jj,jXY, tj)
        if (jj<=nj) j0 = jj // save start index of path in item 2
    }
    if (l>1) d = -1
    // follow path upwards in item 2 if downward search was not successful
    if (!d) {
        ii = i; jj = j
        __geo_bshare_path(l, min((i-1,nj-j)), 0,ii,iXY, 1,jj,jXY, tj)
        if (jj==nj & gtj==3) { // wrap around if item 2 is polygon
            jj = 0
            __geo_bshare_path(l, min((ii-1,j)), 0,ii,iXY, 1,jj,jXY, tj)
        }
        if (l>1) d = 1
    }
    if (i<ni | gti!=3) {; i = ii; j = j0; return(l); }
    // follow path upwards in item 1 (i.e. wrap around) if item 1 is polygon
    // and matching point is at end of item 1
    i0 = ii // save start index of path in item 1
    if (d<=0) { // follow path upwards in item 2
        ii = 0; jj = j
        __geo_bshare_path(l, min((i0,nj-j,nj+1-l)), 1,ii,iXY, 1,jj,jXY, tj)
        if (jj==nj & gtj==3) { // wrap around if item 2 is polygon
            jj = 0
            __geo_bshare_path(l, min((i0-ii,nj+1-l)), 1,ii,iXY, 1,jj,jXY, tj)
        }
        if (l>1) d = -1 // preserve direction if not yet set
    }
    if (d>=0) { // follow path downwards in item 2
        ii = 0; jj = j
        __geo_bshare_path(l, min((i0,j-1,nj+1-l)), 1,ii,iXY, 0,jj,jXY, tj)
        j0 = jj // save start index of path in item 2
        if (jj==1 & gtj==3) { // wrap around if item 2 is polygon
            jj = nj + 1
            __geo_bshare_path(l, min((i0-ii,nj+1-l)), 1,ii,iXY, 0,jj,jXY, tj)
            if (jj<=nj) j0 = jj // save start index of path in item 2
        }
    }
    if (ii>0) i00 = ii // update item 1 search range
    i = i0; j = j0     // return start indices
    return(l)          // return length of path (including first point)
}

void __geo_bshare_path(`Int' l, `Int' k, `Bool' iup, `Int' i, `RM' iXY,
    `Bool' jup, `Int' j, `RM' jXY, `BoolC' tj)
{   // follow path up or down
    // k = max possible remaining length of path in the specified direction
    if (iup) {
        if (jup) {
            for (;k;k--) {
                if (iXY[++i,]!=jXY[++j,]) {; i--; j--; break; }
                l++
                tj[j] = 0 // mark point in pj as used
            }
            return
        }
        for (;k;k--) {
            if (iXY[++i,]!=jXY[--j,]) {; i--; j++; break; }
            l++
            tj[j] = 0 // mark point in pj as used
        }
        return
    }
    if (jup) {
        for (;k;k--) {
            if (iXY[--i,]!=jXY[++j,]) {; i++; j--; break; }
            l++
            tj[j] = 0 // mark point in pj as used
        }
        return
    }
    for (;k;k--) {
        if (iXY[--i,]!=jXY[--j,]) {; i++; j++; break; }
        l++
        tj[j] = 0 // mark point in pj as used
    }
}

end

*! {smcl}
*! {marker geo_centroid}{bf:geo_centroid()}{asis}
*! version 1.0.4  28aug2024  Ben Jann
*!
*! Computes centroid of each unit. If a unit contains at least one polygon,
*! the formula for polygons is used (https://en.wikipedia.org/wiki/Centroid) and
*! lines and points in the unit will be ignored. Nested polygons within a unit
*! are assumed to switch orientation (so that "holes" will be deducted from the
*! total area of the unit). If a unit contains at least one line (but no 
*! polygons), the formula for lines will be used (weighted mean of midpoints of
*! line segments) and points in the unit will be ignored. If a unit only
*! contains points, the formula for points will be used (mean).
*!
*! geo_gtype() is used to classify the geometry items within a unit; polygons
*! and lines are assumed to start with missing.
*!
*!      result = geo_centroid(rtype, ID, XY)
*!
*!  rtype   results type: if rtype!=0 the result is a n x 2 matrix containing
*!          repeated centroids, else the result is a r x 3 matrix with ID in
*!          1st column and centroid coordinates in columns 2 and 3, where r is
*!          the number of units
*!  ID      n x 1 real colvector of unit IDs (or, possibly, scalar if single
*!          unit); rows are assumed to be grouped by unit ID
*!  XY      n x 2 real matrix of (X,Y) coordinates of the geometry items
*!

mata:
mata set matastrict on

real matrix geo_centroid(real scalar rtype, real colvector ID, real matrix XY)
{
    real scalar    i, n, a, b
    real colvector p
    real matrix    C
    
    if (cols(XY)!=2) {
        errprintf("{it:XY} must have two columns\n")
        exit(3200)
    }
    n = rows(XY)
    i = rows(ID)
    if (i!=1) {
        if (i!=n) exit(error(3200))
    }
    if (!n) return(J(0, 2 + !rtype, .)) // no data
    if (n==1) { // single obs
        C = editmissing(XY, .)
        if (rtype) return(C)
        else       return(ID, C)
    }
    if (rows(ID)==1) { // single unit
        p = 1
        C = _geo_centroid(XY)
    }
    else {
        p = selectindex(_mm_unique_tag(ID))
        i = rows(p)
        if (i==n) { // single obs in each unit
            C = editmissing(XY, .)
            if (rtype) return(C)
            else       return(ID, C)
        }
        C = J(i,2,.)
        a = n + 1
        for (;i;i--) {
            b = a - 1; a = p[i]
            C[i,] = _geo_centroid(XY[|a,1 \ b,.|])
        }
    }
    if (rtype) {
        i = rows(p)
        a = n + 1
        C = C \ J(n-i,2,.)
        for (;i;i--) {
            b = a - 1; a = p[i]
            C[|a,1 \ b,2|] = J(b-a+1, 1, C[i,])
        }
        return(C)
    }
    else return(ID[p], C)
}

real rowvector _geo_centroid(real matrix XY)
{
    real colvector g, cnt
    
    g = geo_gtype(3, ., geo_pid(., XY), XY, cnt=.)
    if (cnt[4]) { // centroid of polygons
        if (sum(cnt)==cnt[4]) return(__geo_centroid(1, XY))
        return(__geo_centroid(1, select(XY, g:==3)))
    }
    if (cnt[3]) { // centroid of lines
        if (sum(cnt)==cnt[3]) return(__geo_centroid(0, XY))
        return(__geo_centroid(0, select(XY, g:==2)))
    }
    if (cnt[2]) { // centroid of points
        if (sum(cnt)==cnt[2]) return(mean(XY))
        return(mean(select(XY, g:==1)))
    }
    return(J(1,2,.)) // all empty
}

real rowvector __geo_centroid(real scalar poly, real matrix XY)
{
    real scalar    A
    real colvector a
    real matrix    XY2
    
    if (rows(XY)<2) return(editmissing(XY, .))
    XY2 = XY[|2,1\.,.|] \ (.,.)
    // polygon
    if (poly) {
        a = quadrowsum((1,-1) :* XY :* XY2[,(2,1)])
        A = quadsum(a)
        if (A & A<.) return(quadcolsum(a :* (XY + XY2)) / (3 * A))
    }
    // line
    a = sqrt(quadrowsum((XY2 - XY):^2))
    A = quadsum(a)
    if (A & A<.) return(quadcolsum(a :* (XY + XY2)) / (2 * A))
    // point
    return(mean(XY))
}

end

*! {smcl}
*! {marker geo_circle_tangents}{bf:geo_circle_tangents()}{asis}
*! version 1.0.0  27jun2023  Ben Jann
*!
*! Returns the points of the external tangents connecting two circles, based on
*! https://en.wikipedia.org/wiki/Tangent_lines_to_circles
*!
*! Syntax:
*!
*!      points = geo_circle_tangents(circle1, circle2)
*!
*!  points   4 x 2 real matrix of the points; X in col 1, Y in col 2
*!           J(0,0,.) will be returned if the tangents do not exist
*!  circle1  real rowvector containing mid and radius (X,Y,R) of circle 1
*!  circle2  real rowvector containing mid and radius (X,Y,R) of circle 2
*!

local RS      real scalar
local Circle  real rowvector  // (X,Y,R)
local Points  real matrix     // (X,Y) \ (X,Y) \ ...

mata:
mata set matastrict on

`Points' geo_circle_tangents(`Circle' c1, `Circle' c2)
{
    `RS'     d, alpha1, alpha2, beta, gamma
    `Points' P
    
    d = sqrt((c2[1] - c1[1])^2 + (c2[2] - c1[2])^2)
    if (c1[3]>=(d+c2[3])) return(J(0,0,.)) // c1 covers c2
    if (c2[3]>=(d+c1[3])) return(J(0,0,.)) // c2 covers c1
    if (c1[1]<c2[1])  beta  =  asin((c2[3] - c1[3]) / d)
    else              beta  = -asin((c2[3] - c1[3]) / d)
    if (c1[1]==c2[1]) gamma =   sign(c2[2] - c1[2]) * pi()/2
    else              gamma = -atan((c2[2] - c1[2]) / (c2[1] - c1[1]))
    alpha1 = gamma - beta
    alpha2 = gamma + beta
    P      = (c1[1] + c1[3] * sin(alpha1), c1[2] + c1[3] * cos(alpha1)) \
             (c2[1] + c2[3] * sin(alpha1), c2[2] + c2[3] * cos(alpha1)) \
             (c1[1] - c1[3] * sin(alpha2), c1[2] - c1[3] * cos(alpha2)) \
             (c2[1] - c2[3] * sin(alpha2), c2[2] - c2[3] * cos(alpha2))
    return(P)
}

end

*! {smcl}
*! {marker geo_clip}{bf:geo_clip()}{asis}
*! version 1.0.5  05feb2025  Ben Jann
*!
*! Clips or selects shape items by a convex mask; a modified Sutherland–Hodgman
*! algorithm is used for clipping (returning divided polygons if appropriate);
*! see https://en.wikipedia.org/wiki/Sutherland%E2%80%93Hodgman_algorithm
*!
*! geo_pid() is used to identify shape items; polygons and lines are assumed
*! to start with missing
*!
*! Syntax:
*!
*!      result = geo_clip(XY, mask [, method])
*!
*!  result   coordinates of clipped/selected shapes
*!  XY       n x 2 real matrix containing the (X,Y) coordinates of the shape
*!           to be clipped or selected
*!  mask     n x 2 real matrix containing the (X,Y) coordinates of the convex
*!           clipping mask; invalid results will be returned if the clipping
*!           mask is not convex
*!  method   real scalar setting the method:
*!           0 = regular clipping
*!           1 = enforce line clipping (i.e., do not close the clipped polygons)
*!           2 = apply selection rather than clipping; shape items with at least
*!               one point inside the mask will be retained, all other items
*!               will be removed
*!           3 = like 2, but an item will only be retained if all points of the
*!               item are inside the mask
*!           4 = like 2, but all items will be retained if at least one item has
*!               a point inside the mask; else all items will be removed
*!           5 = like 3, but all items will be removed if at least one item has
*!               a point outside the mask, else all items will be retained
*!           default is 0; values other than the ones above are treated as 0
*!
*! In case of a rectangular mask, you can also use the following function:
*!
*!      result = geo_rclip(XY, limits [, method])
*!
*!  limits   vector specifying the clipping limits: (Xmin, Xmax, Ymin, Ymax)
*!           (missing will be interpreted as +/- infinity)
*!
*!  other arguments as for geo_clip()
*!

local Bool      real scalar
local BoolC     real colvector
local Int       real scalar
local IntC      real colvector
local IntM      real matrix
local RS        real scalar
local RC        real colvector
local RR        real rowvector
local RM        real matrix
local SS        string scalar
local PS        pointer scalar
local PC        pointer colvector

mata:
mata set matastrict on

`RM' geo_clip(`RM' XY, `RM' mask, | `Int' method)
{
    return(_geo_clip_or_select(XY, _geo_clip_mask(mask), method))
}

`RM' _geo_clip_mask(`RM' mask0, | `SS' nm)
{
    `RM' mask
    
    if (args()<2) nm = "mask"
    if (cols(mask0)!=2) {
        errprintf("{it:%s} must have two columns\n", nm)
        exit(3200)
    }
    mask = select(mask0, !rowmissing(mask0))
    if (rows(mask)) {
        mask = mask \ mask[1,]    // wrap around
        mask = _mm_uniqrows(mask) // remove repetitions
    }
    if (rows(mask)<3) {
        errprintf("{it:%s} must contain at least two unique points\n", nm)
        exit(3200)
    }
    if (geo_orientation(mask)==-1) {
        mask = mask[1::rows(mask),] // make counterclockwise
    }
    return(mask)
}

`RM' geo_rclip(`RM' XY, `RM' limits, | `Int' method)
{
    return(_geo_clip_or_select(XY, _geo_rclip_limits(limits), method))
}

`RC' _geo_rclip_limits(`RM' limits)
{
    `RC' mask
 
    mask = vec(limits)
    if (length(mask)<4) mask = mask \ J(4-length(mask),1,.)
    return(mask)
}

`RM' _geo_clip_or_select(`RM' XY, `RM' mask, `Int' method, | `Bool' map)
{   // map will be replaced by an r x 4 matrix of input and output indices; each
    // row contains (a0,b0,a1,b1) where (a0,b0) are the start and end indices of
    // the original item in XY and (a1,b1) are the start and end indices of the
    // transformed item (or set of items) in the output; a1>b1 for dropped items
    if (args()<4) map = 0
    if (cols(XY)!=2) {
        errprintf("{it:XY} must have two columns\n")
        exit(3200)
    }
    if (anyof((2,3,4,5), method)) return(_geo_select(XY, mask, method, map))
    return(_geo_clip(XY, mask, method==1, map))
}

`RM' _geo_select(`RM' XY, `RM' mask, `Int' method, `Bool' map)
{
    `Int'   i, n, a, b
    `IntC'  p
    `BoolC' I
    
    // identify shape items
    n = rows(XY)
    p = selectindex(_mm_unique_tag(geo_pid(., XY)))
    i = rows(p)
    // handle all items together if point data
    if (i==n) {
        if (cols(mask)==1) I = __geo_rclip_point(XY, mask)
        else               I =  __geo_clip_point(XY, mask)
    }
    // else loop over items
    else {
        I = J(n, 1, .)
        a = n + 1
        for (;i;i--) {
            b = a - 1; a = p[i]
            I[|a\b|] = __geo_select(XY, a, b, mask, method)
        }
    }
    // select items
    if (method==4 | method==5) {
        if (method==4 ? any(I) : all(I)) { // at least one inside / all inside
            if (map) map = J(1,2,(p, (p:-1\n)[|2\.|]))
            return(XY)
        }
        else { // else drop all
            if (map) map = p, (p:-1\n)[|2\.|], J(rows(p),2,.)
            return(J(0, 2, .))
        }
    }
    if (map) map = _geo_select_map(p, I)
    return(select(XY, I))
}

`IntM' _geo_select_map(`IntC' p, `BoolC' I)
{
    `Int'  i, a, b, r
    `IntM' map
    
    i = rows(p)
    map = J(i, 4, .)
    a = rows(I) + 1
    r = 0
    for (;i;i--) {
        map[i,2] = b = a - 1
        map[i,1] = a = p[i]
        map[i,4] = r + 1
        r = r + sum(I[|a\b|])
        map[i,3] = r
    }
    map[,(3,4)] = (r+1) :- map[,(3,4)]
    return(map)
}

`BoolC' __geo_select(`RM' XY, `Int' a, `Int' b, `RM' mask, `Int' method)
{   // first row in XY assumed missing
    `BoolC' I

    if (b<=a)               I = J(0,1,.) // empty shape item
    else if (cols(mask)==1) I = __geo_rclip_point(XY[|a+1,1\b,.|], mask)
    else                    I =  __geo_clip_point(XY[|a+1,1\b,.|], mask)
    if (method==2) {
        if (any(I)) return(J(b-a+1,1,1)) // at least one point inside
        else        return(J(b-a+1,1,0)) // else drop all
    }
    if (method==3) {
        if (all(I)) return(J(b-a+1,1,1)) // all points inside
        else        return(J(b-a+1,1,0)) // else drop all
    }
    if (any(I)) return(1 \ I)
    else        return(0 \ I)
}

`RM' _geo_clip(`RM' XY, `RM' mask, `Bool' line, `Bool' map)
{
    `Int'   i, a, b, r
    `IntC'  p
    `IntM'  M
    `RM'    xy
    `PC'    I
    
    // identify shape items
    p = selectindex(_mm_unique_tag(geo_pid(., XY)))
    i = rows(p)
    // handle all items together if point data
    if (i==rows(XY)) return(_geo_clip_point(XY, mask, map))
    // else loop over items ...
    r = 0
    I = J(i, 1, NULL)
    M = J(i, 4, .)
    a = rows(XY) + 1
    for (;i;i--) {
        M[i,2] = b = a - 1; M[i,1] = a = p[i]
        I[i] = &__geo_clip(XY, a, b, mask, line)
        M[i,4] = r + 1
        r = r + rows(*I[i])
        M[i,3] = r
    }
    M[,(3,4)] = (r+1) :- M[,(3,4)]
    // ... and collect results
    xy = J(r, 2, .)
    for (i=length(I);i;i--) {
        a = M[i,3]; b = M[i,4]
        if (a>b) continue // empty item
        xy[|a,1 \ b,.|] = *I[i]
    }
    if (map) map = M
    return(xy)
}

`RM' __geo_clip(`RM' XY, `Int' a, `Int' b, `RM' mask, `Bool' line)
{   // first row in XY assumed missing; XY assumed to have two columns
    `Bool' flip
    `Int'  r, i, n
    `RM'   xy
    `PS'   f

    r = b - a + 1
    // point item
    if (r<=2) {
        if (r<2) return(J(0,2,.)) // empty shape item
        xy = _geo_clip_point(XY[|a+1,1 \ b,.|], mask, 0)
        if (rows(xy)) return(XY[a,] \ xy)
        return(J(0,2,.))
    }
    // polygon item
    xy = XY[|a,1 \ b,.|]
    if (xy[2,]==xy[r,]) {
        if (line) {
            // rearrange points so that polygon does not start inside
            if (_geo_clip_larrange(xy, mask)) return(xy) // all points inside
            // enforce line clipping
            f = &_geo_clip_line()
            flip = 0
        }
        else {
            f = &_geo_clip_area()
            flip = geo_orientation(xy)==1        // is counterclockwise
            if (flip) xy = J(1,2,.) \ xy[r::2,.] // flip orientation
        }
    }
    // line item
    else { 
        f = &_geo_clip_line()
        flip = 0
    }
    // rectangular clipping
    if (cols(mask)==1) {
        if (mask[1]<.) { // xmin
            xy = (*f)(xy, mask[1])
        }
        if (mask[3]<.) { // ymin (-90° rotation)
            xy = (*f)((xy[,2], -xy[,1]), mask[3])
            xy = (-xy[,2], xy[,1])
        }
        if (mask[2]<.) { // xmax (-180° rotation)
            xy = -(*f)(-xy, -mask[2])
        }
        if (mask[4]<.) { // ymax (-270° rotation)
            xy = (*f)((-xy[,2], xy[,1]), -mask[4])
            xy = (xy[,2], -xy[,1])
        }
    }
    // convex clipping
    else {
        n = rows(mask)
        for (i=1;i<n;i++) xy = (*f)(xy, mask[|i,1 \ i+1,2|])
    }
    // restore orientation
    if (flip) {
        r = rows(xy)
        if (r) xy = J(1,2,.) \ xy[r::2,.] 
    }
    // return
    return(xy)
}

`RM' _geo_clip_point(`RM' XY, `RM' mask, `Bool' map)
{
    `Int'   n
    `BoolC' I
    `IntC'  b1
    
    if (cols(mask)==1) I = __geo_rclip_point(XY, mask)
    else               I =  __geo_clip_point(XY, mask)
    if (map) {
        n = rows(I)
        b1 = runningsum(I)
        map = J(1,2,1::n), (1 \ b1:+1)[|1\n|], b1
    }
    return(select(XY, I))
}

`BoolC' __geo_rclip_point(`RM' XY, `RC' mask)
{
    `RC' in

    in = J(rows(XY),1,1)
    if (mask[1]<.) in = in :& (_geo_clip_outside(XY, mask[1]):<=0)
    if (mask[3]<.) in = in :& (_geo_clip_outside(XY[,(2,1)], mask[3]):<=0)
    if (mask[2]<.) in = in :& (-_geo_clip_outside(XY, mask[2]):<=0)
    if (mask[4]<.) in = in :& (-_geo_clip_outside(XY[,(2,1)], mask[4]):<=0)
    return(in)
}

`BoolC' __geo_clip_point(`RM' XY, `RM' mask)
{
    `Int' i, n
    `RC'  in

    in = J(rows(XY),1,1)
    n = rows(mask)
    for (i=1;i<n;i++) {
        in = in :& (_geo_clip_outside(XY, mask[|i,1 \ i+1,2|]):<=0)
    }
    return(in)
}

`Bool' _geo_clip_larrange(`RM' XY, `RM' mask)
{
    `Int'  i, n
    
    if (cols(mask)==1) { // rclip
        if (_geo_rclip_larrange(XY, mask[1], 1, 0)) return(0)
        if (_geo_rclip_larrange(XY, mask[3], 2, 0)) return(0)
        if (_geo_rclip_larrange(XY, mask[2], 1, 1)) return(0)
        if (_geo_rclip_larrange(XY, mask[4], 2, 1)) return(0)
    }
    else {
        n = rows(mask)
        for (i=1;i<n;i++) {
            if (__geo_clip_larrange(XY,
                _geo_clip_outside(XY, mask[|i,1 \ i+1,2|]))) return(0)
        }
    }
    return(1) // all points are inside
}

`Bool' _geo_rclip_larrange(`RM' XY, `RS' c, `Int' j, `Bool' neg)
{
    `IntC' out
    
    if (c>=.) return(0)
    if (neg) out = XY[,j] :> c
    else     out = XY[,j] :< c
    return(__geo_clip_larrange(XY, out))
}

`Bool' __geo_clip_larrange(`RM' XY, `IntC' out)
{
    `Int'  i, n

    n = rows(out)
    for (i=2;i<=n;i++) {
        if (out[i]==1) {
            if (i>2) XY = XY[1,] \ XY[|i,1 \ .,.|] \ XY[|3,1 \ i,.|]
            return(1)
        }
    }
    return(0)
}

`RM' _geo_clip_line(`RM' XY, `RM' c)
{   // first point assumed missing
    `Int'  i, j
    `IntC' out
    `RM'   xy
    
    // checks
    i = rows(XY)
    if (i<2) return(J(0,2,.)) // empty input
    out = _geo_clip_outside(XY, c)
    if (!anyof(out,1)) return(XY) // all points inside
    if (!any(out:<=0)) return(J(0,2,.)) // all points outside
    // apply clipping
    j = 2 * i
    xy = J(j++, 2, .)
    for (;i;i--) {
        if (out[i]>0) { // point is outside or missing
            if (out[i]>=.) continue // skip point if missing
            for (--i;i;i--) { // find first inside point or end of path
                if (out[i]<=0) { // inside point found
                    if (out[i]) // add point on edge
                        xy[--j,] = _geo_clip_intersect(c, XY[i+1,], XY[i,])
                    i++ // move back one point
                    break
                }
                if (out[i]>=.) break // end of path
            }
        }
        else { // point is inside
            xy[--j,] = XY[i,] // add inside point
            for (--i;i;i--) { // find first outside point or end of path
                if (out[i]<=0) { // point is inside
                    xy[--j,] = XY[i,] // add inside point
                    continue
                }
                // point is outside or missing (end of path)
                if (out[i]==1) { // point is outside
                    i++ // move back one point
                    if (out[i]) // add point on edge
                        xy[--j,] = _geo_clip_intersect(c, XY[i,], XY[i-1,])
                }
                break
            }
            j-- // add missing (terminate path)
        }
    }
    // return
    return(xy[|j,1 \ .,.|])
}

`RM' _geo_clip_area(`RM' XY, `RM' c)
{   // first point assumed missing
    `Int'   i, j
    `Bool'  hasentr
    `BoolC' isentr
    `IntC'  out
    `RM'    xy
    
    // checks
    i = rows(XY)
    if (i<2) return(J(0,2,.)) // empty input
    out = _geo_clip_outside(XY, c)
    if (!anyof(out,1)) return(XY) // all points inside
    if (!any(out:<=0)) return(J(0,2,.)) // all points outside
    _geo_clip_area_arrange(XY, out)
    // apply clipping
    j = 2 * i
    isentr = J(j, 1, 0)
    hasentr = 0
    xy = J(j++, 2, .)
    for (;i;i--) {
        if (out[i]>0) { // point is outside or missing
            if (out[i]>=.) continue // skip point if missing
            for (--i;i;i--) { // find first inside point or end of path
                if (out[i]<=0) { // inside point found
                    if (out[i]) { // add point on edge; this is the entry point
                        xy[--j,] = _geo_clip_intersect(c, XY[i+1,], XY[i,])
                        isentr[j] = 1
                    }
                    else isentr[j-1] = 1 // next point is the entry point
                    i++ // move back one point
                    hasentr = 1
                    break
                }
                if (out[i]>=.) break // end of path
            }
        }
        else { // point is inside
            xy[--j,]  = XY[i,] // add inside point
            for (--i;i;i--) { // find first outside point or end of path
                if (out[i]<=0) { // point is inside
                    xy[--j,]  = XY[i,] // add inside point
                    continue
                }
                // point is outside or missing (end of path)
                if (out[i]==1) { // point is outside
                    i++ // move back one point
                    if (out[i]) { // add point on edge
                        xy[--j,]  = _geo_clip_intersect(c, XY[i,], XY[i-1,])
                    }
                }
                break
            }
            isentr[--j] = . // add missing (terminate path)
        }
    }
    // return
    xy = xy[|j,1 \ .,.|]
    if (hasentr) xy = _geo_clip_area_join(xy, c, isentr[|j \. |])
    return(xy)
}

void _geo_clip_area_arrange(`RM' XY, `IntC' out)
{   // rearrange points so that each path starts with an outside point
    // (unless the path is fully inside)
    `Int' i, j, i1
    
    i = rows(out)
    for (;i;i--) {
        i1 = i
        for (;i;i--) {
            if (out[i]>=.) break // end of path
            if (out[i]==1) {
                j = i
                for (--i;i;i--) {
                    if (out[i]>=.) break // end of path
                }
                if (j<i1 & j>(i+1)) {
                    out[|i\i1|] = out[i] \ out[|j\i1|] \ out[|i+2\j|]
                    XY[|i,1\i1,.|] = XY[i,] \ XY[|j,1\i1,.|] \ XY[|i+2,1\j,.|]
                }
                break
            }
        }
    }
}

`RM' _geo_clip_area_join(`RM' XY, `RM' c, `BoolC' isentr)
{   // join pieces of paths crossing the boundary and close the polygons
    `Int' j, j1, k, K, i
    `RC'  yin, yout
    `RM'  ab
    `Int' p
    
    K = sum(isentr:==1)
    ab = J(K,4,.)
    j = rows(XY)
    p = J(j + K, 1, .)
    k = 0
    i = 1
    for (;j;j--) {
        j1 = j--
        while (isentr[j]<.) j--
        if (isentr[j1]==0) { // path is completely inside
            p[|i \ i + j1 - j|] = j::j1
            i = i + j1 - j + 1
            continue
        }
        ab[++k,] = 
            j, j1, _geo_clip_clpos(c, XY[j+1,]), _geo_clip_clpos(c, XY[j1,])
    }
    _sort(ab, -3)
    //_sort(ab, -3)
    while (1) {
        p[|i \ i + ab[1,2] - ab[1,1]|] = ab[1,1]::ab[1,2]
        i = i + ab[1,2] - ab[1,1] + 1
        yin  = ab[1,3]
        //yin  = ab[1,3]
        yout = ab[1,4]
        //yout = ab[1,4]
        while (1) {
            K = rows(ab)
            for (k=K;k>1;k--) {
                if (ab[k,3]>=ab[k,4]) continue // wrong orientation
                //if (ab[k,3]>=ab[k,4]) continue // wrong orientation
                if (ab[k,3]<yout | ab[k,3]>yin) continue // above or below 
                //if (ab[k,3]<yout | ab[k,3]>yin) continue // above or below 
                p[|i \ i + ab[k,2] - ab[k,1] - 1|] = (ab[k,1]+1)::ab[k,2]
                i = i + ab[k,2] - ab[k,1] // (missing is skipped)
                yout = ab[k,4]
                //yout = ab[k,4]
                ab = select(ab, (1::K):!=k)
                break
            }
            if (k<2) break
        }
        p[i++] = ab[1,1] + 1 // close polygon
        if (K==1) break
        ab = ab[|2,1 \ .,.|]
    }
    return(XY[p[|1 \ i-1|],])
}

`IntC' _geo_clip_outside(`RM' XY, `RM' c)
{   // result: 1 outside, -1 inside, 0 on edge, . missing
    if (length(c)==1) {
        // c is the lower limit of X; point is outside if x-value < c
        // (additionally make sure that missing if y-value is missing)
        return(sign(c :- XY[,1]) :* XY[,2]:^0)
    }
    // c is and edge: c = p1 \ p2 with p1 = (x1,y1) and p2 = (x2,x2)
    // check whether path p1 -> p2 -> XY[i,] turns left (inside)
    // or right (outside)
    return(sign((XY[,1] :- c[1,1]) * (c[2,2] - c[1,2])
              - (XY[,2] :- c[1,2]) * (c[2,1] - c[1,1])))
}

`RR' _geo_clip_intersect(`RM' c, `RR' p1, `RR' p2)
{   // obtain intersection between two lines
    // https://en.wikipedia.org/wiki/Line%E2%80%93line_intersection
    if (length(c)==1) {
        // c is the lower limit of X; compute y at which p1->p2 crosses c
        return((c, p1[2] + (p2[2]-p1[2]) * (c-p1[1]) / (p2[1]-p1[1])))
    }
    return(((c[1,1] * c[2,2] - c[1,2] * c[2,1]) :* (p1    - p2)
          - (p1[1]  * p2[2]  - p1[2]  * p2[1])  :* (c[1,] - c[2,]))
        / ((c[1,1]-c[2,1])*(p1[2]-p2[2]) - (c[1,2]-c[2,2])*(p1[1]-p2[1])))
}

`RS' _geo_clip_clpos(`RM' c, `RR' p)
{   // obtain position of point along clipping line
    real scalar r
    
    if (length(c)==1) return(p[2]) // c is the lower limit of X
    // rotate system
    r = atan2(c[2,2]-c[1,2], c[2,1]-c[1,1]) - pi()
    return(p[1]*sin(r) + p[2]*cos(r))
}

end

*! {smcl}
*! {marker geo_gtype}{bf:geo_gtype()}{asis}
*! version 1.0.0  28dec2023  Ben Jann
*!
*! Determine geometry types
*!
*! Syntax:
*!
*!      result = geo_gtype(rtype, ID, PID, XY [, count])
*!
*!  rtype   results type: if rtype==0 the result is a r x 3 matrix with ID in
*!          1st column, PID in 2nd column, and geometry type in 3rd column
*!          (0 = empty, 1 = Point, 2 = LineString, 3 = Polygon), where r is the
*!          total number of polygons; if rtype==1 the result is an n x 1 
*!          colvector containing repeated geometry type values; if rtype==2 the
*!          result is a 4 x 1 colvector of geometry type counts (number of
*!          empty items, points, lines, polygons); if rtype==3, result is the
*!          same as in rtype==1, but optional argument count will be filled in
*!          with type counts
*!  ID      n x 1 real colvector of unit IDs (or, possibly, scalar if single
*!          unit); rows are assumed to be grouped by unit ID
*!  PID     n x 1 real colvector of within-unit geometry-item IDs
*!  XY      n x 2 matrix of (X,Y) coordinates of the geometry items

mata:
mata set matastrict on

real matrix geo_gtype(real scalar rtype, real colvector ID,
    real colvector PID, real matrix XY, | transmorphic cnt)
{
    real scalar    i, n, a, b, r
    real colvector p, GT
    
    // check conformability
    if (cols(XY)!=2) {
        errprintf("{it:XY} must have two columns\n")
        exit(3200)
    }
    n = rows(XY)
    i = rows(ID)
    if (n!=i & i!=1)  exit(error(3200))
    if (n!=rows(PID)) exit(error(3200))
    if (n==0) { // no data
        if (rtype==0) return(J(0,3,.))
        if (rtype==1) return(J(0,1,.))
        if (rtype==2) return(J(4,1,0))
        if (rtype==3) {; cnt = J(4,1,0); return(J(0,1,.)); }
        _geo_rtype_err(0..3)
    }
    // determine geometry types
    if (i==1) p = selectindex(_mm_unique_tag(PID))
    else      p = selectindex(_mm_uniqrows_tag((ID,PID)))
    i = rows(p)
    a = n + 1
    if (rtype==0) {
        GT = J(i,1,.)
        for (;i;i--) {
            b = a - 1; a = p[i]
            GT[i] = _geo_gtype(XY, a, b)
        }
        if (rows(ID)==1) return(J(rows(GT),1,ID), PID[p], GT)
        return(ID[p], PID[p], GT)
    }
    if (rtype==1) {
        GT = J(n,1,.)
        for (;i;i--) {
            b = a - 1; a = p[i]
            GT[|a \ b|] = J(b - a + 1, 1, _geo_gtype(XY, a, b))
        }
        return(GT)
    }
    if (rtype==2) {
        GT = J(4,1,0)
        for (;i;i--) {
            b = a - 1; a = p[i]
            r = _geo_gtype(XY, a, b) + 1
            GT[r] = GT[r] + 1
        }
        return(GT)
    }
    if (rtype==3) {
        cnt = J(4,1,0)
        GT = J(n,1,.)
        for (;i;i--) {
            b = a - 1; a = p[i]
            r = _geo_gtype(XY, a, b) + 1
            cnt[r] = cnt[r] + 1
            GT[|a \ b|] = J(b - a + 1, 1, r-1)
        }
        return(GT)
    }
    _geo_rtype_err(0..3)
}

real scalar _geo_gtype(real matrix XY, real scalar a, real scalar b)
{
    real scalar r
    
    r = b - a + 1
    if (r==1) {
        if (missing(XY[a,])==2) return(0)  // empty
        return(1)                          // point
    }
    if (r==2) return(1)                    // point
    if (r>=5) {
        if (XY[a+1,]==XY[b,]) return(3)    // polygon
        return(2)                          // line
    }
    return(2)                              // line
}

void _geo_rtype_err(real rowvector v)
{
    errprintf("{it:rtype} must be in {%s}\n", invtokens(strofreal(v),","))
    exit(3300)
}

end

*! {smcl}
*! {marker geo_hull}{bf:geo_hull()}{asis}
*! version 1.0.3  16jul2024  Ben Jann
*!
*! Determine convex hull around cloud of points using Graham scan; based on
*! https://en.wikipedia.org/wiki/Graham_scan and
*! https://www.geeksforgeeks.org/convex-hull-using-graham-scan/
*!
*! Syntax:
*!
*!      result = geo_hull(XY)
*!
*!  result  real matrix containing (X,Y) of convex hull (counterclockwise)
*!  XY      n x 2 real matrix containing the points; rows containing missing
*!          will be ignored
*!

mata
mata set matastrict on

real matrix geo_hull(real matrix XY)
{
    if (cols(XY)!=2) {
        errprintf("{it:XY} must have two columns\n")
        exit(3200)
    }
    if (!hasmissing(XY)) return(_geo_hull(XY))
    return(_geo_hull(select(XY, !rowmissing(XY))))
}

real matrix _geo_hull(real matrix XY)
{
    real scalar    i0, i, j, n
    real colvector p, s
    
    n  = rows(XY)
    if (n==0) return(J(0,2,.))  // no data
    if (n==1) return(XY)        // only one point
    // get reference point
    i0 = _geo_hull_refpoint(XY)
    // obtain counterclockwise order of remaining points along half-circle
    p  = _geo_hull_order(XY, i0)
    // obtain convex hull
    n  = length(p)
    if (n<3) return(XY[(i0\p\i0),]) // 3 points or less
    s = J(n+1,1,.) // initialize stack
    s[(1,2,3)] = i0 \ p[1] \p[2]; j = 3 // first three points
    for (i=3;i<=n;i++) {
        while (1) {
            if (j<2) break
            if (_geo_hull_leftturn(XY[s[j-1],], XY[s[j],], XY[p[i],])) break
            j--
        }
        j++
        s[j] = p[i]
    }
    p = s[|1\j|] \ i0
    return(XY[p,])
}

real scalar _geo_hull_refpoint(real matrix XY)
{   // get index of point with lowest Y (and lowest X within ties)
    real colvector i, j
    real matrix    w
    
    i = j = w = .
    minindex(XY[,2], 1, i, w)
    if (length(i)==1) return(i)
    minindex(XY[i,1], 1, j, w)
    return(i[j[1]])
}

real colvector _geo_hull_order(real matrix XY, real scalar i0)
{
    real colvector p, dx, dy, q, a, d
    
    p = 1::rows(XY) // initialize permutation vector
    dx = XY[,1] :- XY[i0,1] // X distance to point i0
    dy = XY[,2] :- XY[i0,2] // Y distance to point i0
    p = select(p, !(dx:==0 :& dy:==0)) // remove point i0 and its duplicates
    if (length(p)==0) return(J(0,1,.)) // no remaining points
    q = sign(dx) // 1 = 1st quadrant, -1 = 2nd quadrant, 0 = on vertical edge
    a = dy :/ dx // order of "angle"; positive in 1st, negative in 2nd quadrant
    _geo_hull_editmin(a, q) // replace missing in 2nd quadrant by mindouble()
    d = dx:^2 + dy:^2 // (squared) distance from point i0
    // sort points by angle and distance with respect to point i0
    _collate(p, order((q,a,d)[p,], (-1,2,3)))
    // ties in angle: keep point with largest distance to point i0
    return(p[selectindex(_mm_uniqrows_tag((q,a)[p,], 1))])
}

void _geo_hull_editmin(real colvector a, real colvector q)
{
    real colvector p
    
    p = selectindex(a:>=. :& q:<0)
    if (length(p)) a[p] = J(length(p), 1, mindouble())
}

real scalar _geo_hull_leftturn(real rowvector p1, real rowvector p2,
    real rowvector p3)
{
    real scalar d
    
    d = (p2[2] - p1[2]) * (p3[1] - p2[1]) - (p2[1] - p1[1]) * (p3[2] - p2[2])
    return(d<0)
}

end

*! {smcl}
*! {marker geo_inpoly}{bf:geo_inpoly()}{asis}
*! version 1.0.0  03aug2025  Ben Jann
*!
*! Spatially joins the points in xy to the shapes in XY. Results are equivalent
*! to the ones from geo_spjoin(), but geo_inpoly() is much more efficient.
*! 
*! geo_inpoly() is based on geoinpoly.ado by Robert Picard; see
*! -ssc describe geoinpoly-
*!
*! Syntax:
*!
*!      result = geo_inpoly(xy, ID, XY [, mtype, nodots, expand])
*!
*!  result  r x 2 matrix containing matched IDs in 1st column and matching
*!          flags in 2nd column (0 = no match, 1 = strictly inside, 2 = on edge
*!          between two vertices, 3 = on vertex)
*!  xy      r x 2 matrix containing points to be matched
*!  ID      n x 1 real colvector of unit IDs
*!  XY      n x 2 real matrix of (X,Y) coordinates of the shapes
*!  mtype   restricts the type matches to be considered: 1 = strictly inside,
*!          2 = on border (edge or vertex), 3 = on vertex; all type of matches
*!          are considered if mtype is omitted or set to any other value
*!  nodots  nodots!=0 suppresses progress dots
*!  expand  changes how multiple matches are handled; by default, if a point
*!          matches multiple shapes, only the first match will be reported;
*!          alternatively, if argument expand is provided, all matches will be
*!          listed, expanding the number of rows in result; furthermore,
*!          expand will be replaced by a r x 1 colvector indicating for each
*!          point the number of rows included in result (1 row if a point has
*!          no match, m rows if a point has m matches)
*!
*! geo_pid() and geo_gtype() are used to identify and classify the shape items
*! in XY; polygons and lines are assumed to start with missing
*!

local Bool    real scalar
local BoolC   real colvector
local Int     real scalar
local IntC    real colvector
local IntR    real rowvector
local IntM    real matrix
local RC      real colvector
local RR      real rowvector
local RM      real matrix
local PS      pointer scalar
local PC      pointer colvector
local SLICE   _geo_inpoly_slice
local Slice   struct `SLICE' scalar
local PSlice  pointer (`Slice') scalar
local PSlices pointer (`Slice') rowvector
local STACK   _geo_inpoly_stack
local Stack   struct `STACK' scalar

mata:
mata set matastrict on

`RM' geo_inpoly(`RM' xy, `RC' ID, `RM' XY, | `Int' mtyp, `Bool' nodots,
    transmorphic E)
{
    `Bool' expand, mmsg
    `Int'  i, j, m, mtype
    `RR'   r
    `PC'   R
    `RM'   M 
    
    expand = (args()==6)
    if (args()<5) nodots = 0
    if (anyof((1,2,3), mtyp)) mtype = mtyp
    else                      mtype = 0
    if (cols(xy)!=2) {
        errprintf("{it:XY} must have two columns\n")
        exit(3200)
    }
    if (cols(XY)!=2) {
        errprintf("{it:XY} must have two columns\n")
        exit(3200)
    }
    if (rows(ID)!=rows(XY)) {
        errprintf("{it:ID} and {it:XY} must have the same number of rows\n")
        exit(3200)
    }
    R = _geo_inpoly(xy, ID, XY, nodots)
    i = rows(xy)
    if (expand) {
        E = J(i, 1, 1)
        for (; i; i--) {
            if (R[i]==NULL) continue
            r = *R[i]
            if (mtype) {
                if (mtype==2) r = select(r, r[,2]:==2 :| r[,2]:==3)
                else          r = select(r, r[,2]:==mtype)
            }
            m = rows(r)
            if (m) E[i] = m
        }
        j = sum(E)
        i = rows(xy)
    }
    else j = i
    mmsg = 0
    M = J(j,1,.), J(j, 1, 0) // second column: 0 if no match
    for (; i; i--) {
        if (R[i]==NULL) {; j--; continue; }
        r = *R[i]
        if (mtype) {
            if (mtype==2) r = select(r, r[,2]:==2 :| r[,2]:==3)
            else          r = select(r, r[,2]:==mtype)
            m = rows(r)
            if (!m) {; j--; continue; }
        }
        else m = rows(r)
        if (expand) {
            M[|j-m+1,1 \ j,.|] = r
            j = j - m
        }
        else {
            if (m>1) mmsg = 1
            M[j--,] = r[1,] // using first match
        }
    }
    if (mmsg) display("{txt}(multiple matches found for at least on point;" +
        " using first match only)")
    return(M)
}

struct `SLICE' {
    `RM' xy  // selected points in slice (x, y, id)
    `RM' E   // selected edges in slice
}

struct `STACK' {
    `Int'     n, N  // current and overall length of stack
    `PSlices' S     // stack of slices
}

`PSlice' _geo_inpoly_stack_pop(`Stack' stack)
{
    `PSlice' s
    
    s = stack.S[stack.n]
    stack.n = stack.n - 1
    return(s)
}

void _geo_inpoly_stack_append(`Stack' stack, `PSlice' s)
{
    stack.n = stack.n + 1
    if (stack.n > stack.N) {
        stack.S = stack.S, J(1,100,NULL)
        stack.N = stack.N + 100
    }
    stack.S[stack.n] = s
}

`PC' _geo_inpoly(`RM' xy, `RC' ID, `RM' XY, `Bool' nodots)
{   /* the function returns a rows(xy) x 1 pointer vector; elements are set to
       NULL for unmatched points or else to a pointer to an m x 2 matrix with
       the IDs of the matched shapes in the first column and corresponding
       matching flags in the second column (1 = strictly inside, 2 = on edge,
       but not on vertex, 3 = on vertex); same pointer is use for duplicates */
    `Int'    r, dj, di, dn
    `BoolC'  t
    `IntC'   p
    `PC'     R
    `PSlice' s, s1
    `Stack'  stack

    if (!rows(xy)) return(J(0,1,NULL))
    if (!rows(XY)) return(J(rows(xy),1,NULL))
    if (!nodots) di = 0
    // sort xy by y and tag unique points
    p = order(xy,2)
    t = _mm_uniqrows_tag(xy[p,], 1) // (tag last)
    // initialize stack
    s = &(`SLICE'())
    stack.n = stack.N = 0
    s->xy = _geo_inpoly_dropoutside(select((xy, (1::rows(xy)))[p,], t), XY)
    _geo_inpoly_setslice(stack, s, _geo_inpoly_edgelist(ID, XY), di)
    // recursively slice and process data
    if (!nodots) {
        displayas("txt")
        dj = _geo_progress_init("(")
        dn = rows(s->xy)
    }
    R = J(rows(xy), 1, NULL)
    while (stack.n) {
        s = _geo_inpoly_stack_pop(stack)
        r = rows(s->xy)
        if (r < 10) { // process slice
            _geo_inpoly_process(R, s->xy, s->E)
            if (!nodots) {
                di = di + rows(s->xy)
                _geo_progress(dj, di/dn)
            }
            continue
        }
        // continue dividing
        r = trunc(r / 2)
        s1 = &(`SLICE'())
        s1->xy = s->xy[|r+1,1 \ .,.|]
        _geo_inpoly_setslice(stack, s1, s->E, di)
        s1 = &(`SLICE'())
        s1->xy = s->xy[|1,1 \ r,.|]
        _geo_inpoly_setslice(stack, s1, s->E, di)
    }
    if (!all(t)) R[p] = _geo_inpoly_fillup(R[p], t)
    if (!nodots) _geo_progress_end(dj, ")")
    return(R)
}

`PC' _geo_inpoly_fillup(`PC' R, `BoolC' t)
{
    `Int' i
    
    for (i=rows(R); i; i--) {
        if (!t[i]) R[i] = R[i+1]
    }
    return(R)
}

`RM' _geo_inpoly_dropoutside(`RM' xy, `RM' XY)
{   // drop points that are outside the global bounds of XY
    `RR' xmm, ymm
    
    if (!rows(XY)) return
    xmm = minmax(XY[,1])
    ymm = minmax(XY[,2])
    return(select(xy, xy[,1]:>=xmm[1] :& xy[,1]:<=xmm[2] :&
                      xy[,2]:>=ymm[1] :& xy[,2]:<=ymm[2]))
}

`RM' _geo_inpoly_edgelist(ID, XY)
{
    `IntC' PID
    `IntC' GT, p
    `RM'   XY0
    
    PID = geo_pid(ID, XY)
    GT  = geo_gtype(1, ID, PID, XY)
    // determine starting points of edges
    if (rows(XY)>1) XY0 = (.,.) \ XY[|1,1 \ rows(XY)-1,2|]
    else            XY0 = (.,.)
    if (anyof(GT,1)) { // represent point as zero-length edge
        p = selectindex(GT:==1)
        XY0[p,] = XY[p,]
    }
    if (anyof(GT,2)) { // represent first segment of line as zero-length edge
        p = selectindex(GT:==2)
        p = select(p, _geo_inpoly_edgelist_tagfirst((ID, PID)[p,]))
        XY0[p,] = XY[p,]
    }
    // mark out duplicates and rows no longer needed
    p = !rowmissing((XY,XY0))
    p = _mm_uniqrows_tag((ID, PID, XY, p)) :& p
    // return edgelist
    return(select((GT, ID,
        rowminmax((XY0[,1],XY[,1])), rowminmax((XY0[,2],XY[,2])),
        (XY[,1] - XY0[,1]) :/ (XY[,2] - XY0[,2]),
        XY0, _geo_inpoly_edgelist_xmm(ID, PID, XY)), p))
        /* gtype ID xlo xup ylo yup slope x0 y0 xmin xmax
            1   2   3   4   5   6    7   8   9  10   11  */
}

`BoolC' _geo_inpoly_edgelist_tagfirst(`IntM' ID)
{
    `Int'   i, n, j
    `IntR'  id0
    `BoolC' p
    
    n = rows(ID)
    p = J(n, 1, 0)
    id0 = (.,.)
    for (i=1; i<=n; i++) {
        if (ID[i,]!=id0) {
            j = 1
            id0 = ID[i,]
            continue
        }
        j++
        if (j==2) p[i] = 1  // line starts on 2nd row of shape item
    }
    return(p)
}

`RM' _geo_inpoly_edgelist_xmm(`IntC' ID, `IntC' PID, `RM' XY)
{    // minimum and maximum x-coordinate of shape item
    `Int'  i, a, b
    `IntC' p
    `RM'   xmm
    
    p = selectindex(_mm_uniqrows_tag((ID, PID)))
    i = rows(p)
    a = rows(XY) + 1
    xmm = J(a-1, 2, .)
    for (;i;i--) {
        b = a - 1; a = p[i]
        xmm[|a,1 \ b,2|] = J(b-a+1, 1, minmax(XY[|a,1 \ b,1|]))
    }
    return(xmm)
}

end
local gt    1  // type if shape item (1 point, 2 line, 3 polygon)
local ID    2  // ID of shape (possibly containing multiple items)
local xlo   3  // lower x-coordinate of edge
local xup   4  // upper x-coordinate of edge
local ylo   5  // lower y-coordinate of edge
local yup   6  // upper y-coordinate of edge
local slope 7  // slope of edge (missing if infinity or undetermined)
local x0    8  // x-coordinate of starting point of edge
local y0    9  // y-coordinate of starting point of edge
local xmin  10 // minimum x-coordinate of shape item
local xmax  11 // maximum y-coordinate of shape item
mata:

void _geo_inpoly_setslice(`Stack' stack, `PSlice' s, `RM' E, `Int' di)
{
    `RR' ymm
    
    ymm = minmax(s->xy[,2])
    s->E = select(E, E[,`ylo']:<=ymm[2] :& E[,`yup']:>=ymm[1])
    if (rows(s->E)) _geo_inpoly_stack_append(stack, s)
    else if (di<.) di = di + rows(s->xy) // slice is skipped; update progress
}

void _geo_inpoly_process(`PC' R, `RM' xy, `RM' E)
{
    `Int'  i
    `RR'   xyi
    
    i = rows(xy)
    for (;i;i--) {
        xyi = xy[i,]
        R[xy[i,3]] = __geo_inpoly_process(xyi, select(E,
            // keep edge if point is within the x-range of shape item
            (xyi[1]:>=E[,`xmin'] :& xyi[1]:<=E[,`xmax']) :&
            // keep edge if point is within y-range of edge
            (xyi[2]:>=E[,`ylo'] :& xyi[2]:<=E[,`yup'])))
    }
}

`PS' __geo_inpoly_process(`RR' xy, `RM' E)
{
    `Int'   i, a, b
    `IntC'  p
    `RC'    x
    `BoolC' onvertex, onedge
    `RM'    r
    
    r = J(0,2,.)
    if (!rows(E)) return(NULL)
    x = E[,`x0'] :+ (xy[2] :- E[,`y0']) :* E[,`slope'] // where ray hits edge
    p = selectindex(_mm_unique_tag(E[,`ID']))
    onvertex = (xy[1]:==E[,`xup'] :& xy[2]:==E[,`yup'])
    onedge   = (x:==xy[1] :|
               (x:>=. :& xy[1]:>=E[,`xlo'] :& xy[1]:<=E[,`xup'])) // flat edge
    i = rows(p)
    a = rows(E) + 1
    for (;i;i--) {
        b = a - 1; a = p[i]
        if      (any(onvertex[|a \ b|])) r = (E[a,`ID'], 3) \ r
        else if (any(onedge[|a \ b|]))   r = (E[a,`ID'], 2) \ r
        else if (E[a,`gt']==3) {
            if (mod(sum(
                // number of edges hit by y-ray
                xy[1]:<x[|a \ b|] :&
                // ignore if at bottom (avoid double counting)
                xy[2]:!=E[|a,`ylo' \ b,`ylo'|]
                ),2)) r = (E[a,`ID'], 1) \ r
        }
    }
    if (!rows(r)) return(NULL)
    return(&r)
}

end

*! {smcl}
*! {marker geo_json}{bf:geo_json_import() and geo_json2xy()}{asis}
*! version 1.0.1  19dec2023  Ben Jann
*!
*! geo_json_import() imports a GeoJSON FeatureCollection from a source file
*! (see https://en.wikipedia.org/wiki/GeoJSON and https://geojson.org/). The
*! collection will be returned as a string matrix with properties (variables)
*! in columns and features (units) in rows.
*!
*!      S = geo_json_import(filename [, rc])
*!
*!  S         string matrix containing the parsed GeoJSON FeatureCollection;
*!            for each feature (unit), column one will contain the GeoJSON
*!            geometry specification; the remaining columns will contain the
*!            values of the properties; the first row in S will contain the
*!            property names; the second row indicates the data types of the 
*!            properties ("string" or "numeric"); data type is "string" if the
*!            property contains a string value for at least one features, else
*!            the data type is "numeric"; the data type of the first column 
*!            (geometry) is always "string"
*!  filename  string scalar providing the (path and) name of the source file
*!  rc        real scalar that will be set to 1 if an issue occurred (invalid
*!            or incomplete GeoJSON specification); else 0
*!
*! geo_json2xy() extracts the coordinates form a GeoJSON geometry object (see
*! https://en.wikipedia.org/wiki/GeoJSON). Supported geometry types are
*! Point, MultiPoint, LineString, MultiLineString, Polygon, MultiPolygon, and
*! GeometryCollection (case sensitive). In the returned matrix of coordinates,
*! each extracted line or polygon and, in case of a GeometryCollection, each
*! point will start with a row of missing values. Missing rows will be omitted
*! by default when extracting coordinates from a Point or MultiPoint object.
*!
*!      XY = geo_json2xy(s [, mis, gtype, rc])
*!
*!  XY      n x 2 real matrix containing the extracted coordinates; J(1,2,.) is
*!          returned if no coordinates are found
*!  s       string scalar containing the GeoJSON specification
*!  mis     mis!=0 enforces separating points by missing in any case
*!  gtype   string scalar that will be set to the geometry type of s
*!  rc      real scalar that will be set to 1 if an issue occurred (invalid
*!          or incomplete GeoJSON specification); else 0
*!

local Bool  real scalar
local BoolC real colvector
local Int   real scalar
local SS    string scalar
local SC    string colvector
local SM    string matrix
local RR    real rowvector
local RM    real matrix
local PC    pointer colvector
local T     transmorphic

mata:
mata set matastrict on

`SM' geo_json_import(`SS' fn, | `Bool' rc)
{
    `SM' SUB
    `T'  t, s
    
    // parser definition
    rc = 0
    t = _geo_json_parser()
    SUB = (`"\""',"<!DQ!>",`"""')', ("\\","<!BS!>","\")'
    // import file
    s = _geo_json_fget(fn, SUB)
    // parse FeatureCollection
    tokenset(t, s)
    s = _geo_json_unbind(tokenget(t), "{}", rc)
    tokenset(t, "")
    s = _geo_json_object(t, s, rc)
    if (asarray(s, "type")!=`""FeatureCollection""') {
        errprintf("file does not seem to contain a GeoJSON FeatureCollection\n")
        exit(499)
    }
    // collect features and return
    s = _geo_json_unbind(asarray(s, "features"), "[]", rc)
    return(_geo_json_features(t, s, SUB, rc))
}

`SS' _geo_json_fget(`SS' fn, `SM' SUB)
{
    `Int' j, fh
    `SS'  s

    fh = fopen(fn, "r")
    s = fread(fh, 1073741824) // max length = 1 GB
    if (fread(fh,1)!=J(0, 0, "")) {
        fclose(fh)
        errprintf("file too large; maximum size is 1 GB\n")
        exit(498)
    }
    fclose(fh)
    for (j=cols(SUB);j;j--) s = subinstr(s, SUB[1,j], SUB[2,j])
    for (j=9;j<=13;j++)     s = subinstr(s, char(j), " ") // white space
    return(s)
}

`SM' _geo_json_features(`T' t0, `SS' s, `SM' SUB, `Bool' rc)
{
    `Int'   i, n, J
    `SM'    S
    `T'     t, V, F
    
    // collect features and store in matrix S
    t = _geo_json_array_set(t0, s)
    n = _geo_json_array_n(t, rc)
    if (!n) return(J(0,0,"")) // empty array
    V = asarray_create() // for positions of properties in S
    S = J(n,50,"")
    J = 1 /*2*/
    for (i=1;i<=n;i++) {
        // parse feature object
        F = _geo_json_object(t0,
            _geo_json_unbind(_geo_json_array_get(t), "{}", rc), rc)
        if (asarray(F, "type")!=`""Feature""') {
            rc = 1
            continue
        }
        // collect id and geometry
        S[i,1] = asarray(F, "geometry")
        /*S[i,2] = asarray(F, "id")*/
        // collect properties
        _geo_json_features_properties(t0, i, F, V, S, J, rc)
    }
    S = S[,1..J]
    // add names and storage types and cleanup strings
    S = _geo_json_features_S(S, V)
    // drop id column if empty
    /*if (allof(S[|3,2 \ .,2|],"")) S = (J<=2 ? S[,1] : (S[,1], S[,3..J]))*/
    // revert substitutions
    for (i=cols(SUB);i;i--) S = subinstr(S, SUB[2,i], SUB[3,i])
    // return
    return(S)
}

void _geo_json_features_properties(`T' t0, `Int' i, `T' F, `T' V, `SM' S,
    `Int' J, `Bool' rc)
{
    `Int'   k, K, j
    `SS'    key
    `SC'    keys
    `T'     A
    
    A = asarray(F, "properties")
    if (A=="") return // "properties": null
    A = _geo_json_object(t0, _geo_json_unbind(A, "{}", rc), rc)
    keys = asarray_keys(A)
    K = rows(keys)
    for (k=1;k<=K;k++) {
        key = keys[k]
        j = asarray(V, key)
        if (!length(j)) {
            J++
            if (J>cols(S)) S = S, J(rows(S),50,"")
            asarray(V, key, J)
            j = J
        }
        S[i,j] = asarray(A, key)
    }
}

`SM' _geo_json_features_S(`SM' S, `t' V)
{
    `Int'   j
    `BoolC' q
    `SS'    key
    `SC'    keys, Sj
    `SM'    L
    
    L = J(2,cols(S),"")
    L[1,1] = "_GEOMETRY"
    L[2,1] = "string"
    L[1,2] = "id"
    keys = asarray_keys(V)
    for (j=rows(keys);j;j--) {
        key = keys[j]
        L[1,asarray(V, key)] = key
    }
    for (j=cols(S);j>1;j--) {
        Sj = S[,j]
        q = (substr(Sj,1,1)+substr(Sj,-1.1)):==`""""'
        if (any(q)) {
            L[2,j] = "string"
            S[,j]  = substr(Sj, 2, strlen(Sj)-(2:*q))
        }
        else L[2,j] = "numeric"
    }
    return(L \ S)
}

`RM' geo_json2xy(`SS' S, | `Bool' mis, `SS' kw, `Bool' rc)
{
    `RM' XY
    `T'  t0, s
    
    if (args()<2) mis = 0
    rc = 0
    t0 = _geo_json_parser()
    s = _geo_json_unbind(strtrim(S), "{}", rc)
    s = _geo_json_object(t0, s, rc)
    kw = _geo_json_unbind(asarray(s, "type"), `""""')
    if (kw=="GeometryCollection") {
        s = _geo_json_unbind(asarray(s, "geometries"), "[]", rc)
        XY = _geo_json2xy_C(t0, rc, s)
    }
    else {
        s = _geo_json_unbind(asarray(s, "coordinates"), "[]", rc)
        if      (kw=="Point")           XY = _geo_json2xy_p(rc, s, mis!=0)
        else if (kw=="MultiPoint")      XY = _geo_json2xy_P(t0, rc, s, mis!=0)
        else if (kw=="LineString")      XY = _geo_json2xy_l(t0, rc, s)
        else if (kw=="MultiLineString") XY = _geo_json2xy_L(t0, rc, s)
        else if (kw=="Polygon")         XY = _geo_json2xy_s(t0, rc, s)
        else if (kw=="MultiPolygon")    XY = _geo_json2xy_S(t0, rc, s)
        else {
            rc = 1
            kw = ""
            XY = J(0,2,.)
        }
    }
    if (!rows(XY)) XY = (.,.)
    return(XY)
}

// parser for GeometryCollection
`RM' _geo_json2xy_C(`T' t0, `Bool' rc, `SS' S)
{
    `Int' i, n, N, a, b
    `SS'  kw
    `RM'  XY
    `PC'  P
    `T'   t, s
    
    t = _geo_json_array_set(t0, S)
    n = _geo_json_array_n(t, rc)
    if (!n) return(J(0,2,.)) // array is empty
    P = J(n,1,NULL)
    N = 0
    for (i=1;i<=n;i++) {
        s  = _geo_json_unbind(_geo_json_array_get(t), "{}", rc)
        s  = _geo_json_object(t0, s, rc)
        kw = _geo_json_unbind(asarray(s, "type"), `""""')
        s  = _geo_json_unbind(asarray(s, "coordinates"), "[]", rc)
        if      (kw=="Point")           P[i] = &_geo_json2xy_p(rc, s, 1)
        else if (kw=="MultiPoint")      P[i] = &_geo_json2xy_P(t0, rc, s, 1)
        else if (kw=="LineString")      P[i] = &_geo_json2xy_l(t0, rc, s)
        else if (kw=="MultiLineString") P[i] = &_geo_json2xy_L(t0, rc, s)
        else if (kw=="Polygon")         P[i] = &_geo_json2xy_s(t0, rc, s)
        else if (kw=="MultiPolygon")    P[i] = &_geo_json2xy_S(t0, rc, s)
        else {
            rc = 1
            P[i] = &(J(0,2,.))
        }
        N = N + rows(*P[i])
    }
    XY = J(N,2,.)
    b = 0
    for (i=1;i<=n;i++) {
        a = b + 1
        b = b + rows(*P[i])
        if (b<a) continue // empty element
        XY[|a,1 \ b,2|] = *P[i]
    }
    return(XY)
}

// parser for point
`RM' _geo_json2xy_p(`Bool' rc, `SS' s, `Bool' mis)
{
    return(J(mis,2,.) \ __geo_json2xy_item(rc, s))
}

// parser for points
`RM' _geo_json2xy_P(`T' t, `Bool' rc, `SS' s, `Bool' mis)
{
    return(_geo_json2xy_array(t, rc, s, mis ? 2 : 1))
}

// parser for line
`RM' _geo_json2xy_l(`T' t, `Bool' rc, `SS' s)
{
    return(_geo_json2xy_array(t, rc, s, 0))
}

// parser for lines
`RM' _geo_json2xy_L(`T' t, `Bool' rc, `SS' s)
{
    return(_geo_json2xy_arrays(t, rc, s, 0))
}

// parser for polygon
`RM' _geo_json2xy_s(`T' t, `Bool' rc, `SS' s)
{
    return(_geo_json2xy_arrays(t, rc, s, 0))
}

// parser for polygons
`RM' _geo_json2xy_S(`T' t, `Bool' rc, `SS' s)
{
    return(_geo_json2xy_arrays(t, rc, s, 1))
}

// collect coordinates from (nested) arrays
`RM' _geo_json2xy_arrays(`T' t0, `Bool' rc, `SS' S, `Int' levl)
{
    `Int' i, n, N, a, b
    `SS'  s
    `RM'  XY
    `PC'  P
    `T'   t
    
    t = _geo_json_array_set(t0, S)
    n = _geo_json_array_n(t, rc)
    if (!n) return(J(0,2,.)) // array is empty
    P = J(n,1,NULL)
    N = 0
    for (i=1;i<=n;i++) {
        s = _geo_json_unbind(_geo_json_array_get(t), "[]", rc)
        if (levl) P[i] = &_geo_json2xy_arrays(t0, rc, s, levl-1)
        else      P[i] = &_geo_json2xy_array(t0, rc, s, 0)
        N = N + rows(*P[i])
    }
    XY = J(N,2,.)
    b = 0
    for (i=1;i<=n;i++) {
        a = b + 1
        b = b + rows(*P[i])
        if (b<a) continue // empty element
        XY[|a,1 \ b,2|] = *P[i]
    }
    return(XY)
}

// collect coordinates from single array
// pt: 0 line/polygon; 1 points w/o missings, 2 points w missings
`RM' _geo_json2xy_array(`T' t0, `Bool' rc, `SS' s, `Int' pt)
{
    `Int' i, n
    `RM'  XY
    `T'   t
    
    t = _geo_json_array_set(t0, s)
    n = _geo_json_array_n(t, rc)
    if (!n) return(J(0,2,.)) // array is empty
    XY = J(n, 2, .)
    for (i=1;i<=n;i++) {
        XY[i,] = __geo_json2xy_item(rc,
            _geo_json_unbind(_geo_json_array_get(t), "[]", rc))
    }
    if      (!pt)   XY = (.,.) \ XY // add leading missing
    else if (pt==2) XY = _geo_json2xy_array_addmis(XY)
    return(XY)
}

`RM' _geo_json2xy_array_addmis(`RM' xy)
{
    `Int' n
    `RM'  XY
    
    n = rows(xy)
    XY = J(2*n,cols(xy),.)
    XY[(1::n)*2,] = xy
    return(XY)
}

// collect coordinates from single item
`RR' __geo_json2xy_item(`Bool' rc, `SS' s)
{
    `Int' j
    `RR'  xy
    
    xy = strtoreal(tokens(subinstr(s,","," ")))
    j = length(xy)
    if (j!=2) {
        rc = 1
        if (j>2)       xy = xy[(1,2)] // too many elements
        else if (j==1) xy = (xy,.)    // too few element
        else           xy = (.,.)     // too few element
    }
    return(xy)
}

// JSON parser definition
`T' _geo_json_parser()
{
    return(tokeninit(" ", (",", ":"), (`""""', "{}", "[]")))
}

// return JSON object as associative array; assumes that {} binding has already
// been removed
`T' _geo_json_object(`T' t0, `SS' S, | `Bool' rc)
{
    `SS' key, s
    `T'  t, A

    // setup associative array
    A = asarray_create()
    asarray_notfound(A, "")
    // collect members: "key" : value [, "key" : value ...]
    t = t0
    tokenset(t, S)
    s = tokenget(t) // get first key
    if (s=="") return(A) // object is empty
    while (1) {
        if (s==",") { // element is empty; skip comma and continue
            rc = 1
            s = tokenget(t)
            if (s=="") break // reached end
            continue
        }
        if (s==":") { // key is missing; skip next token and comma and continue
            rc = 1
            s = tokenget(t)
            if (s!=",") s = tokenget(t)
            s = tokenget(t)
            if (s=="") break // reached end
            continue
        }
        key = _geo_json_unbind(s, `""""', rc)
        s = tokenget(t) // get colon
        if (s==":") s = tokenget(t) // get value
        else        rc = 1 // colon is missing
        if (s==",") { // value is missing; skip comma and continue
            rc = 1
            s = tokenget(t)
            if (s=="") break // reached end
            continue
        }
        if (s=="") { // value is missing and reached end
            rc = 1
            break
        }
        if      (s=="true")  s = "1"
        else if (s=="false") s = "0"
        else if (s=="null")  s = ""
        asarray(A, key, s) // post key and value
        s = tokenget(t) // get comma
        if (s=="") break // reached end
        if (s!=",") { // comma is missing; treat as next key
            rc = 1
            continue
        }
        s = tokenget(t) // get next key
        if (s=="") { // reached end; last element is empty
            rc = 1
            break
        }
    }
    return(A)
}

// parse JSON array; assumes that [] binding has already been removed
// - setup parser
`T' _geo_json_array_set(`T' t0, `SS' s)
{
    `T' t
    
    t = t0
    tokenset(t, s)
    return(t)
}
// - count number of (remaining) elements
`Int' _geo_json_array_n(`T' t, | `Bool' rc)
{
    `SS'  s
    `Int' n, p
    
    p = tokenoffset(t)
    s = tokenget(t)
    if (s=="") return(0) // array is empty
    n = 0
    while (1) {
        n++
        if (s==",") { // element is empty
            rc = 1
            s = tokenget(t)
            continue
        }
        s = tokenget(t) // skip comma
        if (s=="") break // reached end
        if (s!=",") { // comma is missing
            rc = 1
            continue
        }
        s = tokenget(t)
        if (s=="") { // last element empty
            rc = 1
            n++
            break
        }
    }
    tokenoffset(t, p) // move back to start
    return(n)
}
// - get next element
`SS' _geo_json_array_get(`T' t)
{
    `SS'  s
    
    
    s = tokenget(t)
    if (s==",") return("") // element is empty
    if (s=="")  return("") // element is empty
    if (tokenpeek(t)==",") (void) tokenget(t) // skip comma after element
    return(s)
}

// remove binding characters; type
//    s = _geo_json_unbind(s, `""""')   for quotes
//    s = _geo_json_unbind(s, "{}")     for braces
//    s = _geo_json_unbind(s, "[]")     for brackets
`SS' _geo_json_unbind(`SS' s, `SS' lr, | `Bool' rc)
{
    if ((substr(s,1,1)+substr(s,-1,1))!=lr) {
        rc = 1
        return(s)
    }
    return(substr(s,2,strlen(s)-2))
}

end

*! {smcl}
*! {marker geo_ksmooth}{bf:geo_ksmooth()}{asis}
*! version 1.0.2  20sep2024  Ben Jann
*!
*! Function to obtain spatially smoothed values using a kernel-weighted local
*! average or local linear fit based on euclidean distances.
*!
*! Syntax:
*!
*!      result = geo_ksmooth(Z, w, XY, XY1, bwidth [, kernel, ll, fill, nodots])
*!
*!  result  r x 1 colvector containing smoothed values of Z
*!  Z       n x 1 colvector containing input values to be smoothed
*!  w       n x 1 colvector containing weights; specify 1 to omit weights
*!  XY      n x 2 matrix containing the origin coordinates associated with Z
*!  XY1     r x 2 matrix containing the destination coordinates at which the
*!          smooth be evaluated; can be the same as XY
*!  bwidth  real scalar setting the kernel bandwidth
*!  kernel  string scalar selecting the kernel function; can be "epanechnikov",
*!          "epan2", "biweight", "triweight", "cosine", "gaussian" (gaussian
*!           kernel clipped at +/- 4), "Gaussian" (unclipped gaussian kernel),
*!          "parzen", "rectangle", or "triangle"; default is "epan2"
*!  ll      ll!=0 applies local linear smoothing; default is to apply local
*!          average smoothing
*!  fill    fill!=0 uses an unrestricted gaussian kernel as fallback to fill
*!          gaps; this has no effect if XY==XY1 or if kernel is "Gaussian"
*!  nodots  nodots!=0 suppresses progress dots
*!

local Bool real scalar
local Int  real scalar
local IntC real colvector
local RS   real scalar
local SS   string scalar
local RC   real colvector
local RM   real matrix
local PS   pointer scalar

mata:

`RM' geo_ksmooth(`RC' Z, `RC' w, `RM' XY, `RM' XY1, `RS' bw,
    | `SS' kernel, `Bool' ll, `Bool' fill, `Bool' nodots, `Bool' naive)
{
    `RS' bw2
    `SS' k
    
    if (args()<7) ll = 0
    if (args()<8) nodots = 0
    if (args()<9) naive = 0
    if (cols(XY)!=2) {
        errprintf("{it:XY} must have two columns\n")
        exit(3200)
    }
    if (cols(XY1)!=2) {
        errprintf("{it:XY1} must have two columns\n")
        exit(3200)
    }
    if (kernel=="Gaussian") {
        return(_geo_ksmooth_Gaussian(Z, w, XY, XY1, bw, ll, nodots))
    }
    if (fill) {
        if (XY!=XY1) bw2 = bw * mm_kdel0_gaussian() / mm_kdel0(kernel)
    }
    k = _mm_unabkern(kernel) // default is epan2
    if (naive) return(_geo_ksmooth_naive(Z, w, XY, XY1, bw, bw2, k, ll, nodots))
    return(_geo_ksmooth(Z, w, XY, XY1, bw, bw2, k, ll, nodots))
}

`RC' _geo_ksmooth_Gaussian(`RC' Z, `RC' w, `RM' XY, `RM' XY1,
    `RS' bw, `Bool' ll, `Bool' nodots)
{
    `Int' i, d, dn
    `RC'  S

    i = rows(XY1)
    if (!nodots) {
        displayas("txt")
        d = _geo_progress_init("(")
        dn = i
    }
    S = J(i,1,.)
    for (;i;i--) {
        if (!nodots) _geo_progress(d, 1-i/dn)
        S[i] = __geo_ksmooth_Gaussian(Z, w, XY:-XY1[i,], bw, ll)
    }
    if (!nodots) _geo_progress_end(d, ")")
    return(S)
}

`RS' __geo_ksmooth_Gaussian(`RC' Z, `RC' w, `RM' XY, `RS' bw, `Bool' ll)
{
    `RC'  kw
    
    kw = normalden(sqrt(rowsum(XY:^2)) :/ bw) :* w
    if (ll) return(_geo_ksmooth_ll(Z, XY, kw))
    return(_geo_ksmooth_mean(Z, kw))
}

`RC' _geo_ksmooth_naive(`RC' Z, `RC' w, `RM' XY, `RM' XY1,
    `RS' bw, `RS' bw2, `SS' kernel, `Bool' ll, `Bool' nodots)
{
    `Int' i, d, dn
    `RC'  S
    `PS'  k

    if (kernel=="gaussian") k = &_geo_ksmooth_gaussian()
    else                    k = _mm_findkern(kernel)
    i = rows(XY1)
    if (!nodots) {
        displayas("txt")
        d = _geo_progress_init("(")
        dn = i
    }
    S = J(i,1,.)
    for (;i;i--) {
        if (!nodots) _geo_progress(d, 1-i/dn)
        S[i] = _geo_ksmooth_fit(Z, w, XY:-XY1[i,], bw, bw2, k, ll)
    }
    if (!nodots) _geo_progress_end(d, ")")
    return(S)
}

`RC' _geo_ksmooth(`RC' Z, `RC' w, `RM' XY, `RM' XY1,
    `RS' bw, `RS' bw2, `SS' kernel, `Bool' ll, `Bool' nodots)
{   // algorithm using search window
    `Bool' hasW
    `Int'  i, j, q, a, b, d, dn
    `RS'   h, c
    `IntC' p, p1, pi
    `RC'   S
    `PS'   k
    
    // kernel
    if (kernel=="gaussian") {
        k = &_geo_ksmooth_gaussian()
        h = 4
    }
    else {
        k = _mm_findkern(kernel)
        if (kernel=="epanechnikov") h = sqrt(5)
        else if (kernel=="cosine")  h = .5
        else                        h = 1
    }
    h = sqrt(2 * (h * bw)^2)
    // determine direction of search window
    b = rows(XY)
    if (!b) return(J(rows(XY1),1,.)) // no data
    if (mm_diff(minmax(XY[,1])) > mm_diff(minmax(XY[,2]))) q = 1 // vertical
    else                                                   q = 2 // horizontal
    p = order(XY[,q], 1)
    if ((XY[p[b],q]-XY[p[1],q]) < 10*h) { // use naive algorithm if bw is large
        return(_geo_ksmooth_naive(Z, w, XY, XY1, bw, bw2, kernel, ll, nodots))
    }
    if (XY!=XY1) {; i = rows(XY1); p1 = order(XY1[,q], 1); }
    else         {; i = b;         p1 = p; }
    // run algorithm
    hasW = rows(w)!=1
    if (!nodots) {
        displayas("txt")
        d = _geo_progress_init("(")
        dn = i
    }
    S = J(i,1,.)
    for (;i;i--) {
        if (!nodots) _geo_progress(d, 1-i/dn)
        j = p1[i]
        c = XY1[j,q] + h
        for (;b;b--) {
            if (XY[p[b],q]<=c) break
        }
        if (!b) { // reached bottom; no more data
            if (bw2<.) {
                for (;i;i--) {
                    j = p1[i]
                    S[j] = __geo_ksmooth_Gaussian(Z, w, XY:-XY1[j,], bw2, ll)
                }
            }
            break 
        }
        a = b
        c = XY1[j,q] - h
        for (;a;a--) {
            if (XY[p[a],q]<c) {; a++ ; break; }
            if (a==1) break // reached bottom
        }
        if (a>b) { // no data within range
            if (bw2<.) {
                S[j] = __geo_ksmooth_Gaussian(Z, w, XY:-XY1[j,], bw2, ll)
            }
            continue
        }
        pi = p[|a\b|]
        S[j] = _geo_ksmooth_fit(Z[pi], hasW ? w[pi] : w, XY[pi,]:-XY1[j,],
            bw, bw2, k, ll)
    }
    if (!nodots) _geo_progress_end(d, ")")
    return(S)
}

`RS' _geo_ksmooth_fit(`RC' Z, `RC' w, `RM' XY, `RS' bw, `RS' bw2, `PS' k,
    `Bool' ll)
{
    `IntC' p
    `RC'   kw
    
    kw = (*k)(sqrt(rowsum(XY:^2)) :/ bw) :* w
    p = selectindex(kw)
    if (!length(p)) {
        if (bw2<.) return(__geo_ksmooth_Gaussian(Z, w, XY, bw2, ll)) // fallback
        return(.)
    }
    if (rows(p)==rows(kw)) {
        if (ll) return(_geo_ksmooth_ll(Z, XY, kw))
        return(_geo_ksmooth_mean(Z, kw))
    }
    if (ll) return(_geo_ksmooth_ll(Z[p], XY[p,], kw[p]))
    return(_geo_ksmooth_mean(Z[p], kw[p]))
}

`RS' _geo_ksmooth_mean(`RC' y, `RC' w)
{
    return(quadsum(w :* y) / quadsum(w)) // faster than mean(y, w)
}

`RS' _geo_ksmooth_ll(`RC' y, `RM' XY, `RC' w)
{
    return(mm_lsfit(y, XY, w, 1, 1, 0)[3]) // (quad precision, but no demeaning)
}

`RM' _geo_ksmooth_gaussian(`RM' x)
{
    return(normalden(x):*(x:>=-4 :& x:<=4)) // gaussian kernel clipped at +/- 4
}

end

*! {smcl}
*! {marker geo_orientation}{bf:geo_orientation()}{asis}
*! version 1.0.2  01jun2024  Ben Jann
*!
*! Determine orientation of polygon
*! see https://en.wikipedia.org/wiki/Curve_orientation
*!
*! Syntax:
*!
*!      result = geo_orientation(XY)
*!
*!  result  1 if orientation is positive (counterclockwise), -1 if negative
*!          (clockwise), 0 if undefined
*!  XY      n x 2 real matrix containing points of polygon; rows containing
*!          missing will be ignored
*!

mata
mata set matastrict on

real scalar geo_orientation(real matrix XY)
{
    if (cols(XY)!=2) {
        errprintf("{it:XY} must have two columns\n")
        exit(3200)
    }
    if (!hasmissing(XY)) return(_geo_orientation(XY))
    return(_geo_orientation(select(XY, !rowmissing(XY))))
}

real scalar _geo_orientation(real matrix XY)
{
    real scalar    n, i, a
    real colvector A, B, C
    
    n = rows(XY)
    if (n==0) return(0) // no data; orientation undefined
    a = _geo_hull_refpoint(XY)
    A = XY[a,]
    for (i=1;i<n;i++) {
        B = XY[mod(a + i - 1, n) + 1,]
        if (B!=A) break
    }
    if (i==n) return(0) // second point not found; orientation undefined
    for (i=1;i<n;i++) {
        C = XY[mod(a - i - 1, n) + 1,]
        if (C!=A) {
            if (C!=B) break
        }
    }
    if (i==n) return(0) // third point not found; orientation undefined
    return(sign((B[1]-A[1]) * (C[2]-A[2]) - (C[1]-A[1]) * (B[2]-A[2])))
}

end

*! {smcl}
*! {marker geo_pid}{bf:geo_pid()}{asis}
*! version 1.0.3  16jul2024  Ben Jann
*!
*! Generate geometry-item ID (polygon ID) within unit ID
*!
*! Syntax:
*!
*!      PID = geo_pid(ID, XY)
*!
*!  PID     n x 1 real colvector of within-unit geometry-item IDs
*!  ID      n x 1 real colvector of unit IDs (or, possibly, scalar if single
*!          unit); rows are assumed to be grouped by unit ID
*!  XY      n x 2 real matrix of (X,Y) coordinates of the geometry items; if the
*!          first row of a unit is not missing, each row within the unit is
*!          considered a separate item); else each missing row within the unit
*!          starts a new item
*!

mata:
mata set matastrict on

real colvector geo_pid(real colvector ID, real matrix XY)
{
    real scalar    i, n, a, b
    real colvector p, id
    
    // check conformability
    if (cols(XY)!=2) {
        errprintf("{it:XY} must have two columns\n")
        exit(3200)
    }
    n = rows(XY)
    i = rows(ID)
    if (n!=i & i!=1) exit(error(3200))
    // generate item id
    if (n==0) return(J(0,1,.))      // no data
    if (i==1) return(_geo_pid(XY))  // single unit
    p = selectindex(_mm_unique_tag(ID))
    i = rows(p)
    if (i==1) return(_geo_pid(XY))  // single unit
    a = n + 1
    id = J(n,1,.)
    for (;i;i--) {
        b = a - 1; a = p[i]
        id[|a \ b|] = _geo_pid(XY, a, b)
    }
    return(id)
}

real colvector _geo_pid(real matrix XY, | real scalar a, real scalar b)
{
    if (args()==1) {
        if (missing(XY[1,])!=2) return(1::rows(XY))
        return(runningsum(rowmissing(XY):==2))
    }
    if (missing(XY[a,])!=2) return(1::(b-a+1))
    return(runningsum(rowmissing(XY[|a,1 \ b,.|]):==2))
}

end

*! {smcl}
*! {marker geo_plevel}{bf:geo_plevel()}{asis}
*! version 1.0.3  15aug2024  Ben Jann
*!
*! Determines plot levels of polygons: 0 = neither enclave nor exclave, 1 =
*! enclave, 2 = exclave, 3 = enclave within exclave, 4 = exclave within
*! enclave, etc.
*!
*! Syntax:
*!
*!      result = geo_plevel(rtype, ID, PID, XY [, nodots])
*!
*!  rtype   results type: if rtype!=0 the result is a real colvector of length
*!          n containing repeated plot level values, else the result is a r x 3
*!          matrix with ID in 1st column, PID in 2nd column, and plot level in
*!          3rd column, where r is the total number of polygons
*!  ID      real colvector of unit IDs
*!  PID     real colvector of within-unit polygon IDs
*!  XY      n x 2 real matrix of (X,Y) coordinates of the polygons; missing
*!          coordinates will be ignored
*!  nodots  nodots!=0 suppresses progress dots 
*!

local Bool      real scalar
local Int       real scalar
local IntC      real colvector
local RS        real scalar
local RC        real colvector
local RM        real matrix
local POLYGON   _geo_POLYGON
local Polygon   struct `POLYGON' scalar
local pPolygon  pointer (`Polygon') scalar
local pPolygons pointer (`Polygon') vector
local UNIT      _geo_UNIT
local Unit      struct `UNIT' scalar
local pUnits    pointer (`Unit') vector

mata:
mata set matastrict on

struct `POLYGON' {
    `Int'  id       // within-unit polygon id
    `RM'   XY       // coordinates
    `RS'   xmin, xmax, ymin, ymax
    `Int'  a, b     // data range of polygon
    `Int'  l        // plot level
    `IntC' d        // list of descendants
}

struct `UNIT' {
    `Int'       id   // unit id
    `Int'       n    // number of polygons within unit
    `pPolygons' p    // polygons
}

`RM' geo_plevel(`Int' rtype, `RC' ID, `RC' PID, `RM' XY, | `Bool' nodots)
{
    `Int'    i, j, a, b, n, dn, di, dj
    `RM'     P
    `pUnits' u
    
    if (args()<5) nodots = 0
    if (cols(XY)!=2) {
        errprintf("{it:XY} must have two columns\n")
        exit(3200)
    }
    // collect units and polygons
    u = _geo_collect_units(ID, PID, XY)
    n = length(u)
    // determine within unit plot levels
    if (!nodots) {
        dj = _geo_progress_init(n>1 ? "(pass 1/2: " : "(")
        di = dn = 0
        for (i=n;i;i--) dn = dn + comb(u[i]->n,2)
    }
    for (i=n;i;i--) {
        _geo_plevel_within(*u[i], !nodots, dj, di, dn)
        //if (!nodots) _geo_progress(dj, 1-(i-1)/n)
    }
    if (!nodots) _geo_progress_end(dj, ")")
    // update plot levels based on between unit comparisons
    if (n>1) {
        if (!nodots) {
            dj = _geo_progress_init("(pass 2/2: ")
            di = dn = 0
            for (i=n;i;i--) {
                for (j=i-1; j; j--) dn = dn + u[i]->n * u[j]->n
            }
        }
        for (i=n;i;i--) {
            for (j=i-1; j; j--)
                _geo_plevel_between(*u[i], *u[j], !nodots, dj, di, dn)
        }
        if (!nodots) _geo_progress_end(dj, ")")
    }
    // fill in result
    if (rtype) {
        P = J(rows(ID), 1, .)
        for (i=n;i;i--) {
            for (j=u[i]->n;j;j--) {
                a = u[i]->p[j]->a
                b = u[i]->p[j]->b
                P[|a \ b|] = J(b-a+1, 1, u[i]->p[j]->l)
            }
        }
        return(P)
    }
    a = 0
    for (i=n;i;i--) a = a + u[i]->n
    P = J(a,3,.)
    for (i=n;i;i--) {
        for (j=u[i]->n;j;j--) {
            P[a,] = (u[i]->id, u[i]->p[j]->id, u[i]->p[j]->l)
            a--
        }
    }
    return(P)
}

void _geo_plevel_within(`Unit' u, `Bool' dots, `Int' dj, `Int' di, `Int' dn)
{
    `Int'      i, j
    `pPolygon' pi, pj

    for (i=u.n;i>1;i--) {
        pi = u.p[i]
        for (j=i-1; j; j--) {
            pj = u.p[j]
            if (pi->ymax < pj->ymin) continue
            if (pi->xmax < pj->xmin) continue
            if (pj->ymax < pi->ymin) continue
            if (pj->xmax < pi->xmin) continue
            if (!_geo_plevel_within_d(u, i, j)) {
                if (_geo_plevel_notinside(pi->XY, pj->XY)) {
                    if (!_geo_plevel_within_d(u, j, i)) {
                        if (_geo_plevel_notinside(pj->XY, pi->XY)) continue
                    }
                    // pj is inside pi
                    pj->l = pj->l + 1
                    pi->d = pi->d \ j
                    continue
                }
            }
            // pi is inside pj
            pi->l = pi->l + 1
            pj->d = pj->d \ i
        }
        if (dots) {
            di = di + i - 1
            _geo_progress(dj, di/dn)
        }
    }
}

`Bool' _geo_plevel_within_d(`Unit' u, `Int' i, `Int' j)
{   // checks whether polygon i is among descendants of polygon j
    `Int'  ji
    `IntC' d
    
    d = u.p[j]->d
    for (ji=rows(d);ji;ji--) {
        if (i==d[ji]) return(1)
        if (_geo_plevel_within_d(u, i, d[ji])) return(1)
    }
    return(0)
}

void _geo_plevel_between(`Unit' ui, `Unit' uj, `Bool' dots, `Int' dj, `Int' di,
    `Int' dn)
{
    `Int'      i, j, l
    `pPolygon' pi, pj
    
    // update plot level
    for (i=ui.n;i;i--) {
        pi = ui.p[i]
        l  = pi->l
        for (j=uj.n;j;j--) {
            pj = uj.p[j]
            if (mod(l,2)!=mod(pj->l, 2)) continue
            if (pi->ymax < pj->ymin) continue
            if (pi->xmax < pj->xmin) continue
            if (pj->ymax < pi->ymin) continue
            if (pj->xmax < pi->xmin) continue
            if (_geo_plevel_notinside(pi->XY, pj->XY)) {
                if (_geo_plevel_notinside(pj->XY, pi->XY)) continue
                // pj is in pi; increase plot level by 2
                pj->l = pj->l + 2
                continue
            }
            // pi is inside pj; increase plot level by 2
            pi->l = pi->l + 2
        }
        if (dots) {
            di = di + uj.n
            _geo_progress(dj, di/dn)
        }
    }
}

`Bool' _geo_plevel_notinside(`RM' xy, `RM' XY)
{   // treat as not inside as soon as an outside point is found
    // treat as inside as soon as an inside point is found
    // (assuming that there are no crossings)
    // treat as not inside if all points are on border
    `Int' i, r

    for (i=rows(xy);i;i--) {
        r = geo_pointinpolygon(xy[i,1], xy[i,2], XY)
        if (r==0) return(1) // point is outside
        if (r==1) return(0) // point is inside
    }
    return(0) // all points on border
}

`pUnits' _geo_collect_units(`RC' ID, `RC' PID, `RM' XY)
{
    `Int'    i, a, b
    `IntC'   p
    `pUnits' u
    
    p = selectindex(_mm_unique_tag(ID))
    i = rows(p)
    u = J(i,1,NULL)
    a = rows(ID) + 1
    for (;i;i--) {
        b = a - 1; a = p[i]
        u[i] = &_geo_collect_unit(a, b, ID, PID, XY)
    }
    return(u)
}

`Unit' _geo_collect_unit(`Int' a, `Int' b, `RC' ID, `RC' PID, `RM' XY)
{
    `Int'  i, i0, i1
    `IntC' p
    `Unit' u
    
    u.id = ID[a]
    p    = (a - 1) :+ selectindex(_mm_unique_tag(PID[|a \ b|]))
    u.n  = i = rows(p)
    u.p  = J(u.n, 1, NULL)
    i0   = b + 1
    for (;i;i--) {
        i1 = i0 - 1; i0 = p[i]
        u.p[i] = &_geo_collect_polygon(i0, i1, PID, XY)
    }
    return(u)
}

`Polygon' _geo_collect_polygon(`Int' a, `Int' b, `RC' PID, `RM' XY)
{
    `RM'      minmax
    `Polygon' p
    
    p.id = PID[a]
    p.a  = a
    p.b  = b
    p.l  = 0
    p.XY = XY[|a,1 \ b,2|]
    p.XY = select(p.XY, !rowmissing(p.XY)) // exclude missing points
    minmax = colminmax(p.XY)
    p.xmin = minmax[1,1]
    p.xmax = minmax[2,1]
    p.ymin = minmax[1,2]
    p.ymax = minmax[2,2]
    return(p)
}

end

*! {smcl}
*! {marker geo_pointinpolygon}{bf:geo_pointinpolygon()}{asis}
*! version 1.1.0  16may2024  Ben Jann
*!
*! Determines whether a point is inside or outside of a given polygon; the
*! implementation is loosely based on the examples at
*! https://rosettacode.org/wiki/Ray-casting_algorithm
*!
*! Syntax:
*!
*!      inside = geo_pointinpolygon(x, y, XY)
*!
*!  inside  real scalar equal to
*!              0 if point is outside
*!              1 if point is inside
*!              2 if point lies on edge
*!              3 is point lies on vertex
*!  x       real scalar containing X coordinate of point
*!  y       real scalar containing Y coordinate of point
*!  XY      n x 2 real matrix containing (X,Y) coordinates of polygon
*!          all arguments assumed non-missing
*!

mata:
mata set matastrict on

real scalar geo_pointinpolygon(real scalar x, real scalar y, real matrix XY)
{
    real scalar  i, c, C, poly
    real scalar  ax, ay, bx, by
    
    // XY empty
    if (!(i = rows(XY))) return(0)
    // XY is point
    if (i==1) {
        if ((x,y)==XY) return(3)
        return(0)
    }
    // XY is polygon or line
    poly = (XY[1,]==XY[i,])
    C = 0
    ax = XY[i,1]; ay = XY[i,2]
    i--
    for (;i;i--) {
        bx = ax; by = ay
        ax = XY[i,1]; ay = XY[i,2]
        if (ay>by) c = _geo_rayintersect(x, y, bx, by, ax, ay)
        else       c = _geo_rayintersect(x, y, ax, ay, bx, by)
        if (c) {
            if (c<2) C++
            else     return(c)  // point lies on vertex or on edge
        }
    }
    if (poly) return(mod(C,2))
    return(0) // XY is line; position inside not possible
}

real scalar _geo_rayintersect(real scalar px, real scalar py,
    real scalar ax, real scalar ay, real scalar bx, real scalar by)
{
    real scalar a_b, a_p
    
    // A: outside of bounding box of segment
    if (py>by) return(0)          // above
    if (py<ay) return(0)          // below
    if (ax>bx) {
        if (px > ax) return(0)    // right
        if (px < bx) {            // left
            if (ay==by) return(0) // do not count if segment is flat
            if (ay==py) return(0) // do not count if at bottom
            return(1)
        }
    }
    else {
        if (px > bx) return(0)    // right
        if (px < ax) {            // left
            if (ay==by) return(0) // do not count if segment is flat
            if (ay==py) return(0) // do not count if at bottom
            return(1)
        }
    }
    // B: on edge of bounding box
    if (py==ay) {
        if (px==ax) return(3)     // p equal to a
        if (ay==by) {             // segment is flat
            if (px==bx) return(3) // p equal to b
            return(2)             // p lies on segment
        }
        return(0)                 // at bottom; do not count
    }
    if (py==by) {
        if (px==bx) return(3)     // p equal to b
        return(bx>ax)             // at top; count if b is right of a
    }
    if (px==ax) {
        if (ax==bx) return(2)     // segment is upright; p lies on segment
        return(bx>ax)             // count if b is right of a
    }
    if (px==bx) {
        return(bx<ax)             // count if b is left of a
    }
    // C: inside bounding box
    a_b = (by - ay) / (bx - ax)   // slope of a->b
    a_p = (py - ay) / (px - ax)   // slope of a->p
    if (a_p==a_b) return(2)       // p lies on segment
    return(a_p>a_b)               // count if slope of a->p is larger
}

end

*! {smcl}
*! {marker geo_project}{bf:geo_project()}{asis}
*! version 1.0.0  03jun2024  Ben Jann
*!
*! Apply a map projection to given (unprojected) coordinates.
*!
*! Syntax:
*!
*!      result = geo_project(XY, [ pname, rad, opts ])
*!
*!  result  n x 2 real matrix of projected (X,Y) coordinates
*!  XY      n x 2 real matrix of original (X,Y) coordinates
*!  pname   string scalar selecting the projection; abbreviation and uppercase
*!          spelling allowed for built-in projections; default is "webmercator"
*!  rad     rad!=0 specifies that the original coordinates are in radians, not
*!          in degrees; this also affects the interpretation of optional
*!          arguments (if relevant)
*!  opts    real vector containing optional arguments
*!

mata:
mata set matastrict on

real matrix geo_project(real matrix XY, | string scalar s, real scalar rad,
    real vector opts)
{
    pointer (function) scalar f
    
    if (args()<3) rad = 0
    if (cols(XY)!=2) {
         errprintf("{it:XY} must have two columns\n")
         exit(3200)
    }
    (void) _geo_project_find(s, f=NULL)
    return((*f)(XY, rad, opts))
}

string scalar _geo_project_find(string scalar s0, | pointer (function) scalar f)
{
    string scalar    s
    string rowvector list
    
    list = "webmercator", "mercator", "emercator", "miller", "gallstereo",
           "lambert", "behrmann", "hobodyer", "gallpeters", "peters",
           "equirectangular",
           "robinson", "equalearth", "naturalearth",
           "winkeltripel", "hammer",
           "conic", "albers", "lambertconic",
           "orthographic"
    (void) _mm_strexpand(s=s0, strlower(strtrim(s0)), list, "webmercator")
    f = findexternal("geo_project_"+s+"()")
    if (f==NULL) {
        errprintf("projection {bf:%s} not found\n", s0)
        exit(3499)
    }
    return(s) // return expanded name
}

real scalar _geo_project_opt(real vector opts, real scalar j, real scalar def)
{   
    return(length(opts)>=j ? opts[j] : def)
}

real matrix _geo_project_rad(real scalar rad, real matrix X)
{
    if (rad) return(X)
    return(X * (pi()/180))
}

real colvector _geo_project_clip(real colvector x, string scalar lbl,
    real scalar limit, | real scalar offset)
{
    real scalar    min, max, clipped
    real rowvector minmax
    real colvector X, p
    
    // setup
    if (args()<4) offset = 0
    if (limit>=.)  return(x) // nothing to do
    if (offset>=.) return(x) // nothing to do
    max = offset + abs(limit) 
    min = offset - abs(limit)
    // clip data
    minmax = minmax(x)
    clipped = 0
    if (minmax[1]<min) {
        p = selectindex(x:<min)
        X = x
        X[p] = J(length(p), 1, min)
        clipped = 1
    }
    if (minmax[2]>max & minmax[2]<.) {
        p = selectindex(x:>max :& x:<.)
        if (clipped) X[p] = J(length(p), 1, max)
        else {
            X = x
            X[p] = J(length(p), 1, max)
            clipped = 1
        }
    }
    if (clipped) {
        printf("{txt}(using clipped values for %s coordinates" +/*
            */ " outside [%g,%g])\n", lbl, min, max)
        return(X)
    }
    return(x)
}

real matrix geo_project_webmercator(real matrix XY, real scalar rad,
     | real vector opts)
{   // Web Mercator projection based on
    // https://en.wikipedia.org/wiki/Web_Mercator_projection
    // Y clipped at +/- 85.051129
    real scalar    r, x0, yc
    real colvector x, y
    
    yc = _geo_project_rad(!rad, 360/pi() * atan(exp(pi())) - 90) // Y limit
    r  = 256 * 2^_geo_project_opt(opts, 1, 0) / (2*pi()) // zoom
    x0 = _geo_project_opt(opts, 2, 0) // central meridian
    x  = _geo_project_rad(rad, XY[,1] :- x0)
    y  = _geo_project_rad(rad, _geo_project_clip(XY[,2], "Y", yc))
    return(r * (
        x :+ pi(),
        ln(tan(pi()/4 :+ y/2)) :- pi()
        ))
}

real matrix geo_project_mercator(real matrix XY, real scalar rad,
     | real vector opts)
{   // Mercator projection (spherical earth model) based on
    // https://en.wikipedia.org/wiki/Mercator_projection
    real scalar    r, x0, yc
    real colvector x, y
    
    yc = _geo_project_rad(!rad, 90)   // Y limit
    r  = _geo_project_opt(opts, 1, 1) // radius of earth
    x0 = _geo_project_opt(opts, 2, 0) // central meridian
    x  = _geo_project_rad(rad, XY[,1] :- x0)
    y  = _geo_project_rad(rad, _geo_project_clip(XY[,2], "Y", yc))
    return(r * ( 
        x,
        sign(y) :* ln(tan(pi()/4 :+ abs(y)/2))
        )) // using abs(y) and multiply by sign to prevent missing at -90
}

real matrix geo_project_emercator(real matrix XY, real scalar rad,
     | real vector opts)
{   // Mercator projection (ellipsoid earth model) based on
    // https://en.wikipedia.org/wiki/Mercator_projection
    // inverse flattening parameter according to WGS 84 from
    // https://en.wikipedia.org/wiki/World_Geodetic_System
    // note:
    // - the squared eccentricity is defined as e2 = 1 - (b/a)^2, where a is
    //   the semi-major axis (a = 6378137) and b is the semi-minor axis of the
    //   ellipsoid
    // - the flattening (ellipticity) is defined as f = (a - b) / a, the
    //   inverse flattening as m = 1/f
    // - this implies: e2 = 2*f - f^2 = 2/m - (1/m)^2
    //                 b = a - a*f = a - a/m
    real scalar    r, x0, yc, m, e
    real colvector x, y
    
    yc = _geo_project_rad(!rad, 90)   // Y limit
    r  = _geo_project_opt(opts, 1, 1) // radius of earth
    x0 = _geo_project_opt(opts, 2, 0) // central meridian
    m  = _geo_project_opt(opts, 3, 298.257223563) // inverse flattening
    x  = _geo_project_rad(rad, XY[,1] :- x0)
    y  = _geo_project_rad(rad, _geo_project_clip(XY[,2], "Y", yc))
    e  = sqrt(2/m - (1/m)^2)
    return(r * ( 
        x,
        sign(y) :* ln(tan(pi()/4 :+ abs(y)/2) :* ((1 :- e * sin(abs(y)))
            :/  (1 :+ e * sin(abs(y)))):^(e/2))
        )) // using abs(y) and multiply by sign to prevent missing at -90
}

real matrix geo_project_miller(real matrix XY, real scalar rad,
     | real vector opts)
{   // Miller cylindrical projection using the formula given at
    // https://en.wikipedia.org/wiki/Miller_cylindrical_projection
    real scalar    r, x0, yc
    real colvector x, y
    
    yc = _geo_project_rad(!rad, 90)   // Y limit
    r  = _geo_project_opt(opts, 1, 1) // radius of earth
    x0 = _geo_project_opt(opts, 2, 0) // central meridian
    x  = _geo_project_rad(rad, XY[,1] :- x0)
    y  = _geo_project_rad(rad, _geo_project_clip(XY[,2], "Y", yc))
    return(r * (
        x,
        (5/4) * ln(tan(pi()/4 :+ (2/5)*y))
        ))
}

real matrix geo_project_gallstereo(real matrix XY, real scalar rad,
     | real vector opts)
{   // Gall stereographic projection using the formula given at
    // https://en.wikipedia.org/wiki/Gall_stereographic_projection
    real scalar    r, x0, yc
    real colvector x, y
    
    yc = _geo_project_rad(!rad, 90)   // Y limit
    r  = _geo_project_opt(opts, 1, 1) // radius of earth
    x0 = _geo_project_opt(opts, 2, 0) // central meridian
    x  = _geo_project_rad(rad, XY[,1] :- x0)
    y  = _geo_project_rad(rad, _geo_project_clip(XY[,2], "Y", yc))
    return(r * (
        x / sqrt(2),
        (1 + sqrt(2)/2) * tan(y/2)
        ))
}

real matrix geo_project_lambert(real matrix XY, real scalar rad,
     | real vector opts)
{   // Lambert cylindrical equal-area projection using the formula given at
    // https://en.wikipedia.org/wiki/Cylindrical_equal-area_projection
    real scalar r, x0, s
    
    r  = _geo_project_opt(opts, 1, 1) // radius of earth
    x0 = _geo_project_opt(opts, 2, 0) // central meridian
    s  = _geo_project_opt(opts, 3, 1) // stretch factor
    return(_geo_project_lambert(XY, rad, r, x0, s))
}

real matrix _geo_project_lambert(real matrix XY, real scalar rad,
     real scalar r, real scalar x0, real scalar s)
{
    real scalar    yc
    real colvector x, y
    
    yc = _geo_project_rad(!rad, 90) // Y limit
    x  = _geo_project_rad(rad, XY[,1] :- x0)
    y  = _geo_project_rad(rad, _geo_project_clip(XY[,2], "Y", yc))
    return(r * (sqrt(s) * x, sin(y) / sqrt(s)))
}

real matrix geo_project_behrmann(real matrix XY, real scalar rad,
     | real vector opts)
{   // Behrmann projection using the formula given at
    // https://en.wikipedia.org/wiki/Cylindrical_equal-area_projection
    real scalar r, x0
    
    r  = _geo_project_opt(opts, 1, 1) // radius of earth
    x0 = _geo_project_opt(opts, 2, 0) // central meridian
    return(_geo_project_lambert(XY, rad, r, x0, .75))
}

real matrix geo_project_hobodyer(real matrix XY, real scalar rad,
     | real vector opts)
{   // Hobo–Dyer projection using the formula given at
    // https://en.wikipedia.org/wiki/Cylindrical_equal-area_projection
    real scalar r, x0
    
    r  = _geo_project_opt(opts, 1, 1) // radius of earth
    x0 = _geo_project_opt(opts, 2, 0) // central meridian
    return(_geo_project_lambert(XY, rad, r, x0, cos(37.5 * pi() / 180)^2))
}

real matrix geo_project_gallpeters(real matrix XY, real scalar rad,
     | real vector opts)
{   // Gall–Peters projection using the formula given at
    // https://en.wikipedia.org/wiki/Cylindrical_equal-area_projection
    real scalar r, x0
    
    r  = _geo_project_opt(opts, 1, 1) // radius of earth
    x0 = _geo_project_opt(opts, 2, 0) // central meridian
    return(_geo_project_lambert(XY, rad, r, x0, .5))
}

real matrix geo_project_peters(real matrix XY, real scalar rad,
     | real vector opts)
{
    return(geo_project_gallpeters(XY, rad, opts))
}

real matrix geo_project_equirectangular(real matrix XY, real scalar rad,
     | real vector opts)
{   // Equirectangular projection based on
    // https://en.wikipedia.org/wiki/Equirectangular_projection
    real scalar    y1, r, x0, y0
    real colvector x, y
    
    y1 = _geo_project_rad(rad, _geo_project_opt(opts, 1, 0)) // std parallel
    r  = _geo_project_opt(opts, 2, 1) // radius of earth
    x0 = _geo_project_opt(opts, 3, 0) // central meridian
    y0 = _geo_project_opt(opts, 4, 0) // central parallel
    x  = _geo_project_rad(rad, XY[,1] :- x0)
    y  = _geo_project_rad(rad, XY[,2] :- y0)
    return(r * (cos(y1) * x, y))
}
real matrix geo_project_robinson(real matrix XY, real scalar rad,
     | real vector opts)
{   // robinson projection using linear interpolation; the length of the central
    // meridian will be 1.3523/.8487/pi() = .5071880041 times the equator length;
    // values taken from https://en.wikipedia.org/wiki/Robinson_projection; also
    // see: Ipbuker, C. (2005). A Computational Approach to the Robinson 
    // Projection. Survey Review 38(297): 204–217. DOI:10.1179/sre.2005.38.297.204
    real scalar    r, x0, yc, i, j
    real colvector X, Y, x, y, d
    
    yc = _geo_project_rad(!rad, 90)   // Y limit
    r  = _geo_project_opt(opts, 1, 1) // radius of earth
    x0 = _geo_project_opt(opts, 2, 0) // central meridian
    x  = _geo_project_rad(rad, XY[,1] :- x0)
    y  = _geo_project_rad(rad, _geo_project_clip(XY[,2], "Y", yc))
    X  = r *
         (1,.9986,.9954,.99,.9822,.973,.96,.9427,.9216,.8962,.8679,
          .835,.7986,.7597,.7186,.6732,.6213,.5722,.5322,.5322)'
    Y  = r * 1.3523/.8487 *
         (0,.062,.124,.186,.248,.31,.372,.434,.4958,.5571,.6176,
          .6769,.7346,.7903,.8435,.8936,.9394,.9761,1,1)'
    d  = abs(y) * (180/(5*pi())) // 5 degree steps
    i  = trunc(d)
    d  = d - i
    i  = editmissing(i :+ 1, 1) // (set to arbitrary index if y is missing)
    j  = i :+ 1
    return(((X[i] + d :* (X[j]-X[i])) :* x,
            (Y[i] + d :* (Y[j]-Y[i])) :* sign(y)))
}

real matrix geo_project_equalearth(real matrix XY, real scalar rad,
    | real vector opts)
{   // equal earth projection using the formula given at
    // https://en.wikipedia.org/wiki/Equal_Earth_projection
    real scalar    r, x0, yc, A1, A2, A3, A4
    real colvector x, y
    
    yc = _geo_project_rad(!rad, 90)   // Y limit
    r  = _geo_project_opt(opts, 1, 1) // radius of earth
    x0 = _geo_project_opt(opts, 2, 0) // central meridian
    x = _geo_project_rad(rad, XY[,1] :- x0)
    y = _geo_project_rad(rad, _geo_project_clip(XY[,2], "Y", yc))
    A1 = 1.340264; A2 = -0.081106; A3 = 0.000893; A4 = 0.003796
    y = asin(sqrt(3)/2 * sin(y))
    return(r * (
        2/3*sqrt(3)*(x :* cos(y) :/ (9*A4*y:^8 + 7*A3*y:^6 + 3*A2*y:^2 :+ A1)),
        A4*y:^9 +   A3*y:^7 +   A2*y:^3  + A1*y
        ))
}

real matrix geo_project_naturalearth(real matrix XY, real scalar rad,
    | real vector opts)
{   // natural earth projection using the formula in source code at
    // http://www.shadedrelief.com/NE_proj/natural_earth_proj.zip
    // (formula at https://en.wikipedia.org/wiki/Natural_Earth_projection
    // 27may2024, appears wrong)
    real scalar    r, x0, yc, A0, A1, A2, A3, A4, B0, B1, B2, B3, B4
    real colvector x, y, p2, p4
    
    yc = _geo_project_rad(!rad, 90)   // Y limit
    r  = _geo_project_opt(opts, 1, 1) // radius of earth
    x0 = _geo_project_opt(opts, 2, 0) // central meridian
    x  = _geo_project_rad(rad, XY[,1] :- x0)
    y  = _geo_project_rad(rad, _geo_project_clip(XY[,2], "Y", yc))
    A0 =  .8707;   A1 = -.131979; A2 = -.013791; A3 = .003971; A4 = -.001529
    B0 = 1.007226; B1 =  .015085; B2 = -.044475; B3 = .028874; B4 = -.005916
    p2 = y:^2; p4 = p2:^2
    return(r * (
        x :* (A0 :+ p2 :* (A1 :+ p2 :* (A2 :+ p4 :* p2 :* (A3 :+ p2 :* A4)))),
        y :* (B0 :+ p2 :* (B1 :+ p4 :* (B2 :+ B3 :* p2 :+ B4 :* p4)))
        ))
}

real matrix geo_project_winkeltripel(real matrix XY, real scalar rad,
    | real vector opts)
{   // Winkel tripel projection using the formula given at
    // https://en.wikipedia.org/wiki/Winkel_tripel_projection
    real scalar    y1, r, x0, yc
    real colvector x, y, a
    
    yc = _geo_project_rad(!rad, 90)     // Y limit
    y1 = _geo_project_rad(!rad, 180/pi()) * acos(2/pi()) // default for y1
    y1 = _geo_project_opt(opts, 1, y1)  // std parallel
    r  = _geo_project_opt(opts, 2, 1)   // radius of earth
    x0 = _geo_project_opt(opts, 3, 0)   // central meridian
    x  = _geo_project_rad(rad, XY[,1] :- x0)
    y  = _geo_project_rad(rad, _geo_project_clip(XY[,2], "Y", yc))
    y1 = _geo_project_rad(rad, y1)
    a  = acos(cos(y) :* cos(x/2)) // alpha
    a  = editmissing(sin(a) :/ a, 1) // sinc(alpha)
    return((r/2) * (
        x * cos(y1) + 2 * (cos(y) :* sin(x/2) :/ a),
        y + sin(y) :/ a
        ))
}

real matrix geo_project_hammer(real matrix XY, real scalar rad,
    | real vector opts)
{   // Winkel tripel projection using the formula given at
    // https://en.wikipedia.org/wiki/Winkel_tripel_projection
    real scalar    r, x0, yc
    real colvector x, y, d
    
    yc = _geo_project_rad(!rad, 90)   // Y limit
    r  = _geo_project_opt(opts, 1, 1) // radius of earth
    x0 = _geo_project_opt(opts, 2, 0) // central meridian
    x  = _geo_project_rad(rad, XY[,1] :- x0)
    y  = _geo_project_rad(rad, _geo_project_clip(XY[,2], "Y", yc))
    d  = sqrt(1 :+ cos(y) :* cos(x/2))
    return(r * (
        (2 * sqrt(2)) * (cos(y) :* sin(x/2) :/ d),
        sqrt(2) * (sin(y) :/ d)
        ))
}

real matrix geo_project_conic(real matrix XY, real scalar rad,
     | real vector opts)
{   // Equidistant conic projection using the formula given at
    // https://en.wikipedia.org/wiki/Equidistant_conic_projection
    real scalar    y1, y2, r, x0, y0, yc, n, G, p
    real colvector x, y
    
    yc = _geo_project_rad(!rad, 90)     // Y limit
    y2 = _geo_project_rad(!rad, 60)     // default for y2
    y1 = _geo_project_opt(opts, 1,  0)  // 1st standard parallel
    y2 = _geo_project_opt(opts, 2, y2)  // 2nd standard parallel
    r  = _geo_project_opt(opts, 3,  1)  // radius of earth
    x0 = _geo_project_opt(opts, 4,  0)  // central meridian
    y0 = _geo_project_opt(opts, 5,  0)  // central parallel
    x  = _geo_project_rad(rad, XY[,1] :- x0)
    y  = _geo_project_rad(rad, _geo_project_clip(XY[,2], "Y", yc))
    y1 = _geo_project_rad(rad, y1)
    y2 = _geo_project_rad(rad, y2)
    y0 = _geo_project_rad(rad, y0)
    n  = y1==y2 ? sin(y1) : (cos(y1) - cos(y2)) / (y2 - y1)
    G  = cos(y1)/n + y1
    p  = G - y0 // rho0
    y  = G :- y // rho
    return(r * (y :* sin(n*x), p :- y :* cos(n*x)))
}

real matrix geo_project_albers(real matrix XY, real scalar rad,
     | real vector opts)
{   // Albers equal-area conic projection using the formula given at
    // https://en.wikipedia.org/wiki/Albers_projection
    real scalar    y1, y2, r, x0, y0, yc, n, C, p
    real colvector x, y
    
    yc = _geo_project_rad(!rad, 90)     // Y limit
    y2 = _geo_project_rad(!rad, 60)     // default for y2
    y1 = _geo_project_opt(opts, 1,  0)  // 1st standard parallel
    y2 = _geo_project_opt(opts, 2, y2)  // 2nd standard parallel
    r  = _geo_project_opt(opts, 3,  1)  // radius of earth
    x0 = _geo_project_opt(opts, 4,  0)  // central meridian
    y0 = _geo_project_opt(opts, 5,  0)  // central parallel
    x  = _geo_project_rad(rad, XY[,1] :- x0)
    y  = _geo_project_rad(rad, _geo_project_clip(XY[,2], "Y", yc))
    y1 = _geo_project_rad(rad, y1)
    y2 = _geo_project_rad(rad, y2)
    y0 = _geo_project_rad(rad, y0)
    n  = (sin(y1) + sin(y2)) / 2
    C  = cos(y1)^2 + 2*n*sin(y1)
    p  = r/n * sqrt(C - 2*n*sin(y0)) // rho0
    y  = r/n * sqrt(C :- 2*n*sin(y)) // rho
    return((y :* sin(n*x), p :- y :* cos(n*x)))
}

real matrix geo_project_lambertconic(real matrix XY, real scalar rad,
    | real vector opts)
{   // Lambert conformal conic projection using the formula given at
    // https://en.wikipedia.org/wiki/Lambert_conformal_conic_projection
    real scalar    y1, y2, r, x0, y0, yc, n, F, p
    real colvector x, y
    
    yc = _geo_project_rad(!rad, 90)     // Y limit
    y2 = _geo_project_rad(!rad, 60)     // default for y2
    y1 = _geo_project_opt(opts, 1,  0)  // 1st standard parallel
    y2 = _geo_project_opt(opts, 2, y2)  // 2nd standard parallel
    r  = _geo_project_opt(opts, 3,  1)  // radius of earth
    x0 = _geo_project_opt(opts, 4,  0)  // central meridian
    y0 = _geo_project_opt(opts, 5,  0)  // central parallel
    x  = _geo_project_rad(rad, XY[,1] :- x0)
    y  = _geo_project_rad(rad, _geo_project_clip(XY[,2], "Y", yc))
    y1 = _geo_project_rad(rad, y1)
    y2 = _geo_project_rad(rad, y2)
    y0 = _geo_project_rad(rad, y0)
    n  = y1==y2 ? sin(y1) :
         ln(cos(y1)/cos(y2)) / ln(tan(pi()/4 + y2/2) / tan(pi()/4 + y1/2))
    F  = cos(y1) * tan(pi()/4 + y1/2)^n / n
    p  = r*F * (1 / tan(pi()/4 + y0/2)):^n  // rho0
    y  = r*F * (1 :/ tan(pi()/4 :+ y/2)):^n // rho
    return((y :* sin(n*x), p :- y :* cos(n*x)))
}

real matrix geo_project_orthographic(real matrix XY, real scalar rad,
    | real vector opts)
{   // Orthographic projection using the formula given at
    // https://en.wikipedia.org/wiki/Orthographic_map_projection
    real scalar    r, x0, y0, xc, yc
    real colvector x, y
    
    xc = _geo_project_rad(!rad, 90)     // X limit
    yc = _geo_project_rad(!rad, 90)     // Y limit
    r  = _geo_project_opt(opts, 1, 1)   // radius of earth
    x0 = _geo_project_opt(opts, 2, 0)   // central meridian
    y0 = _geo_project_opt(opts, 3, 0)   // central parallel
    x  = _geo_project_rad(rad, _geo_project_clip(XY[,1], "X", xc, x0) :- x0)
    y  = _geo_project_rad(rad, _geo_project_clip(XY[,2], "Y", yc, y0))
    y0 = _geo_project_rad(rad, y0)
    return(r * (
        cos(y) :* sin(x),
        cos(y0) :* sin(y) - sin(y0)*cos(y):*cos(x)
        ))
}

end

*! {smcl}
*! {marker geo_raster}{bf:geo_raster()}{asis}
*! version 1.0.1  30aug2024  Ben Jann
*!
*! Generate a raster covering the provided shape units.
*!
*! Syntax:
*!
*!      result = geo_raster(rtype, n, angle, XY [, ID, PL, mtype, nodots])
*!
*!  result   real matrix containing generated raster items; columns are
*!           (id, x, y, [cx, cy, uid, pl]) where id contains a unique ID for
*!           each item, x and y contain the shape coordinates, cx and
*!           cy contain centroids (the original centroids before clipping),
*!           uid contains the ID of the input unit to which the raster item
*!           has been mapped, and pl contains the plot level index of the item;
*!           cx and cy will be omitted if rtype=0, uid and pl will be omitted
*!           unless mtype=0, pl will be omitted if PL is not provided or
*!           if rtype=0 
*!  rtype    real scalar selecting the type of raster to be generated, supported
*!           types are 0 = point, 2 = triangle, 3 = triangle (every other only),
*!           4 = square, 5 = square (every other only, i.e. a checkerboard),
*!           6 = hexagon; any other value will be interpreted as 0
*!  n        number of raster columns
*!  angle    rotate the raster by angle degrees (counter clockwise), default
*!           is 0
*!  XY       n x 2 real matrix containing the (X,Y) coordinates of the shape
*!           units to be covered by the raster
*!  ID       n x 1 real colvector containing the IDs of the shape units in XY;
*!           ID is set to 1 for all rows in XY if ID is omitted; can also
*!           specify # to set the ID to # for all rows
*!  PL       n x 1 real colvector containing the plot levels of the individual
*!           shape items in XY; can specify PL as . to omit plot levels; PL will
*!           not be used if rtype = 0 (point)
*!  mtype    real scalar selecting the type of merging; 0 = merge and clip
*!           raster items to shape units; 1 = select raster items that overlap
*!           with at least one shape unit; 2 = skip merging and return a full
*!           (rectangular) raster; any other value will be interpreted as 0
*!  nodots   nodots!=0 suppresses progress dots
*!

local Bool    real scalar
local BoolC   real colvector
local Int     real scalar
local IntC    real colvector
local IntM    real matrix
local RS      real scalar
local RC      real colvector
local RM      real matrix
local PS      pointer scalar
local PC      pointer colvector
local PM      pointer matrix
local ITEM    _geo_raster_ITEM
local Item    struct `ITEM' scalar
local pItems  pointer (`Item') colvector

mata:

struct `ITEM' {
    `Int' id, gt
    `RS'  xmin, xmax, ymin, ymax
    `RM'  XY
    `RR'  xy
}

`RM' geo_raster(`Int' rtype, `Int' n0, `RS' angle, `RM' XY, | `RC' ID, 
    `IntC' PL, `Int' mtype, `Bool' nodots)
{
    `Int'  n
    `RM'   limits
    `PS'   pID, pPL
    transmorphic R
    
    // settings
    if (args()<5)         pID = &J(rows(XY),1,1)
    else if (rows(ID)==1) pID = &J(rows(XY),1,ID)
    else                  pID = &ID
    if (args()<6)         pPL = &J(0,1,.)
    else if (rows(PL)==1) pPL = &J(0,1,.)
    else                  pPL = &PL
    if (args()<8) nodots = 0
    if (cols(XY)!=2) {
        errprintf("{it:XY} must have two columns\n")
        exit(3200)
    }
    // raster size and range
    if (!nodots) {
        displayas("txt")
        printf("(generating raster items ...")
        displayflush()
    }
    if (n0>=.)     n = 50
    else if (n0<1) n = 1
    else           n = n0
    limits = _geo_raster_limits(XY, angle)
    // generate raw raster
    if      (rtype==2) R = _geo_raster_triangle(n, limits, angle, 0)
    else if (rtype==3) R = _geo_raster_triangle(n, limits, angle, 1)
    else if (rtype==4) R = _geo_raster_square(n, limits, angle, 0)
    else if (rtype==5) R = _geo_raster_square(n, limits, angle, 1)
    else if (rtype==6) R = _geo_raster_hex(n, limits, angle)
    else /*point*/ {
        R = _geo_raster_point(n, limits, angle)
        if (!nodots) {
            display(" done)")
            if (mtype!=2) display("(mapping raster items to shape units)")
        }
        return(_geo_raster_point_map(R, XY, *pID, mtype, nodots))
    }
    // merge raster to shapes
    if (!nodots) {
        display(" done)")
        if (mtype!=2) display("(mapping raster items to shape units)")
    }
    if      (mtype==2) R = _geo_raster_collect(R)
    else if (mtype==1) R = _geo_raster_select(R, XY, *pID, *pPL, nodots)
    else               R = _geo_raster_clip(R, XY, *pID, *pPL, nodots)
    return(R)
}

`RM' _geo_raster_limits(`RM' XY, `RS' angle)
{
    `RR' range
    `RM' limits
    
    if (angle!=0 & angle<.) limits = colminmax(geo_rotate(XY, -angle))
    else                    limits = colminmax(XY)
    range = limits[2,] - limits[1,]
    if (!hasmissing(range)) {
        if (all(range:>0)) return(limits) // all limits ok
    }
    if (range[1]>=.) {
        if (range[2]>=.) return((0,0) \ (1,1)) // all limits missing
        // X limits missing => copy Y limits
        limits = J(1,2,limits[,2])
        range  = J(1,2,range[2])
    }
    else if (range[2]>=.) {
        // Y limits missing => copy X limits
        limits = J(1,2,limits[,1])
        range  = J(1,2,range[1])
    }
    if (range[1]==0) {
        if (range[2]==0) return(limits + J(1,2, -.5 \ .5)) // zero X/Y-range
        // zero X-range => copy Y-range
        limits[,1] = limits[,1] + (-range[2]/2 \ range[2]/2)
    }
    else if (range[2]==0) {
        // zero Y-range => copy X-range
        limits[,2] = limits[,2] + (-range[1]/2 \ range[1]/2)
    }
    return(limits)
}

`pItems' _geo_raster_items(`RM' XY, `RC' ID)
{
    `Int'    i, a, b
    `IntC'   p
    `pItems' P
    
    p = selectindex(_mm_uniqrows_tag((ID, geo_pid(ID, XY))))
    i = rows(p)
    P = J(i,1,NULL)
    a = rows(XY) + 1
    for (;i;i--) {
        b = a - 1; a = p[i]
        P[i] = &_geo_raster_item(XY[|a,1 \ b,2|], ID[a])
    }
    return(P)
}

`Item' _geo_raster_item(`RM' XY, `Int' id)
{
    `Int'  r
    `Item' p
    
    r = rows(XY)
    if (r<=2) { // point (or missing)
        p.gt = 1
        if (r==1) p.XY = XY
        else      p.XY = XY[2,] // ignore 1st row (missing)
    }
    else if (r<=4) { // line
        p.gt = 2
        p.XY = XY
    }
    else if (XY[2,]!=XY[r,]) { // line
        p.gt = 2
        p.XY = XY
    }
    else { // polygon
        p.gt = 3
        if (geo_orientation(XY)!=1) p.XY = XY
        else p.XY = J(1,2,.) \ XY[r::2,.] // make clockwise
    }
    p.id = id
    _geo_raster_minmax(p)
    return(p)
}

void _geo_raster_minmax(`Item' p)
{
    `RM' M
    
    M = colminmax(p.XY)
    p.xmin = M[1,1]
    p.xmax = M[2,1]
    p.ymin = M[1,2]
    p.ymax = M[2,2]
}

`RS' _geo_raster_A0(`RM' mask, `RS' a, `RS' b)
{
    `RR' minmax
    
    minmax = minmax(mask)
    a = minmax[1]
    b = minmax[2] - minmax[1]
    return(__geo_area((mask:-a)/b))
}

`Item' _geo_raster_ritem(`RM' XY, `RS' angle)
{
    `Item' p
    
    p.XY = (.,.) \ geo_rotate( XY, angle)
    p.xy = __geo_centroid(1, p.XY)
    return(p)
}

`RM' _geo_raster_point(`Int' n, `RM' limits, `RS' angle)
{
    `Int' r, i
    `RS'  h, c
    `RC'  X, Y
    `RM'  XY

    h = (limits[2,1] - limits[1,1]) / n             // step size
    if (h>=.) h = 1                                 // set to 1 if range is 0
    r = ceil((limits[2,2] - limits[1,2]) / h)       // number of rows
    c = (h - (r*h + limits[1,2] - limits[2,2])) / 2 // vertical offset
    X = rangen(limits[1,1]+h/2, limits[2,1]-h/2, n)
    Y = rangen(limits[1,2]+c,   limits[2,2]-c, r)
    XY = J(n*r, 2, .)
    for (i=r;i;i--) XY[|(i-1)*n+1,1 \ i*n,2|] = X, J(n,1,Y[i])
    if (angle!=0 & angle<.) return(geo_rotate(XY, angle))
    return(XY)
}

`RM' _geo_raster_point_map(`RM' R, `RM' XY, `RC' ID, `Int' mtype, `Bool' nodots)
{
    `RM' id
    
    if (mtype!=2) {
        id = geo_inpoly(R, ID, XY, 0, nodots) 
        if (mtype==1) R = select(R, id[,2])
        else          R = mm_sort(select((R,id[,1]), id[,2]), 3, 1)
    }
    return((1::rows(R)), R) // add raster item ID
}

/*`RM' _geo_raster_line(`Int' n, `RM' limits, `RS' angle)
{
    `Int' i, a, b, x, y1, y2
    `RC'  X
    `RM'  XY

    X = rangen(limits[1,1], limits[2,1], n)
    y1 = limits[1,2]; y2 = limits[2,2]
    XY = J(n*3, 2, .0)
    a = rows(XY) + 1
    for (i=n;i;i--) {
        b = a - 1; a = a - 3
        x = X[i]
        XY[|a,1 \ b,2|] = (.,.) \ (x,y1) \ (x,y2)
    }
    if (angle!=0 & angle<.) return(geo_rotate(XY, angle))
    return(XY)
}*/

`pItems' _geo_raster_triangle(`Int' n, `RM' limits, `RS' angle, `Bool' checker)
{
    `Int'    r, i, j, k, ang, x1, x2, x3, y1, y2, jodd, odd
    `RS'     h, hy, c
    `RC'     X, Y
    `RM'     xy
    `pItems' R

    ang = angle<. ? angle : 0
    h = (limits[2,1] - limits[1,1]) / n              // horizontal step size
    hy = sqrt(3) / 2 * h                             // vertical step size
    r = ceil((limits[2,2] - limits[1,2]) / hy)       // number of rows
    c = (r*hy + limits[1,2] - limits[2,2]) / 2       // vertical offset
    X = rangen(limits[1,1]-h/2,limits[2,1]+h/2, (n+1)*2+1)
    Y = rangen(limits[1,2]-c,limits[2,2]+c, r+1)
    if (checker) k = ((n+1)*ceil(r/2) + n*floor(r/2))
    else         k = (n * 2 + 1) * r
    R = J(k, 1, NULL)
    j = r + 1
    y1 = Y[j--]
    for (;j;j--) {
        y2 = y1; y1 = Y[j]
        jodd = mod(j,2)
        i = (n+1)*2+1
        x2 = X[i--]; x1 = X[i--]
        for (;i;i--) {
            x3 = x2; x2 = x1; x1 = X[i]
            odd = (jodd + mod(i,2))==1
            if (odd) {
                if (checker) continue
                xy = (x1,y2) \ (x2,y1) \ (x3,y2) \ (x1,y2)
            }
            else xy = (x1,y1) \ (x3,y1) \ (x2,y2) \ (x1,y1)
            R[k--] = &_geo_raster_ritem(xy, ang)
        }
    }
    return(R)
}

`pItems' _geo_raster_square(`Int' n, `RM' limits, `RS' angle, `Bool' checker)
{
    `Int'    r, i, j, k, ang, xlo, xup, ylo, yup
    `RS'     h, c
    `RC'     X, Y
    `pItems' R

    ang = angle<. ? angle : 0
    if (n==1) {
        h = (limits[2,1] - limits[1,1]) * 2
        X = limits[1,1]-h/4, limits[2,1]+h/4
    }
    else {
        h = (limits[2,1] - limits[1,1]) / (n-1)       // step size
        X = rangen(limits[1,1]-h/2, limits[2,1]+h/2, n+1)
    }
    r = ceil((limits[2,2] - limits[1,2]) / h)         // number of rows
    c = (r*h + limits[1,2] - limits[2,2]) / 2         // vertical offset
    Y = rangen(limits[1,2]-c, limits[2,2]+c, r+1)
    if (checker) k = (ceil(n/2)*ceil(r/2) + floor(n/2)*floor(r/2))
    else         k = n * r
    R = J(k, 1, NULL)
    j = r + 1
    ylo = Y[j--]
    for (;j;j--) {
        yup = ylo; ylo = Y[j]
        i = n + 1
        xlo = X[i--]
        for (;i;i--) {
            xup = xlo; xlo = X[i]
            if (checker) {
                if (mod(j,2)) {; if (!mod(i,2)) continue; }
                else          {; if (mod(i,2))  continue; }
            }
            R[k--] = &_geo_raster_ritem((xlo,ylo) \ (xup,ylo) \ (xup,yup) \
                (xlo,yup) \ (xlo,ylo), ang)
        }
    }
    return(R)
}

`pItems' _geo_raster_hex(`Int' n, `RM' limits, `RS' angle)
{
    `Int'    r, i, j, k, ang, x1, x2, x3, y1, y2, y3, y4, odd
    `RS'     h, hy, c
    `RC'     X, Y
    `pItems' R

    ang = angle<. ? angle : 0
    h = (limits[2,1] - limits[1,1]) / n              // horizontal step size
    hy = h / sqrt(3)                                 // vertical step size
    r = ceil((limits[2,2] - limits[1,2] + hy/2) / (1.5*hy)) // number of rows
    c = (1.5*hy*r+hy/2 + limits[1,2] - limits[2,2]) / 2   // vertical offset
    X = rangen(limits[1,1]-h/2,limits[2,1]+h/2, (n+1)*2+1)
    Y = rangen(limits[1,2]-c,  limits[2,2]+c,   r*3+2)
    k = n * r + floor(r/2)
    R = J(k, 1, NULL)
    j = r*3+2
    y2 = Y[j--]; y1 = Y[j--]
    for (;j;j--) {
        j--
        y4 = y2; y3 = y1; y2 = Y[j--]; y1 = Y[j]
        odd = mod(j,2)
        i = (n+1)*2 + 1
        if (odd) i--
        x1 = X[i--]
        for (;i>1;i--) {
            x3 = x1; x2 = X[i--]
            x1 = X[i]
            R[k--] = &_geo_raster_ritem((x1,y2) \ (x2,y1) \ (x3,y2) \ (x3,y3) \
                (x2,y4) \ (x1,y3) \ (x1,y2), ang)
        }
    }
    return(R)
}

`RM' _geo_raster_collect(`pItems' R)
{
    `Int' i, r, a, b
    `RM'  XY
    
    a = 0
    for (i=rows(R); i; i--) a = a + rows(R[i]->XY)
    XY = J(a,5,.)
    a++
    for (i=rows(R); i; i--) {
        r = rows(R[i]->XY)
        b = a - 1
        a = a - r
        XY[|a,1 \ b,5|] = J(r, 1, i), R[i]->XY, J(r, 1, R[i]->xy)
    }
    return(XY)
}

`RM' _geo_raster_select(`pItems' R, `RM' XY, `RC' ID, `IntC' PL, `Bool' nodots)
{
    `Int'   i, k, K, d
    `BoolC' P
    `IntC'  p, L
    `PS'    pl
    
    i = rows(R)
    P = J(i,1,.)
    for (;i;i--) _geo_raster_minmax(*R[i])
    if (rows(PL)) {
        if (hasmissing(PL)) pl = &editmissing(PL, 0) // treat missing as 0
        else                pl = &PL
        L = mm_unique(select(*pl, _mm_uniqrows_tag((ID, geo_pid(ID, XY)))))
        K = length(L)
        for (k=K;k;k--) {
            if (!nodots)
                d = _geo_progress_init(sprintf("(pass %g/%g: ", K-k+1, K))
            p = selectindex(*pl:==L[k])
            __geo_raster_select(P, R, _geo_raster_items(XY[p,], ID[p]),
                mod(L[k],2), d)
            if (!nodots) _geo_progress_end(d, ")")
        }
    }
    else {
        if (!nodots) d = _geo_progress_init("(")
        __geo_raster_select(P, R, _geo_raster_items(XY, ID), 0, d)
        if (!nodots) _geo_progress_end(d, ")")
    }
    _editmissing(P,0)
    R = select(R, P)
    return(_geo_raster_collect(R))
}

void __geo_raster_select(`BoolC' P, `pItems' R, `pItems' S, `Bool' odd, `Int' d)
{
    `Int' i, n, j, jj, r, o, off
    `RS'  A0, a, b
    
    n = rows(P)
    if (n) A0 = _geo_raster_A0(R[1]->XY, a=., b=.)
    r = rows(S)
    off = -1
    for (i=n;i;i--) {
        if (d<.) _geo_progress(d, 1-i/n)
        if (P[i]<.) continue
        for (j=r;j;j--) {
            jj = mod(j + off, r) + 1
            o = __geo_raster_select_i(*S[jj], *R[i], A0, a, b)
            if (!o) continue
            if (odd) {
                if (o==2) P[i] = 0 // exclude cell if fully inside enclave
            }
            else P[i] = 1
            off = jj - 2  // continue with next cell in same position
            break
        }
    }
}

`Int' __geo_raster_select_i(`Item' p, `Item' p0, `RS' A0, `RS' a, `RS' b)
{
    if (p0.xmax < p.xmin) return(0)
    if (p0.xmin > p.xmax) return(0)
    if (p0.ymax < p.ymin) return(0)
    if (p0.ymin > p.ymax) return(0)
    if (p.gt==1) return(__geo_raster_select_pt(p.XY, p0.XY))
    if (p.gt==2) return(__geo_raster_select_line(p.XY, p0.XY))
    return(__geo_raster_select_area(p.XY, p0.XY, A0, a, b))
}

`Int' __geo_raster_select_pt(`RR' xy, `RM' mask)
{   // returns 0 if point outside mask, 3 if point inside mask
    `Int' i
    `RS'  x, y, x0, x1, y0, y1
    
    x = xy[1]; y = xy[2]
    i = rows(mask)
    x0 = mask[i,1]; y0 = mask[i,2]; i--
    for (;i>1;i--) { // ignore first row
        x1 = x0; y1 = y0
        x0 = mask[i,1]; y0 = mask[i,2]
        if (sign((x - x0)*(y1 - y0) - (y - y0)*(x1 - x0))>0) return(0)
    }
    return(3)
}

`Int' __geo_raster_select_line(`RM' XY, `RM' mask)
{   // return: 0 no overlap, 1 overlap, 3 XY inside mask
    `Int' i, n
    `RM'  xy
    
    xy = XY
    n = rows(mask)
    for (i=2;i<n;i++) xy = _geo_clip_line(xy, mask[|i,1 \ i+1,2|])
    if (!rows(xy)) return(0) // no overlap
    if (xy==XY) return(3)    // XY inside mask
    return(1)                // overlap
}

`Int' __geo_raster_select_area(`RM' XY, `RM' mask, `RS' A0, `RS' a, `RS' b)
{   // return: 0 no overlap, 1 overlap, 2 mask inside XY, 3 XY inside mask
    `Int' i, n, r
    `RM'  xy
    
    xy = XY
    n = rows(mask)
    for (i=2;i<n;i++) xy = _geo_clip_area(xy, mask[|i,1 \ i+1,2|])
    r = rows(xy)
    if (!r) return(0)     // no overlap
    if (r==n) {
        if (reldif(__geo_area((xy:-a)/b), A0)<1e-13)
            return(2)     // mask inside XY
    }
    if (xy==XY) return(3) // XY inside mask
    return(1)             // overlap
}

`RM' _geo_raster_clip(`pItems' R, `RM' XY, `RC' ID, `IntC' PL, `Bool' nodots)
{
    `Int'   i, k, K, l, l0, d
    `BoolC' P, hasPL
    `IntC'  p, L
    `RM'    S
    `PS'    pl
    `PM'    I
    
    for (i=rows(R);i;i--) _geo_raster_minmax(*R[i])
    hasPL = rows(PL)!=0
    if (hasPL) {
        if (hasmissing(PL)) pl = &editmissing(PL, 0) // treat missing as 0
        else                pl = &PL
        L = mm_unique(select(*pl, _mm_uniqrows_tag((ID, geo_pid(ID, XY)))))
        K = length(L)
        I = J(rows(R),K,NULL)
        S = J(0,6,.)
        l = .
        for (k=K;k;k--) {
            if (!nodots)
                d = _geo_progress_init(sprintf("(pass %g/%g: ", K-k+1, K))
            l0 = l; l = L[k]
            p = selectindex(*pl:==L[k])
            if (mod(l,2))       P = J(rows(R),1,0)
            else if (l0!=(l+1)) P = J(rows(R),1,0)
            I[,k] = __geo_raster_clip(P, R,
                _geo_raster_items(XY[p,], ID[p]), mod(l,2), S, l, d)
            if (!nodots) _geo_progress_end(d, ")")
        }
    }
    else {
        if (!nodots) d = _geo_progress_init("(")
        I = __geo_raster_clip(J(rows(R),1,0), R,
            _geo_raster_items(XY, ID), 0, S, l, d)
        if (!nodots) _geo_progress_end(d, ")")
    }
    if (hasPL) S = runningsum(_mm_uniqrows_tag(S[,(5,6)])):+rows(I), S
    else       S = J(0,6,.)
    S = _geo_raster_clip_collect(I, hasPL, L) \ S
    S = mm_sort(S, (1,6), 1)
    S[,1] = runningsum(_mm_uniqrows_tag(S[,(1,6)])) // update raster item ID
    return(S)
}

`PC' __geo_raster_clip(`BoolC' P, `pItems' R, `pItems' S, `Bool' odd, `RM' E,
    `Int' pl, `Int' d)
{
    `Bool' inside
    `Int'  i, n, j, jj, r, off
    `RS'   A, AA, A0, a, b
    `RM'   xy
    `PC'   I
    
    n = rows(P)
    if (n) A0 = _geo_raster_A0(R[1]->XY, a=., b=.)
    I = J(n,1,NULL)
    r = rows(S)
    off = -1
    for (i=n;i;i--) {
        if (d<.) _geo_progress(d, 1-i/n)
        if (P[i]) continue
        AA = 0
        for (j=r;j;j--) {
            jj = mod(j + off, r) + 1
            xy = __geo_raster_clip_i(*S[jj], *R[i])
            if (!rows(xy)) continue
            A = __geo_area((xy :- a) / b)
            if (!A) continue
            inside = reldif(A,A0)<1e-13 // cell is fully inside shape item
            if (odd) { // enclave
                if (inside) {
                    P[i] = 1
                    off = jj - 2 // continue with next cell in same position
                    break
                }
                __geo_raster_clip_save(I, i, xy, *S[jj], *R[i])
                continue
            }
            if (inside) {
                __geo_raster_clip_save(I, i, R[i]->XY, *S[jj], *R[i])
                off = jj - 2 // continue with next cell in same position
                break
            }
            __geo_raster_clip_save(I, i, (.,.)\xy[rows(xy)::2,], *S[jj], *R[i])
            AA = quadsum((AA, A))
            if (reldif(AA,A0)<1e-13) { // cell is complete
                off = jj - 2 // continue with next cell in same position
                break
            }
        }
    }
    if (odd) _geo_raster_clip_E(E, S, pl) // collect enclaves
    return(I)
}

void __geo_raster_clip_save(`PC' I, `Int' i, `RM' xy, `Item' p, `Item' p0)
{
    if (I[i]==NULL) I[i] =          &(xy, J(rows(xy),1,(p0.xy, p.id)))
    else            I[i] = &(*I[i] \ (xy, J(rows(xy),1,(p0.xy, p.id))))
}

`RM' __geo_raster_clip_i(`Item' p, `Item' p0)
{
    `Int' i, n
    `RM'  xy
    
    if (p.gt==1) return(J(0,2,.))
    if (p.gt==2) return(J(0,2,.))
    if (p0.xmax < p.xmin) return(J(0,2,.))
    if (p0.xmin > p.xmax) return(J(0,2,.))
    if (p0.ymax < p.ymin) return(J(0,2,.))
    if (p0.ymin > p.ymax) return(J(0,2,.))
    xy = p.XY
    n = rows(p0.XY)
    for (i=2;i<n;i++) xy = _geo_clip_area(xy, p0.XY[|i,1 \ i+1,2|])
    return(xy)
}

`RM' _geo_raster_clip_collect(`PM' I, `Bool' hasPL, `IntC' L)
{
    `Int' i, n, l, k, K, r, a, b
    `RM'  R
    
    n = rows(I)
    if (!hasPL) {
        a = 0
        for (i=n; i; i--) {
            if (I[i]==NULL) continue
            a = a + rows(*I[i])
        }
        R = J(a,6,.)
        a++
        for (i=n; i; i--) {
            if (I[i]==NULL) continue
            r = rows(*I[i])
            b = a - 1; a = a - r
            R[|a,1 \ b,6|] = J(r,1,i), *I[i]
        }
        return(R)
    }
    K = length(L)
    a = 0
    for (k=K; k; k--) {
        for (i=n; i; i--) {
            if (I[i,k]==NULL) continue
            a = a + rows(*I[i,k])
        }
    }
    R = J(a,7,.)
    a++
    for (k=K; k; k--) {
        l = L[k]
        for (i=n; i; i--) {
            if (I[i,k]==NULL) continue
            r = rows(*I[i,k])
            b = a - 1; a = a - r
            R[|a,1 \ b,7|] = J(r,1,i), *I[i,k], J(r,1,l)
        }
    }
    return(R)
}

void _geo_raster_clip_E(`RM' E, `pItems' S, `Int' pl)
{
    `Int' i, r, a, b
    `RM'  XY, ID
    
    a = 0
    for (i=rows(S); i; i--) {
        if (S[i]->gt==1) continue
        if (S[i]->gt==2) continue
        a = a + rows(S[i]->XY)
    }
    ID = J(a,1,.)
    XY = J(a,2,.)
    a++
    for (i=rows(S); i; i--) {
        if (S[i]->gt==1) continue
        if (S[i]->gt==2) continue
        r = rows(S[i]->XY)
        b = a - 1; a = a - r
        XY[|a,1 \ b,2|] = S[i]->XY // (clockwise)
        ID[|a \ b|]     = J(r, 1, S[i]->id)
    }
    E = (XY, geo_centroid(1, ID, XY), ID, J(rows(ID),1,pl)) \ E
}

end


*! {smcl}
*! {marker geo_refine}{bf:geo_refine()}{asis}
*! version 1.0.2  02jun2024  Ben Jann
*!
*! Refines polygons and lines by adding extra points such that maximum distance
*! between neighboring points is smaller than or equal to delta.
*!
*! geo_pid() is used to identify shape items; polygons and lines are assumed
*! to start with missing
*!
*! Syntax:
*!
*!      result = geo_refine(XY, delta)
*!
*!  result  n x 2 real matrix containing refined shapes
*!  XY      n x 2 real matrix containing the (X,Y) coordinates of the shape
*!          items to be refined
*!  delta   real scalar specifying threshold for adding points (minimum
*!          distance)
*!

local Int real scalar
local RS  real scalar
local RR  real rowvector
local RM  real matrix
local PC  pointer colvector

mata:
mata set matastrict on

`RM' geo_refine(`RM' XY, `RS' delta)
{
    `Int' i, n, r, k, a, b
    `RR'  xy0, xy1
    `RM'  xy, res
    `PC'  I
    
    if (cols(XY)!=2) {
        errprintf("{it:XY} must have two columns\n")
        exit(3200)
    }
    if (delta<=0) return(XY) // do not refine if delta=0
    if (delta>=.) return(XY) // do not refine if delta>=.
    if (all(_mm_unique_tag(geo_pid(., XY)))) return(XY) // point data
    // loop over coordinates ...
    n = rows(XY)
    r = 0
    I = J(n, 1, NULL)
    xy0 = (.,.)
    for (i=1;i<=n;i++) {
        xy1 = XY[i,]
        if      (hasmissing(xy1)) xy = xy1
        else if (hasmissing(xy0)) xy = xy1
        else {
            k = ceil(sqrt((xy1[1]-xy0[1])^2 + (xy1[2]-xy0[2])^2) / delta)
            if (k<2) xy = xy1 // distance not smaller than delta
            else xy = xy0 :+ (1::k-1)/k * (xy1[1]-xy0[1], xy1[2]-xy0[2]) \ xy1
        }
        r = r + rows(xy)
        I[i] = &xy[.,.]
        xy0 = xy1
    }
    // ... and collect results
    res = J(r, 2, .)
    b = 0
    for (i=1;i<=n;i++) {
        xy = *I[i]
        a = b + 1
        b = b + rows(xy)
        res[|a,1 \ b,.|] = xy
    }
    return(res)
}

end

*! {smcl}
*! {marker geo_rotate}{bf:geo_rotate()}{asis}
*! version 1.0.2  11aug2024  Ben Jann
*!
*! Rotates coordinates around (0,0) by angle degrees (counterclockwise)
*!
*! Syntax:
*!
*!      result = geo_rotate(XY, angle)
*!
*!  result  n x 2 real matrix of rotated (X,Y) coordinates
*!  XY      n x 2 real matrix of (X,Y) coordinates
*!  angle   real scalar specifying angle
*!
*! Rotate in place:
*!
*!      _geo_rotate(XY, angle)
*!

mata:
mata set matastrict on

real matrix geo_rotate(real matrix XY, real scalar angle)
{
    real scalar r
    
    if (angle==0) return(XY)
    r  = angle * pi() / 180
    return((XY[,1] * cos(r) - XY[,2] * sin(r),
            XY[,1] * sin(r) + XY[,2] * cos(r)))
}

void _geo_rotate(real matrix XY, real scalar angle)
{
    if (angle==0) return
    XY = geo_rotate(XY, angle)
}

end

*! {smcl}
*! {marker geo_simplify}{bf:geo_simplify()}{asis}
*! version 1.0.2  16jul2024  Ben Jann
*!
*! Simplify polygons and lines using Visvalingam–Whyatt algorithm
*! see: https://en.wikipedia.org/wiki/Visvalingam%E2%80%93Whyatt_algorithm
*!
*! geo_pid() is used to identify shape items; polygons and lines are assumed
*! to start with missing
*!
*! Syntax:
*!
*!      result = geo_simplify(XY, delta [, B ])
*!
*!  result  n x 1 colvector tagging points to be kept (0 drop, 1 keep)
*!  XY      n x 2 real matrix containing the (X,Y) coordinates of the shape
*!          items to be simplified
*!  delta   real scalar specifying threshold for dropping points (minimum
*!          triangle area)
*!  B       n x 1 real colvector tagging start and end points of shared
*!          borders (0 regular point, !0 start or end point of shared border);
*!          simplification will then operate by segments formed by these points,
*!          ensuring consistent simplification of shared borders across shape
*!          items
*!
*! Note that all point items will be dropped (unless delta==0). Line items that
*! are simplified to two points will be dropped unless their length is at least
*! 2*sqrt(2*delta). Polygon items that are simplified to two points will be
*! dropped.
*!

local Bool  real scalar
local BoolC real colvector
local Int   real scalar
local IntC  real colvector
local RS    real scalar
local RC    real colvector
local RR    real rowvector
local RM    real matrix
local PC    pointer colvector

mata:

`BoolC' geo_simplify(`RM' XY, `RS' delta0, | `BoolC' B)
{
    `Int'   i, n, a, b
    `RS'    delta
    `IntC'  p
    `BoolC' I
    
    // checks
    if (cols(XY)!=2) {
        errprintf("{it:XY} must have two columns\n")
        exit(3200)
    }
    n = rows(XY)
    delta = 2 * delta0 // _geo_vwhyatt() operates on 2*(triangle area)
    if (delta<=0) return(J(n,1,1)) // keep all
    // loop over shape items
    p = selectindex(_mm_unique_tag(geo_pid(., XY)))
    i = rows(p)
    if (i==n) return(J(n,1,0)) // point data; drop all
    I = J(n,1,1)
    a = n + 1
    for (;i;i--) {
        b = a - 1; a = p[i]
        if ((b-a)<2) { // item has 2 or less rows; must be point => drop
            I[|a\b|] = J(b-a+1,1,0)
            continue
        }
        _geo_simplify(I, XY, B, a, b, delta)
    }
    return(I)
}

void _geo_simplify(`BoolC' I, `RM' XY, `BoolC' B, `Int' a, `Int' b, `RS' delta)
{
    `Int' r
    
    r = b - a // note: first row in XY is missing
    if (r>2 & rows(B) ? (any(B[|a+1\b|]) ? 1 : 0) : 0) {
        // process item piece by piece if there are shared borders (and the
        // item has at least 3 points)
        I[|a+1\b|] = _geo_simplify_B(XY[|a+1,1\b,.|], B[|a+1\b|], delta, r)
    }
    else {
        // else process entire item in one go
        I[|a+1\b|] = _geo_vwhyatt(XY[|a+1,1\b,.|], delta, r)
        if (r<3) {
            if (_geo_simplify_dist(XY[a+1,], XY[b,])<2*sqrt(delta)) {
                I[a+1] = 0; I[b] = 0; r = 0
            }
        }
    }
    if (!r) I[a] = 0 // untag first row if entire item dropped
}

`BoolC' _geo_simplify_B(`RM' XY, `BoolC' B, `RS' delta, `Int' n)
{   // simplify piece by piece; B assumed fleeting; n will be updated
    `Int'   a, b, i, r, c
    `IntC'  p
    `BoolC' I
    
    I = J(n, 1, 1)
    c = 1
    // item is polygon and first row untagged: last segment wraps around
    if (XY[1,]==XY[n,] & !B[1]) {
        // get start points of segments
        p = selectindex(B)
        i = rows(p)
        // process last segment
        a = p[i]
        b = p[1]
        r = n + b - a // length of segment
        I[a::n \ 2::b] = _geo_vwhyatt(XY[a::n \ 2::b,], delta, r)
        I[1] = I[n] // update first row
        if (r>2) c = 0 // (more than 2 remaining points)
        n = r
        i--
    }
    // not a polygon or first row tagged; no wrapping needed
    else {
        B[1] = 1; B[n] = 1 // tag first and last row in any case
        p = selectindex(B) // get start points of segments
        i = rows(p) - 1    // last element of p is end point, so ignore
        a = n
        n = 0
    }
    // process (remaining) segments
    for (;i;i--) {
        b = a; a = p[i]
        r = b - a + 1
        I[|a\b|] = _geo_vwhyatt(XY[|a,1 \ b,.|], delta, r)
        if (r>2) c = 0 // (more than 2 remaining points)
        n = n + r
    }
    // if no piece has more than 2 points: check whether further simplification
    // removes the item
    if (c) {
        if (_geo_simplify_empty(selectindex(I), XY, delta)) {
            n = 0
            I = J(rows(I), 1, 0)
        }
    }
    return(I)
}

`Bool' _geo_simplify_empty(`IntC' p, `RM' XY, `RS' delta)
{
    `Int' r
    
    r = rows(p)
    (void) _geo_vwhyatt(XY[p,], delta, r)
    if (r<3) {
        if (_geo_simplify_dist(XY[p[1],], XY[p[rows(p)],])<2*sqrt(delta)) {
            return(1)
        }
    }
    return(0)
}

`RC' _geo_simplify_dist(`RM' A, `RM' B) // distance between A and B
{
    return(sqrt((A[1]-B[1])^2 + (A[2]-B[2])^2))
}

`BoolC' _geo_vwhyatt(`RM' XY, `RS' delta, `Int' r) // r will be updated
{   // tags points to be kept; delta is assumed to be equal to twice the minimum
    // triangle area
    `Int'  i, i0, i1, n
    `IntC' I
    `RC'   A
    
    n = r
    if (n<3) return(J(n,1,1)) // only two points; nothing to drop
    if (delta>=.) {
        // delta is infinity; drop all points except first and last
        r = 2
        return(1 \ J(n-2,1,0) \ 1) 
    }
    A = . \ _geo_vwhyatt_A(XY) \ .
    I = J(n, 1, 1)
    i = _geo_vwhyatt_imin(A)
    while (A[i]<delta) {
        // remove point
        A[i] = .
        I[i] = 0
        r--
        // update area of point above and below
        i1 = _geo_vwhyatt_i1(I, i)
        i0 = _geo_vwhyatt_i0(I, i)
        if (i1<n) {
            i = i1
            i1 = _geo_vwhyatt_i1(I, i)
            A[i] = _geo_vwhyatt_a(XY[i,], XY[i0,], XY[i1,])
            if (i0>1) {
                i1 = i
                i = i0
                i0 = _geo_vwhyatt_i0(I, i)
                A[i] = _geo_vwhyatt_a(XY[i,], XY[i0,], XY[i1,])
            }
        }
        else if (i0>1) {
            i = i0
            i0 = _geo_vwhyatt_i0(I, i)
            A[i] = _geo_vwhyatt_a(XY[i,], XY[i0,], XY[i1,])
        }
        else break // only 2 points left
        // get index of new minimum
        i = _geo_vwhyatt_imin(A)
    }
    return(I)
}

`Int' _geo_vwhyatt_imin(A)
{
    transmorphic i, w
    pragma unset i
    pragma unset w
    
    minindex(A, 1, i, w)
    return(i[1]) // will return error if A is all missing
}

`Int' _geo_vwhyatt_i1(`IntC' I, `Int' i)
{
    `Int' i1
    
    i1 = i + 1
    while (!I[i1]) i1++
    return(i1)
}

`Int' _geo_vwhyatt_i0(`IntC' I, `Int' i)
{
    `Int' i0
    
    i0 = i - 1
    while (!I[i0]) i0--
    return(i0)
}

`RC' _geo_vwhyatt_A(`RM' XY)
{
    `RM' xy, lo, up
    
    xy = lo = up = (2,1 \ rows(XY)-1,2)
    lo[,1] = lo[,1] :- 1
    up[,1] = up[,1] :+ 1
    return(_geo_vwhyatt_a(XY[|xy|], XY[|lo|], XY[|up|]))
}

`RC' _geo_vwhyatt_a(`RM' xy, `RM' lo, `RM' up) // returns double triangle area
{
    return(abs((up[,1]-xy[,1]) :* (lo[,2]-xy[,2])
             - (lo[,1]-xy[,1]) :* (up[,2]-xy[,2])))
}

end

*! {smcl}
*! {marker geo_spjoin}{bf:geo_spjoin()}{asis}
*! version 1.0.3  16aug2024  Ben Jann
*!
*! Spatially joins the points in xy to the polygons in XY. Note that function
*! geo_inpoly() does the same in a much more efficient way.
*!
*! Syntax:
*!
*!      result = geo_spjoin(xy, ID, PID, XY [, PL, nodots])
*!
*!  result  r x 2 matrix containing matched IDs in 1st column and matching
*!          flag in 2nd column (1 if matched, 0 else)
*!  xy      r x 2 matrix containing points to be matched
*!  ID      n x 1 real colvector of unit IDs
*!  PID     n x 1 real colvector of within-unit polygon IDs
*!  XY      n x 2 real matrix of (X,Y) coordinates of the polygons; missing
*!          coordinates will be ignored
*!  PL      optional n x 1 real colvector containing plot level indicator 
*!  nodots  nodots!=0 suppresses progress dots
*!

local Bool      real scalar
local Int       real scalar
local IntC      real colvector
local RS        real scalar
local RC        real colvector
local RM        real matrix
local SS        string scalar
local POLYGON   _geo_POLYGON
local Polygon   struct `POLYGON' scalar
local pPolygon  pointer (`Polygon') scalar
local UNIT      _geo_UNIT
local Unit      struct `UNIT' scalar
local pUnits    pointer (`Unit') vector

mata:
mata set matastrict on

`RM' geo_spjoin(`RM' xy, `RC' ID, `RC' PID, `RM' XY, | `RC' PL, `Bool' nodots)
{
    `Int'    i, n
    `IntC'   p, P
    `RC'     L
    `RM'     id
    pointer  pl
    
    if (args()<6) nodots = 0
    if (cols(xy)!=2) {
        errprintf("{it:XY} must have two columns\n")
        exit(3200)
    }
    if (!rows(PL)) return(_geo_spjoin(xy, ID, PID, XY, 0, nodots, "("))
    if (hasmissing(PL)) pl = &editmissing(PL, 0) // treat missing as 0
    else                pl = &PL
    L  = mm_unique(select(*pl, _mm_uniqrows_tag((ID, PID))))
    id = J(rows(xy), 2, .) // second column will be used to tag matched points
    p  = . // use all points in first round
    n = length(L)
    for (i=n;i;i--) {
        P      = selectindex(*pl:==L[i])
        id[p,] = _geo_spjoin(xy[p,], ID[P], PID[P], XY[P,], mod(L[i],2), nodots,
            sprintf("(pass %g/%g: ", n-i+1, n))
        if (i>1) p = selectindex(!id[,2]) // remaining unmatched points
    }
    return(id[,1], editvalue(id[,2],2,0/*reset points inside enclaves*/))
}

`RM' _geo_spjoin(`RM' xy, `RC' ID, `RC' PID, `RM' XY, `Bool' enclave,
    `Bool' nodots, `SS' msg)
{
    `Int'    i, i0, n, ii
    `IntC'   p
    `RM'     id
    `pUnits' u
    
    if (!nodots) i0 = _geo_progress_init(msg)
    u = _geo_collect_units(ID, PID, XY)
    n = rows(xy)
    id = J(n, 1, (.,0)) // second column: set 1 if matched
    p = unorder(n) // (evaluate points in random order for even progress)
    for (i=n;i;i--) {
        ii = p[i]
        id[ii,] = __geo_spjoin(xy[ii,1], xy[ii,2], enclave, u)
        if (!nodots) _geo_progress(i0, 1-(i-1)/n)
    }
    if (!nodots) _geo_progress_end(i0, ")")
    return(id)
}

`RM' __geo_spjoin(`RS' px, `RS' py, `Bool' enclave, `pUnits' u)
{
    `Int'      i, j, m
    `pPolygon' p
    
    for (i=length(u);i;i--) {
        for (j=u[i]->n;j;j--) {
            p = u[i]->p[j]
            if (px < p->xmin) continue
            if (px > p->xmax) continue
            if (py < p->ymin) continue
            if (py > p->ymax) continue
            if (m=geo_pointinpolygon(px, py, p->XY)) {
                // if not enclave: return id of matching unit
                if (!enclave) return((u[i]->id,1))
                // if enclave and inside: tag as matched, but do not return ID
                if (m==1)     return((.,2))
                // if enclave and on edge: do not tag, but exit search
                              return((.,0))
            }
        }
    }
    return((.,0))
}

end

*! {smcl}
*! {marker geo_symbol}{bf:symbol()}{asis}
*! version 1.0.5  01aug2024  Ben Jann
*!
*! Returns the coordinates of a selected symbol
*!
*! Syntax:
*!
*!      result = geo_symbol("symbol" [, n, "arg"])
*!
*!  result  r x 2 real matrix of the (X,Y) coordinates or r x 3 real matrix
*!          of the (X,Y) coordinates and a plot level indicator
*!  symbol  name of symbol
*!  n       real scalar specifying number of points on circle; use symbol
*!          "circle" with low n to create a regular polygons, e.g.
*!          geo_symbol("circle", 6) for a hexagon
*!  arg     string scalar containing symbol-specific arguments
*!

mata:
mata set matastrict on

real matrix geo_symbol(string scalar sym, | real scalar n, string scalar arg)
{
    pointer(real matrix function) scalar f
    
    if (sym=="")                f = &_geo_symbol_circle()
    else if (sym=="circle")     f = &_geo_symbol_circle()
    else if (sym=="slice")      f = &_geo_symbol_slice()
    else if (sym=="arc")        f = &_geo_symbol_arc()
    else if (sym=="pentagram")  f = &_geo_symbol_pentagram()
    else if (sym=="hexagram")   f = &_geo_symbol_hexagram()
    else if (sym=="pin")        f = &_geo_symbol_pin()
    else if (sym=="pin2")       f = &_geo_symbol_pin2()
    else {
        f = findexternal("_geo_symbol_" + sym + "()")
        if (f==NULL) {
            errprintf("geo_symbol(): symbol '%s' not found\n", sym)
            exit(111)
        }
    }
    return((*f)(n, arg))
}

real matrix _geo_symbol_circle(| real scalar n0, string scalar arg)
{
    real colvector r, n
    real matrix    xy
    pragma unused arg
    
    if (n0>=.) n = 100
    else       n = n0
    r = .25 - .5/n // set angle such that shape has horizontal edge at bottom
    r = rangen(-r, 1-r, n+1) * (2 * pi())
    xy = (cos(r), sin(r))
    xy[n+1,] = xy[1,] // for sake of precision
    return(xy)
}

real matrix _geo_symbol_slice(| real scalar n, string scalar arg)
{
    return((0,0) \ _geo_symbol_arc(n, arg) \ (0,0))
}

real matrix _geo_symbol_arc(| real scalar n0, string scalar arg)
{
    real scalar    n, angle
    real colvector r
    
    if (arg=="") angle = 180 // default
    else {
        angle = strtoreal(arg)
        if (angle<-360 | angle>360) {
            errprintf("symbol arc: {it:angle} must be in [-360,360]\n")
            exit(125)
        }
    }
    if (n0>=.) n = max((2, ceil(abs(angle)/360 * 100)))
    else       n = n0
    r = rangen(0, angle/180, n) * pi()
    return((cos(r), sin(r)))
}

real matrix _geo_symbol_star(| real scalar n, string scalar arg)
{
    real matrix XY, xy
    pragma unused n
    pragma unused arg
    
    // outer pentagon
    XY = _geo_symbol_circle(5)
    // inner pentagon
    xy = _geo_symbol_circle(5) / (.5 * (1 + sqrt(5)))^2
    _geo_rotate(xy, 180)
    // merge
    XY = colshape((XY[1::5,], (xy[4::5,] \ xy[1::3,])), 2)
    XY = XY \ XY[1,] // last point = first point
    return(XY)
}

real matrix _geo_symbol_star6(| real scalar n, string scalar arg)
{
    real matrix XY, xy
    pragma unused n
    pragma unused arg
    
    // outer hexagon
    XY = _geo_symbol_circle(6)
    _geo_rotate(XY, 90)
    // inner hexagon
    xy = _geo_symbol_circle(6) * sqrt(1/3)
    // merge
    XY = colshape(((XY[5::6,] \ XY[1::4,]), xy[1::6,]), 2)
    XY = XY \ XY[1,] // last point = first point
    return(XY)
}

real matrix _geo_symbol_hexagram(| real scalar n, string scalar arg)
{
    real matrix XY
    pragma unused n
    pragma unused arg
    
    XY = _geo_symbol_star6()
    return(XY[(1,5,9,1),] \ (.,.) \ XY[(7,11,3,7),])
}

real matrix _geo_symbol_pentagram(| real scalar n, string scalar arg)
{
    pragma unused n
    pragma unused arg
    
    return(_geo_symbol_star()[(1,5,9,3,7,1),])
}

real matrix _geo_symbol_pin(| real scalar n0, string scalar arg)
{
    real colvector n, r, h
    real matrix    xy
    
    if (arg=="") h = 1/3 // default
    else {
        h = strtoreal(arg)
        if (h<0 | h>1) {
            errprintf("symbol pin: {it:headsize} must be in [0,1]\n")
            exit(125)
        }
    }
    if (n0>=.) n = max((4, ceil(h * 100)))
    else       n = n0
    r = rangen(-.25, .75, n+1) * (2 * pi())
    xy = h * (cos(r), sin(r))
    xy[,2] = xy[,2] :+ (2-h)
    xy = xy \ (0,0) \ (0,2-2*h)
    return(xy)
}

real matrix _geo_symbol_pin2(| real scalar n0, string scalar arg)
{
    real colvector n, r, a, c
    real matrix    xy0, xy1
    
    if (arg=="") a = .6 // default
    else {
        a = strtoreal(arg)
        if (a<0 | a>1) {
            errprintf("symbol pin2: {it:headsize} must be in [0,1]\n")
            exit(125)
        }
    }
    if (n0>=.) n = max((4, ceil(a * 100)))
    else       n = n0
    // outer polygon (counterclockwise)
    c = 2 - a
    r = rangen(-asin(a/c), pi()+asin(a/c), n+1)
    xy0 = a * (cos(r),sin(r))
    xy0[,2] = xy0[,2] :+ c
    xy0 = xy0 \ (0,0) \ xy0[1,] 
    xy0 = xy0, J(rows(xy0),1,0) // plevel=0
    // inner polygon (clockwise)
    r = rangen(1, 0, n+1) * (2 * pi())
    xy1 = (0.5*a) * (cos(r), sin(r))
    xy1[,2] = xy1[,2] :+ c
    xy1 = (.,.) \ xy1
    xy1 = xy1, J(rows(xy1),1,1) // plevel=1
    return(xy0 \ xy1)
}

real matrix _geo_symbol_pin3(| real scalar n0, string scalar arg)
{
    real colvector n, r, a, c
    real matrix    xy
    
    if (arg=="") a = 1/3 // default
    else {
        a = strtoreal(arg)
        if (a<0 | a>1) {
            errprintf("symbol pin3: {it:headsize} must be in [0,1]\n")
            exit(125)
        }
    }
    if (n0>=.) n = max((4, ceil(a * 100)))
    else       n = n0
    c = 2 - a
    r = rangen(-asin(a/c), pi()+asin(a/c), n+1)
    xy = a * (cos(r),sin(r))
    xy[,2] = xy[,2] :+ c
    return(xy \ (0,0) \ xy[1,] )
}

real matrix _geo_symbol_line(| real scalar n, string scalar arg)
{
    pragma unused n
    pragma unused arg
    
    return((-1,0) \ (1,0))
}

real matrix _geo_symbol_pipe(| real scalar n, string scalar arg)
{
    pragma unused n
    pragma unused arg
    
    return((0,-1) \ (0,1))
}

real matrix _geo_symbol_plus(| real scalar n, string scalar arg)
{
    pragma unused n
    pragma unused arg
    
    return((-1,0) \ (1,0) \ (.,.) \ (0,-1) \ (0,1))
}

real matrix _geo_symbol_x(| real scalar n, string scalar arg)
{
    real scalar r
    pragma unused n
    pragma unused arg
    
    r = sin(.25*pi())
    return((-r,-r) \ (r,r) \ (.,.) \ (-r,r) \ (r,-r))
}

real matrix _geo_symbol_diamond(| real scalar n, string scalar arg)
{
    pragma unused n
    pragma unused arg
    
    return((0,-1) \ (1,0) \ (0,1) \ (-1,0) \ (0,-1))
}

real matrix _geo_symbol_v(| real scalar n, string scalar arg)
{
    real scalar r
    pragma unused n
    pragma unused arg
    
    r = cos(.5/3 * pi())
    return((-r,.5) \ (0,-1) \ (.,.) \ (0,-1) \ (r,.5))
}

real matrix _geo_symbol_arrow(| real scalar n, string scalar arg)
{
    real scalar    l, w
    real rowvector ARG
    pragma unused n
    
    ARG = strtoreal(tokens(arg))
    if (length(ARG)<2) ARG = ARG, J(1,2-length(ARG),.)
    l = ARG[1]; w = ARG[2]
    if (l>=.) l = .5
    if (w>=.) w = 2/3
    l = 1 - l*2
    return((-1,0) \ (1,0) \ (.,.) \ (1,0) \ (l,w) \ (.,.) \ (1,0) \ (l,-w))
}

real matrix _geo_symbol_barrow(| real scalar n, string scalar arg)
{
    real scalar    l, w
    real rowvector ARG
    pragma unused n
    
    ARG = strtoreal(tokens(arg))
    if (length(ARG)<2) ARG = ARG, J(1,2-length(ARG),.)
    l = ARG[1]; w = ARG[2]
    if (l>=.) l = .375
    if (w>=.) w = .5
    l = 1 - l*2
    return((-1,0) \ (-l,w) \ (.,.) \ (-1,0) \ (-l,-w) \ (.,.) \
           (-1,0) \ ( 1,0) \ (.,.) \
           ( 1,0) \ ( l,w) \ (.,.) \ ( 1,0) \ ( l,-w))
}

real matrix _geo_symbol_farrow(| real scalar n, string scalar arg)
{
    real scalar    l, w, b
    real rowvector ARG
    pragma unused n

    ARG = strtoreal(tokens(arg))
    if (length(ARG)<3) ARG = ARG, J(1,3-length(ARG),.)
    l = ARG[1]; w = ARG[2]; b = ARG[3]
    if (l>=.) l = .5
    if (w>=.) w = .5
    if (b>=.) b = .2
    l = 1 - l*2
    return((-1,b) \ (l,b) \ (l,w) \ (1,0) \ (l,-w) \ (l,-b) \ (-1,-b) \ (-1, b))
}

real matrix _geo_symbol_fbarrow(| real scalar n, string scalar arg)
{
    real scalar    l, w, b
    real rowvector ARG
    pragma unused n

    ARG = strtoreal(tokens(arg))
    if (length(ARG)<3) ARG = ARG, J(1,3-length(ARG),.)
    l = ARG[1]; w = ARG[2]; b = ARG[3]
    if (l>=.) l = 1/3
    if (w>=.) w = 1/3
    if (b>=.) b = 1/8
    l = 1 - l*2
    return((-1,0) \ (-l,w) \ (-l,b) \ (l,b) \ (l,w) \ (1,0) \ (l,-w) \ 
           (l,-b) \ (-l,-b) \ (-l,-w) \ (-1,0))
}

real matrix _geo_symbol_bar(| real scalar n, string scalar arg)
{
    real scalar h
    pragma unused n

    h = strtoreal(arg)
    if (h>=.) h = 1/3
    return((-1,-h) \ (1,-h) \ (1,h) \ (-1,h) \ (-1,-h))
}

real matrix _geo_symbol_cross(| real scalar n, string scalar arg)
{
    real scalar h
    pragma unused n

    h = strtoreal(arg)
    if (h>=.) h = 1/3
    return((-h,-1) \ (h,-1) \ (h,-h) \ (1,-h) \ (1,h) \ (h,h) \ (h,1) \
            (-h,1) \ (-h,h) \ (-1,h) \ (-1,-h) \ (-h,-h) \ (-h,-1))
}

real matrix _geo_symbol_asterisk(| real scalar n, string scalar arg)
{
    real scalar k, i
    real matrix p, xy
    pragma unused n
    
    k = trunc(strtoreal(arg))
    if      (k>=.) k = 6
    else if (k<2)  k = 2
    p = rangen(.25, 1.25, k+1) * (2 * pi())
    p = round((cos(p), sin(p)), 1e-14)
    xy = J(k*3-1, 2, .)
    for (;k;k--) {
        i = (k*3) - 2
        xy[i,]   = (0,0)
        xy[i+1,] = p[k,]
    }
    return(xy)
}

real matrix _geo_symbol_fasterisk(| real scalar n, string scalar arg)
{
    real scalar    k, w, r
    real matrix    xy, XY
    real rowvector ARG
    pragma unused n
    
    ARG = strtoreal(tokens(arg))
    if (length(ARG)<2) ARG = ARG, J(1,2-length(ARG),.)
    k = trunc(ARG[1]); w = ARG[2]
    if      (k>=.) k = 6
    else if (k<=2) k = 2
    if (w>=.) w = .2 // should depend on k 
    if (k==2) return((0-w,1) \ (0-w,-1) \ (0+w,-1) \ (0+w,1) \ (0-w,1))
    r = 360 / k
    xy = (0-w,1)\(0-w,0) \ geo_rotate((0+w,1)\(0+w,0), r)
    xy = xy[1,] \ _geo_symbol_fasterisk_intersect(xy) \ xy[3,]
    XY = J(0,2,.)
    for (;k;k--) {
        XY = XY \ xy
        _geo_rotate(xy, r)
    }
    return(XY \ XY[1,])
}

real rowvector _geo_symbol_fasterisk_intersect(real matrix xy)
{
    real scalar a, b, d
    
    a = (xy[1,1] * xy[2,2] - xy[1,2] * xy[2,1])
    b = (xy[3,1] * xy[4,2] - xy[3,2] * xy[4,1])
    d = (xy[1,1] - xy[2,1]) * (xy[3,2] - xy[4,2]) -
        (xy[1,2] - xy[2,2]) * (xy[3,1] - xy[4,1])
    return(((a * (xy[3,1] - xy[4,1]) - (xy[1,1] - xy[2,1]) * b),
            (a * (xy[3,2] - xy[4,2]) - (xy[1,2] - xy[2,2]) * b)) / d)
}

real matrix _geo_symbol_trapezoid(| real scalar n, string scalar arg)
{
    real scalar l, h
    pragma unused n

    l = strtoreal(arg)
    if (l>=.) l = .5
    h = .5
    return((-1,-h) \ (1,-h) \ (l,h) \ (-l,h) \ (-1,-h))
}

end

*! {smcl}
*! {marker geo_tissot}{bf:geo_tissot()}{asis}
*! version 1.0.0  26may2024  Ben Jann
*!
*! Compute (unprojected) Tissot's indicatrix at a given point and radius
*! (see https://en.wikipedia.org/wiki/Tissot%27s_indicatrix); based on code
*! from -geo2xy- (from SSC) by Robert Picard (program -geo2xy_tissot- in
*! geo2xy.ado)
*!
*! Syntax:
*!
*!      XY = geo_tissot(x, y, r, n)
*!
*!  XY         (n+1) x 2 real matrix containing coordinates of Tissot polygon
*!  x          real scalar specifying X coordinate of point (in degrees)
*!  y          real scalar specifying Y coordinate of point (in degrees)
*!  r          real scalar specifying radius (in degrees);
*!             y +/- r must within +/- 90 for valid results
*!  n          real scalar setting number of edges of polygon
*!
*!  Function _geo_tissot() is like geo_tissot(), but with input and output in
*!  radians rather than degrees.

mata:
mata set matastrict on

real matrix geo_tissot(real scalar x, real scalar y, real scalar r,
    real scalar n)
{
    return(_geo_tissot(x*pi()/180, y*pi()/180, r*pi()/180, n)*(180/pi()))
}

real matrix _geo_tissot(real scalar x, real scalar y, real scalar r,
    real scalar n)
{
    real colvector b, Y
    
    b = rangen(0, 2*pi(), n+1)
    b[n+1] = 0 // for sake of precision (last point = first point)
    Y = asin(sin(y) * cos(r) :+ cos(y) * sin(r) :* cos(b))
    return((
        x :+ atan2(cos(r) :- sin(y) * sin(Y), sin(b) :* sin(r) * cos(y)),
        Y))
}

end

*! {smcl}
*! {marker geo_welzl}{bf:geo_welzl()}{asis}
*! version 1.0.1  30jul2025  Ben Jann
*!
*! Find minimum enclosing circle using Welzl's algorithm; based on
*! https://www.geeksforgeeks.org/minimum-enclosing-circle-using-welzls-algorithm/
*! and
*! https://stackoverflow.com/questions/50925307/iterative-version-of-welzls-algorithm
*!
*! Syntax:
*!
*!      circle = geo_welzl(XY [, recursive])
*!
*!  circle     real rowvector containing mid and radius (X,Y,R)
*!  XY         n x 2 real matrix containing points; rows containing missing
*!             will be ignored
*!  recursive  recursive!=0 requests the recursive algorithm
*!

local RS      real scalar
local Bool    real scalar
local Int     real scalar
local Point   real rowvector  // (X,Y)
local Points  real matrix     // (X,Y) \ (X,Y) \ ...
local Circle  real rowvector  // (X,Y,R)
local FRAME   _geo_welzl_frame
local Frame   struct `FRAME' scalar
local PFrame  pointer (`Frame') scalar
local PFrames pointer (`Frame') rowvector
local FRAMES  _geo_welzl_frames
local Frames  struct `FRAMES' scalar

mata:
mata set matastrict on

// main function

`Circle' geo_welzl(`Points' XY, | `Bool' recursive)
{
    pointer (`Points') scalar xy
    
    if (args()<2) recursive = 0
    if (cols(XY)!=2) {
        errprintf("{it:XY} must have two columns\n")
        exit(3200)
    }
    if (isfleeting(XY)) xy = &XY
    else                xy = &J(1,1,XY)
    if (hasmissing(*xy)) *xy = select(*xy, !rowmissing(*xy))
    *xy = jumble(select(*xy, mm_uniqrows_tag(*xy)))
    if (recursive) return(_geo_welzl_recursive(*xy, J(0,2,.), rows(*xy)))
    return(_geo_welzl_iterative(*xy))
}

// iterative variant of Welzl algorithm

struct `FRAME' {
    `Int'    s  // stage
    `Int'    n  // current n
    `Point'  p  // selected point
    `Points' r  // up to three selected points
}

`Frame' _geo_welzl_frame_copy(`Frame' f0)
{
    `Frame' f
    
    f = f0
    return(f)
}

struct `FRAMES' {
    `Int'     n  // current length
    `PFrames' F  // stack of frames
}

`PFrame' _geo_welzl_frames_pop(`Frames' frames)
{
    `PFrame' f
    
    f = frames.F[frames.n]
    frames.n = frames.n - 1
    return(f)
}

void _geo_welzl_frames_append(`Frames' frames, `PFrame' f)
{
    frames.n = frames.n + 1
    frames.F[frames.n] = f
}

`Circle' _geo_welzl_iterative(`Points' P)
{
    `Circle'  c
    `PFrame'  frame
    `Frames'  frames
    
    // initialize frames stacks
    frames.n       = 1
    frames.F       = J(1, rows(P)+1, NULL)
    frames.F[1]    = &(`FRAME'())
    frames.F[1]->s = 1
    frames.F[1]->n = rows(P)
    frames.F[1]->r = J(0,2,.)
    // iterate
    while (frames.n) {
        frame = _geo_welzl_frames_pop(frames)
        if (frame->n==0 | rows(frame->r)==3) {
            c = _geo_welzl_min_circle_trivial(frame->r)
        }
        else if (frame->s==1) {
            frame->p     = P[1,] // pick 1st (input has been jumbled)
            P[1,]        = P[frame->n,]
            P[frame->n,] = frame->p
            frame->s     = 2
            _geo_welzl_frames_append(frames, frame)
            frame        = &_geo_welzl_frame_copy(*frame)
            frame->s     = 1
            frame->n     = frame->n - 1
            _geo_welzl_frames_append(frames, frame)
        }
        else if (frame->s==2) {
            if (!_geo_welzl_is_inside(c, frame->p)) {
                frame->s = 1
                frame->n = frame->n - 1
                frame->r = frame->r \ frame->p
                _geo_welzl_frames_append(frames, frame)
            }
        }
    }
    return(c)
}

// recursive Welzl algorithm

`Circle' _geo_welzl_recursive(`Points' P, `Points' R0, `Int' n)
{
    `Point'  p
    `Circle' d
    `Points' R
    
    R = R0 // work on copy!
    if (n == 0 | rows(R) == 3) return(_geo_welzl_min_circle_trivial(R))
    p     = P[1,] // pick 1st (input has been jumbled)
    P[1,] = P[n,]
    P[n,] = p
    d     = _geo_welzl_recursive(P, R, n - 1)
    if (_geo_welzl_is_inside(d, p)) return(d)
    R     = R \ p
    return(_geo_welzl_recursive(P, R, n - 1))
}

// helper functions

// - get minimum enclosing circle given 3 or less points
`Circle' _geo_welzl_min_circle_trivial(`Points' P)
{
    `Int' n
    
    n = rows(P)
    assert(n <= 3)
    if (n == 0) return(J(1,3,0))
    if (n == 1) return((P,0))
    if (n == 2) return(_geo_welzl_circle_from2(P[1,], P[2,]))
    return(_geo_welzl_circle_from3(P[1,], P[2,], P[3,]))
}

// - get unique circle that intersects three points
`Circle' _geo_welzl_circle_from3(`Point' A, `Point' B, `Point' C)
{
    `RS'     bx, by, cx, cy, b, c, d
    `Circle' D
    
    bx = B[1] - A[1]
    by = B[2] - A[2]
    cx = C[1] - A[1]
    cy = C[2] - A[2]
    b  = bx^2 + by^2
    c  = cx^2 + cy^2
    d  = 2 * (bx * cy - by * cx)
    D  = A + ((cy * b - by * c) / d, (bx * c - cx * b) / d)
    D  = D, _geo_welzl_dist(D, A)
    return(D)
}

// - get smallest circle that intersects 2 points
`Circle' _geo_welzl_circle_from2(`Point' A, `Point' B)
{
    return(((A[1] + B[1]) / 2, (A[2] + B[2]) / 2, _geo_welzl_dist(A, B) / 2))
}

// - check whether a point lies inside or on the boundaries of the circle
`Bool' _geo_welzl_is_inside(`Circle' c, `Point' p)
{
    return(_geo_welzl_dist(c[(1,2)], p) <= c[3])
}

// - euclidean distance between two points
`RS' _geo_welzl_dist(`Point' a, `Point' b)
{
    return(sqrt((a[1] - b[1])^2 + (a[2] - b[2])^2))
}

end

*! {smcl}
*! {marker geo_wkt2xy}{bf:geo_wkt2xy()}{asis}
*! version 1.0.0  02dec2023  Ben Jann
*!
*! Extracts the coordinates form a WKT geometry specification ("Well-known text
*! representation of geometry geometry; see
*! https://en.wikipedia.org/wiki/Well-known_text_representation_of_geometry).
*! Supported geometry types are Point, MultiPoint, LineString, MultiLineString,
*! Polygon, MultiPolygon, and GeometryCollection (case insensitive).
*! In the returned matrix of coordinates, each extracted line or polygon and,
*! in case of a GeometryCollection, each point will start with a row of missing
*! values. Missing rows will be omitted by default when extracting coordinates
*! from a Point or MultiPoint specification.
*!
*!      XY = geo_wkt2xy(s [, mis, gtype, rc])
*!
*!  XY      n x 2 real matrix containing the extracted coordinates; J(1,2,.) is
*!          returned if no coordinates are found
*!  s       string scalar containing the WKT specification
*!  mis     mis!=0 enforces separating points by missing in any case
*!  gtype   string scalar that will be set to the geometry type of s
*!  rc      real scalar that will be set to 1 if an issue occurred (invalid
*!          or incomplete WKT specification); else 0
*!

local Bool real scalar
local Int  real scalar
local RR   real rowvector
local RM   real matrix
local SS   string scalar
local SR   string rowvector
local T    transmorphic

mata:
mata set matastrict on

// main function: determine geometry type and launch relevant parser
`RM' geo_wkt2xy(`SS' S, | `Bool' mis, `SS' kw, `Bool' rc)
{
    `SS' s
    `RM' XY
    `T'  t
    
    if (args()<2) mis = 0
    rc = 0
    t = tokeninit("", ",", "()")
    tokenset(t, S)
    kw = strtrim(strlower(tokenget(t)))
    s  = tokenget(t)
    _geo_wkt2xy_pstrip(rc, t, s)
    if (tokenrest(t)!="") rc = 1
    XY = J(0,2,.)
    if (kw=="point") {
        kw = "Point"
        _geo_wkt2xy_p(rc, XY, s, mis!=0)
    }
    else if (kw=="multipoint") {
        kw = "MultiPoint"
        _geo_wkt2xy_P(t, rc, XY, s, mis!=0)
    }
    else if (kw=="linestring") {
        kw = "LineString"
        _geo_wkt2xy_l(rc, XY, s)
    }
    else if (kw=="multilinestring") {
        kw = "MultiLineString"
        _geo_wkt2xy_L(t, rc,  XY, s)
    }
    else if (kw=="polygon") {
        kw = "Polygon"
        _geo_wkt2xy_s(t, rc, XY, s)
    }
    else if (kw=="multipolygon") {
        kw = "MultiPolygon"
        _geo_wkt2xy_S(t, rc, XY, s)
    }
    else if (kw=="geometrycollection") {
        kw = "GeometryCollection"
        _geo_wkt2xy_C(t, rc, XY, s)
    }
    else {
        rc = 1
        kw = ""
    }
    if (!rows(XY)) XY = (.,.)
    return(XY)
}

// parser for geometrycollection
void _geo_wkt2xy_C(`T' t0, `Bool' rc, `RM' XY, `SS' S)
{
    `SS' kw, s
    `T'  t
    
    t = t0
    tokenset(t, S)
    while ((kw = tokenget(t))!="") {
        if (kw==",") continue
        kw = strtrim(strlower(kw))
        s  = tokenget(t)
        _geo_wkt2xy_pstrip(rc, t, s)
        if      (kw=="point")           _geo_wkt2xy_p(rc, XY, s, 1)
        else if (kw=="multipoint")      _geo_wkt2xy_P(t0, rc, XY, s, 1)
        else if (kw=="linestring")      _geo_wkt2xy_l(rc, XY, s)
        else if (kw=="multilinestring") _geo_wkt2xy_L(t0, rc,  XY, s)
        else if (kw=="polygon")         _geo_wkt2xy_s(t0, rc, XY, s)
        else if (kw=="multipolygon")    _geo_wkt2xy_S(t0, rc, XY, s)
        else rc = 1
    }
}

// parser for point
void _geo_wkt2xy_p(`Bool' rc, `RM' XY, `SS' S, `Bool' mis)
{
    XY = XY \ J(mis, 2, .) \ __geo_wkt2xy_xy(rc, S)
}

// parser for points
void _geo_wkt2xy_P(`T' t0, `Bool' rc, `RM' XY, `SS' S, `Bool' mis)
{
    `SS' s
    `T'  t
    
    t = t0
    tokenset(t, S)
    while ((s = tokenget(t))!="") {
        if (s==",") continue
        if (strtrim(s)=="") continue
        // note; parentheses are optional; cannot use _geo_wkt2xy_pstrip()
        if (substr(s,1,1)=="(") {
            s = strltrim(substr(s,2,.))
            if (substr(s,-1,1)==")") s = strrtrim(substr(s,1,strlen(s)-1))
            else rc = 1 // opening paren only
        }
        else if (substr(s,-1,1)==")") {
            s = strrtrim(substr(s,1,strlen(s)-1))
            rc = 1 // closing paren only
        }
        _geo_wkt2xy_p(rc, XY, s, mis)
    }
}

// parser for line
void _geo_wkt2xy_l(`Bool' rc, `RM' XY, `SS' S)
{
    XY = XY \ _geo_wkt2xy_xy(rc, S)
}

// parser for lines
void _geo_wkt2xy_L(`T' t0, `Bool' rc, `RM' XY, `SS' S)
{
    `SS' s
    `T'  t
    
    t = t0
    tokenset(t, S)
    while ((s = tokenget(t))!="") {
        if (s==",") continue
        if (strtrim(s)=="") continue
        _geo_wkt2xy_pstrip(rc, t, s)
        _geo_wkt2xy_l(rc, XY, s)
    }
}

// parser for polygon
void _geo_wkt2xy_s(`T' t0, `Bool' rc, `RM' XY, `SS' S)
{
    `SS' s
    `T'  t
    
    t = t0
    tokenset(t, S)
    while ((s = tokenget(t))!="") {
        if (s==",") continue
        if (strtrim(s)=="") continue
        _geo_wkt2xy_pstrip(rc, t, s)
        XY = XY \ _geo_wkt2xy_xy(rc, s)
    }
}

// parser for multipolygon
void _geo_wkt2xy_S(`T' t0, `Bool' rc, `RM' XY, `SS' S)
{
    `SS' s
    `T'  t
    
    t = t0
    tokenset(t, S)
    while ((s = tokenget(t))!="") {
        if (s==",") continue
        if (strtrim(s)=="") continue
        _geo_wkt2xy_pstrip(rc, t, s)
        _geo_wkt2xy_s(t0, rc, XY, s)
    }
}

// collect coordinates of a single item
`RM' _geo_wkt2xy_xy(`Bool' rc, `SS' s)
{
    `Int' i, n
    `SR'  S
    `RM'  XY
    
    S = tokens(s, ",")
    S = select(S, S:!=",")
    n = length(S)
    if (!n) { // item is empty
        rc = 1
        return(J(0,2,.))
    }
    XY = J(n, 2, .)
    for (i=1;i<=n;i++) XY[i,] = __geo_wkt2xy_xy(rc, S[i])
    return((.,.) \ XY) // add leading row containing missing
}

`RR' __geo_wkt2xy_xy(`Bool' rc, `SS' s)
{
    `Int' j
    `RR'  xy
    
    xy = strtoreal(tokens(s))
    j = length(xy)
    if (j!=2) {
        rc = 1
        if (j>2)       xy = xy[(1,2)] // too many elements
        else if (j==1) xy = (xy,.)    // too few element
        else           xy = (.,.)     // too few element
    }
    return(xy)
}

// remove outer parentheses (sets rc = 1 if no outer parentheses)
void _geo_wkt2xy_pstrip(`Bool' rc, `T' t, `SS' s)
{
    if (substr(s,1,1)=="(") {
        s = strltrim(substr(s,2,.))
        if (substr(s,-1,1)==")") s = strrtrim(substr(s,1,strlen(s)-1))
        else {
            rc = 1
            s = s + tokenrest(t) // add rest if closing paren is missing
            tokenset(t, "")
        }
    }
    else {
        if (substr(s,-1,1)==")") s = strrtrim(substr(s,1,strlen(s)-1))
        rc = 1
    }
}

end

*! {smcl}
*! {marker _geo_progress}{bf:_geo_progress()}{asis}
*! version 1.0.1  23jun2024  Ben Jann
*!
*! Helper function to display progress dots.
*!
*! Syntax:
*!
*!      j = _geo_progress_init(prefix)
*!      ...
*!      _geo_progress(j, p)
*!      ...
*!      _geo_progress_end(j, suffix)
*!
*!  j       real scalar containing progress counter
*!  p       real scalar specifying proportion of progress
*!  prefix  string scalar specifying prefix to be printed
*!  suffix  string scalar specifying suffix to be printed
*!

local Int       real scalar
local SS        string scalar

mata:
mata set matastrict on

`Int' _geo_progress_init(`SS' msg)
{
    displayas("txt")
    printf("%s0%%", msg)
    displayflush()
    return(0)
}

void _geo_progress(`Int' j, `Int' p)
{
    while (1) {
        if (j>=40) break
        if (p < (j+1)/40) break
        j++
        if (mod(j,4)) {
            printf(".")
            displayflush()
        }
        else {
            printf("%g%%", j/4*10)
            displayflush()
        }
    }
}

void _geo_progress_end(`Int' j, `SS' msg)
{
    _geo_progress(j, 1) // complete to 100% if necessary
    printf("%s\n", msg)
    displayflush()
}

end

*! {smcl}
*! {marker varia}Further functions{asis}
*! version 1.0.0  30jun2024  Ben Jann
*!

mata:
mata set matastrict on

void _geo_parse_marginexp(string scalar nm, string scalar s,
    | real scalar lb, real scalar def)
{
    real scalar    i, n
    real rowvector R
    string scalar  tok
    transmorphic   t
    
    if (args()<4) def = 0
    R = strtoreal(tokens(s))
    n = length(R)
    if (!n) { // empty
        st_local(nm, invtokens(strofreal(J(1,4,def))))
        return
    }
    if (!hasmissing(R)) { // all numeric
        if (n<4) {
            R = R, J(1,4-n,.)
            for (i=4;i>=n;i--) R[i] = R[mod(i-1,n)+1] // recycle
        }
        else if (n>4) R = R[|1\4|]
    }
    else {
        R = J(1,4,def)
        t = tokeninit(" ", "=")
        tokenset(t, s)
        while ((tok = tokenget(t))!="") {
            i = 0
            if      (tok=="l") i = 1
            else if (tok=="r") i = 2
            else if (tok=="b") i = 3
            else if (tok=="t") i = 4
            if (i) {
                if (tokenpeek(t)=="=") (void) tokenget(t) // remove "="
                R[i] = strtoreal(tokenget(t))
                continue
            }
            errprintf("invalid {bf:%s()}\n", nm)
            exit(198)
        }
    }
    if (hasmissing(R)) {
        errprintf("invalid {bf:%s()}; missing not allowed\n", nm)
        exit(198)
    }
    if (lb<.) {
        if (any(R:<lb)) {
            errprintf("invalid {bf:%s()}; has values out of range\n", nm)
            exit(198)
        }
    }
    st_local(nm, invtokens(strofreal(R)))
}

end
