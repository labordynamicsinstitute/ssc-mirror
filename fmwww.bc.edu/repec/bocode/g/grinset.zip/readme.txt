Recommended installation procedure:

 Type -ssc install grinset, replace- in Stata.

Alternative installation procedure (if you cannot
use -ssc- due to firewall issues, etc.):

 1. Download grinset.zip.

 2. Unzip grinset.zip into a temporary directory on
    your hard disk (e.g. c:\temp).

 3. Start Stata and type -net from c:\temp- or
    wherever you unzipped the files.

 4. Type -net install grinset, replace-.

20230429, Ben Jann
