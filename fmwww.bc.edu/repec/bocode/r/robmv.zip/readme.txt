Recommended installation procedure:

 Type -ssc install robmv, replace- in Stata.

Alternative installation procedure (if you cannot
use -ssc- due to firewall issues, etc.):

 1. Download robmv.zip.

 2. Unzip robmv.zip into a temporary directory on
    your hard disk (e.g. c:\temp).

 3. Start Stata and type -net from c:\temp- or
    wherever you unzipped the files.

 4. Type -net install robmv, replace-.

20210206, Ben Jann
