Recommended installation procedure:

 Type -ssc install kdens, replace- in Stata.

Alternative installation procedure (if you cannot
use -ssc- due to firewall issues, etc.):

 1. Download kdens.zip.

 2. Unzip kdens.zip into a temporary directory on
    your hard disk (e.g. c:\temp).

 3. Start Stata and type -net from c:\temp- or
    wherever you unzipped the files.

 4. Type -net install kdens, replace-.

20251021, Ben Jann
