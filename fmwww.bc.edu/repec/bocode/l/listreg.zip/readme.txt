Recommended installation procedure:

 Type -ssc install listreg, replace- in Stata.

Alternative installation procedure (if you cannot
use -ssc- due to firewall issues, etc.):

 1. Download listreg.zip.

 2. Unzip listreg.zip into a temporary directory on
    your hard disk (e.g. c:\temp).

 3. Start Stata and type -net from c:\temp- or
    wherever you unzipped the files.

 4. Type -net install listreg, replace-.

20240314, Ben Jann
