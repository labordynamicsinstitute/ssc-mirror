Recommended installation procedure:

 Type -ssc install adolist, replace- in Stata.

Alternative installation procedure (if you cannot
use -ssc- due to firewall issues, etc.):

 1. Download adolist.zip.

 2. Unzip adolist.zip into a temporary directory on
    your hard disk (e.g. c:\temp).

 3. Start Stata and type -net from c:\temp- or
    wherever you unzipped the files.

 4. Type -net install adolist, replace-.

24aug2007, Ben Jann
