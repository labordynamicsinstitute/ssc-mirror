.h addlegend
