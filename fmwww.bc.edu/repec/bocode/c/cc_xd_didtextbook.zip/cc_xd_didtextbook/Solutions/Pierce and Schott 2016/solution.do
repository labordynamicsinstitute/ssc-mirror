capture use "C:\Users\134476\C DE CHAISEMARTIN Dropbox\clément de chaisemartin\A Mini course DID\Applications\Data sets\Pierce and Schott 2016\pierce_schott_didtextbook.dta", clear

if _rc==601{
use "C:\Users\134476.SCIENCESPO\C DE CHAISEMARTIN Dropbox\clément de chaisemartin\A Mini course DID\Applications\Data sets\Pierce and Schott 2016\pierce_schott_didtextbook.dta", clear
}

*1) TWFE regressions
reg delta2001 ntrgap, vce(hc2 indusid, dfadjust)
reg delta2002 ntrgap, vce(hc2 indusid, dfadjust)
reg delta2004 ntrgap, vce(hc2 indusid, dfadjust)
reg delta2005 ntrgap, vce(hc2 indusid, dfadjust)

*2) Weights analysis
twowayfeweights delta2001 indusid cons ntrgap ntrgap, type(fdTR)

*3) Test that the NTR-gap treatment is as good as randomly assigned
reg ntrgap lemp1997 lemp1998 lemp1999 lemp2000, vce(hc2 indusid, dfadjust)
test lemp1997 lemp1998 lemp1999 lemp2000

*4) DID-RD estimator

preserve
reshape long lemp, i(indusid) j(year)
replace ntrgap=0 if year<=2000
did_had lemp indusid year ntrgap, effects(4) placebo(3)
*graph export "C:\Users\134476.SCIENCESPO\C DE CHAISEMARTIN Dropbox\clément de chaisemartin\A Mini course DID\Textbook\figures\did_had_pierce_schott.pdf", replace
restore