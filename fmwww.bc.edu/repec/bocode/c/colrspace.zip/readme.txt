Recommended installation procedure:

 Type -ssc install colrspace, replace- in Stata.

Alternative installation procedure (if you cannot
use -ssc- due to firewall issues, etc.):

 1. Download colrspace.zip.

 2. Unzip colrspace.zip into a temporary directory on
    your hard disk (e.g. c:\temp).

 3. Start Stata and type -net from c:\temp- or
    wherever you unzipped the files.

 4. Type -net install colrspace, replace-.

20220403, Ben Jann
