Recommended installation procedure:

 Type -ssc install fre, replace- in Stata.

Alternative installation procedure (if you cannot
use -ssc- due to firewall issues, etc.):

 1. Download fre.zip.

 2. Unzip fre.zip into a temporary directory on
    your hard disk (e.g. c:\temp).

 3. Start Stata and type -net from c:\temp- or
    wherever you unzipped the files.

 4. Type -net install fre, replace-.

01jun2015, Ben Jann
