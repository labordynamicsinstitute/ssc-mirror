Recommended installation procedure:

 Type -ssc install mrtab, replace- in Stata.

Alternative installation procedure (if you cannot
use -ssc- due to firewall issues, etc.):

 1. Download mrtab.zip.

 2. Unzip mrtab.zip into a temporary directory on
    your hard disk (e.g. c:\temp).

 3. Start Stata and type -net from c:\temp- or
    wherever you unzipped the files.

 4. Type -net install mrtab, replace-.

20250704, Ben Jann
