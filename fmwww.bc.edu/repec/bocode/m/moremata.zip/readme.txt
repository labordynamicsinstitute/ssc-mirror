Recommended installation procedure:

 Type -ssc install moremata, replace- in Stata.

Alternative installation procedure (if you cannot
use -ssc- due to firewall issues, etc.):

 1. Download moremata.zip.

 2. Unzip moremata.zip into a temporary directory on
    your hard disk (e.g. c:\temp).

 3. Start Stata and type -net from c:\temp- or
    wherever you unzipped the files.

 4. Type -net install moremata, replace-.

20220127, Ben Jann
