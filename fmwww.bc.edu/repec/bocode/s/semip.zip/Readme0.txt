This contains Gauss files for applying Lewbel's semiparametric binary choice 
and sample selection model estimators. pdf files of these paper's are included.

@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
			FILES IN THE MAIN DIRECTORY
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@


The file binc.src has a short interface which controls which binary estimator 
is used, and various other options.  Sselc.src is the equivalent for the sample 
selection estimators.  The other src files are supporting routines, called by 
binc.src and sselc.src. The pdf file contains the relevant equations from the 
referenced papers.

binc.src     : main program for the semiparametric binary estimators 
bnsims.txt   : simulations using the binary semiparametric estimators
enbsim.txt   : simulations using the endogenous probit estimator
cv.src       : code for bandwidth selection (density estimation) using cross-validation
ensssim.txt  : simulations using the endogenous sample selection estimator
est.src      : code for the binary semiparametric estimator
estsel.src   : code for the sample selection semiparametric estimator
exsssim.txt  : simulations using the exogenous sample selection estimator
ftrim.src    : trimming fucntion
hcksel.src   : code for the exogenous sample selection estimator
hsel.src     : code for bandwidth selection
kernd.src    : code for kernel density estimation
oiv.dat      : firm-level investment data used in the empirical section
simul.txt    : program used to generate the simulations in the sample selection paper
sord.src     : code for the simple ordered binary estimator
sordsel.src  : code for the simple ordered sample selection estimator
sselc.src    : main program for the semiparametric sample selection estimators
sslsefin.txt : program used to generate the results in the empirical section of the paper
ssfinal.log  : log file from sslsefin.txt, contains the results reported in the paper
bnlsefin.txt : the same as sslsefin.txt, but for the selection eq. of the model
sssims.txt   : simulations using the sample selection semiparametric estimators
summr.src    : code for generating a table of summary statistics (binary version paper)
wfn.src      : weighting functions used in the kernel denisty estimation
semibi10.pdf : "Semiparametric Qualitative Response Model Extimation with Unknown 
               Heteroskedasticity or instrumental Variables"
treat3.pdf   : "Selection Models and Conditional Treatment Effects, Including Endogenous Covariates"
trimdist.pdf : "Asymptotic Trimming for Bounded Density Plug-in Estimators"

@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
			FILES IN SUBDIRECTORY OIVIND
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

oivind.asc     : raw data in comma delimited format
oivind.txt     : Stata do file 
oivind.dta     : stata dataset, produced by oivind.txt
oivinddata.txt : raw data in text format 
oiv2.dat       : oivind.dta in tab delimited format
elkfn22.tex    : Likelihood functions for the MLE
liklfn.pdf     : pdf version of elkfn22.tex
elkfn22s.tex   : shorter version of elkfn22.tex
Files with the nb extension are Mathematica files used 
to check the derivations in the TEX files


Yuriy Tchamourliyski
tchamour@bc.edu
this version
20/01/2002

