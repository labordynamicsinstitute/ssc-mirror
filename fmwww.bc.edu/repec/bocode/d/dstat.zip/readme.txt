Recommended installation procedure:

 Type -ssc install dstat, replace- in Stata.

Alternative installation procedure (if you cannot
use -ssc- due to firewall issues, etc.):

 1. Download dstat.zip.

 2. Unzip dstat.zip into a temporary directory on
    your hard disk (e.g. c:\temp).

 3. Start Stata and type -net from c:\temp- or
    wherever you unzipped the files.

 4. Type -net install dstat, replace-.

20220922, Ben Jann
